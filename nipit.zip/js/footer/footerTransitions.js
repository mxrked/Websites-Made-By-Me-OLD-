/*

    This script is for the footer 

*/



    var i;


    toggleFooterTransitions();

    function toggleFooterTransitions() {

        const ALL_FOOTER_TRANSITIONS = document.getElementsByClassName('footer-transition');

        for (i = 0; i < ALL_FOOTER_TRANSITIONS.length; i++) {

            ALL_FOOTER_TRANSITIONS[i].classList.toggle('window-transition-active');

        }

    }