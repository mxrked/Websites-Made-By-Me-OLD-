/*

    This script is for the back to top btn

*/


    const backToTopBtn = document.getElementById('backToTopBtn');



    function backToTopScroll() {

        window.scrollTo(0,0);

    }



    window.addEventListener('scroll', () => {

        const backToTopTrigger = document.getElementById('backToTopTrigger');

        if (window.scrollY > (backToTopTrigger.offsetTop + backToTopTrigger.offsetHeight)) {

            backToTopBtn.style.display = 'block';

        } else {

            backToTopBtn.style.display = 'none';

        }

    });





    backToTopBtn.addEventListener('click', backToTopScroll);