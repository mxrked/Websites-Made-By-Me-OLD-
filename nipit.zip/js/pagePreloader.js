/*

    This script is for the page preloader

*/

document.querySelector('body').style.overflowY = 'hidden';



    $(window).on('load', function() {

        $('.page-preloader-wrapper').fadeOut('slow');

        setTimeout(() => {

            document.querySelector('body').style.overflowY = 'auto';

        }, 800);

        loadIndexContent();

    });