/*

    This script is for the index quick pages

*/



   
    removeQPBG(); // Hides the QPOverLay by default


        function removeQPBG() { // Hides each of the overlays

            var i;

            const ALL_QPS_OVERLAYS = document.getElementsByClassName('index-quick-page-overlay');

            for (i = 0; i < ALL_QPS_OVERLAYS.length; i++) {

                ALL_QPS_OVERLAYS[i].classList.remove('toggleOverLay');

            }

        }



    

    // Hover Triggers

    document.querySelector('#qPOne').addEventListener('mouseover', () => {

        document.querySelector('#qPO1').classList.toggle('toggleOverLay');

    });


    document.querySelector('#qPTwo').addEventListener('mouseover', () => {

        document.querySelector('#qPO2').classList.toggle('toggleOverLay');

    });


    document.querySelector('#qPThree').addEventListener('mouseover', () => {

        document.querySelector('#qPO3').classList.toggle('toggleOverLay');

    });


    document.querySelector('#qPFour').addEventListener('mouseover', () => {

        document.querySelector('#qPO4').classList.toggle('toggleOverLay');

    });

    
    // Unhover Triggers

    document.querySelector('#qPOne').addEventListener('mouseout', removeQPBG);
    document.querySelector('#qPTwo').addEventListener('mouseout', removeQPBG);
    document.querySelector('#qPThree').addEventListener('mouseout', removeQPBG);
    document.querySelector('#qPFour').addEventListener('mouseout', removeQPBG);