/*

    This script is for the index transitions and shows

*/


    var i;





    toggleIndexTransitions();

    function toggleIndexTransitions() {

        const ALL_INDEX_TRANSITIONS = document.getElementsByClassName('index-transition');

        for (i = 0; i < ALL_INDEX_TRANSITIONS.length; i++) {

            ALL_INDEX_TRANSITIONS[i].classList.toggle('window-transition-active');

        }

    }







    hideIndexContent();

    function hideIndexContent() {

        const ALL_INDEX_HIDES = document.getElementsByClassName('index-hide');

        for (i = 0; i < ALL_INDEX_HIDES.length; i++) {

            ALL_INDEX_HIDES[i].classList.toggle('deactive');

        }

    }








    function loadIndexContent() {


        // Index Heros 
        loadIndexHero();
        loadIndexMobileHero();

        // Index Quick Pages
        loadIndexQPs();


        // Index About and Index Product WILL USE AOS 

        
    }




    function loadIndexHero(left, right) {

        left = document.querySelector('#indexHeroL');
        right = document.querySelector('#indexHeroR');

        setTimeout((content) => {

            content = left;

            // console.log(content);

            content.classList.remove('deactive');
            content.style.bottom = '0px';

        }, 800);

        setTimeout((content) => {

            content = right;

            //console.log(content);

            content.classList.remove('deactive');
            content.style.bottom = '0px';

        }, 1200);

    }


    function loadIndexMobileHero(bg, content) {

        bg = document.querySelector('#indexMobileHeroBG');
        content = document.querySelector('#indexMobileHeroContentDiv');

        setTimeout((bgImg) => {

            bgImg = bg;

            // console.log(bgImg);

            bgImg.classList.remove('deactive');

        }, 800);

        setTimeout((contentDiv) => {

            contentDiv = content;

            // console.log(contentDiv);

            contentDiv.classList.remove('deactive');

        }, 1200);

    } 


    function loadIndexQPs(qpOne, qpTwo, qpThree, qpFour) {

        qpOne = document.querySelector('#qPOne');
        qpTwo = document.querySelector('#qPTwo');
        qpThree = document.querySelector('#qPThree');
        qpFour = document.querySelector('#qPFour');


        setTimeout((qp1) => {

            qp1 = qpOne;

            // console.log(qp1);

            qp1.classList.remove('deactive');
            qp1.style.bottom = '0';

        }, 1600);

        setTimeout((qp2) => {

            qp2 = qpTwo;

            // console.log(qp2);

            qp2.classList.remove('deactive');
            qp2.style.bottom = '0';

        }, 1900);

        setTimeout((qp3) => {

            qp3 = qpThree;

            // console.log(qp3);

            qp3.classList.remove('deactive');
            qp3.style.bottom = '0';

        }, 2200);

        setTimeout((qp4) => {

            qp4 = qpFour;

            // console.log(qp4);

            qp4.classList.remove('deactive');
            qp4.style.bottom = '0';

        }, 2500);

    }