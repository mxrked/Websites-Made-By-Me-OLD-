/*

    This script is for the developers socials tab

*/


    document.querySelector('#openDevsTab').addEventListener('click', () => {

        document.querySelector('#openDevsTab').style.display = 'none';
        document.querySelector('#closeDevsTab').style.display = 'flex';
        document.querySelector('#devsTab').style.marginBottom = '0';

    });


    document.querySelector('#closeDevsTab').addEventListener('click', () => {

        document.querySelector('#openDevsTab').style.display = 'flex';
        document.querySelector('#closeDevsTab').style.display = 'none';
        document.querySelector('#devsTab').style.marginBottom = '-34px';

    });