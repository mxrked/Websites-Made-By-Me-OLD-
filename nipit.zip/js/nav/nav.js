/*

    This script is for the mobile nav

*/



    //! Global Variables

        const NAV_TOGGLER = document.getElementById('navToggler');
        const NAV_CLOSER = document.getElementById('navCloser');
        const NAV_LINKS = document.getElementById('navLinks');
        const NAV_LINKS_MAIN = document.getElementById('navLinksMain');

        let opened;


    //! Global ClassLists 

        document.querySelector('#pageDarken').classList.toggle('deactive'); // Sets the pageDarken to not appear by default
        NAV_CLOSER.classList.toggle('deactive'); 
        NAV_LINKS_MAIN.classList.toggle('deactive');



    //! Functions

        function openNav() { //* Main Open Nav Function

            window.scrollTo(0,0);

            document.body.style.overflowY = 'hidden';
            NAV_TOGGLER.classList.toggle('deactive');
            NAV_LINKS.style.overflowY = 'auto';
            NAV_LINKS.style.width = '95%';

            setTimeout(() => {

                NAV_LINKS_MAIN.classList.remove('deactive');

            }, 400);

            setTimeout(() => { // This makes it so when the user opens the nav, the navCloser isnt squished with the mobile nav links logo

                NAV_CLOSER.classList.remove('deactive');

            }, 600);
            
            document.querySelector('#mobileNavLogo').classList.toggle('deactive');
            document.querySelector("#pageDarken").classList.remove('deactive');

            determineState(); 

            opened = 1; // Indicates that the mobile nav is open.

            console.log(`Mobile Nav is open.`);

        }



        function closeNav() { //* Main Close Nav Function

            NAV_LINKS.style.width = '0';

            document.querySelector('#pageDarken').classList.toggle('deactive');
            NAV_TOGGLER.classList.remove('deactive');
            NAV_CLOSER.classList.toggle('deactive');
            NAV_LINKS_MAIN.classList.toggle('deactive');

            setTimeout(() => { // Makes it so that the mobile nav logo appears after the mobile nav links has closed, makes it look nicer and allows the user to scroll vertically

                document.body.style.overflowY = 'auto';
                document.querySelector('#mobileNavLogo').classList.remove('deactive');

            }, 800);


            closeML(); // This will close the main links
            closeCL(); // This will close the contact links

            opened = 0; // Indicates that the mobile nav is closed.

            console.log(`Mobile Nav is closed.`);

        }






        function determineState() { //* Determines whether or not to display the pageDarken based on the users browser size

            if (window.innerWidth <= 954 && opened === 1) { // If the browsers width is less than or equal to 954px and the mobile nav is opened.

                document.querySelector('#pageDarken').style.display = 'block';
                document.body.style.overflowY = 'auto';

                closeNav();

            } else if (window.innerWidth >= 954 && opened === 0) { // If the browsers width is greater than or equal to 954px and the mobile nav is not opened.

                document.querySelector('#pageDarken').style.display = 'none';
                document.body.style.overflowY = 'auto';

            } 


            if (window.innerHeight <= 483 && opened === 1) { // If the browsers height is less than or equal to 483px and the mobile nav is opened.

                document.querySelector("#pageDarken").style.display = 'none';
                document.body.style.overflowY = 'auto';

                closeNav();

            }


        }
        






        function openML(opener, closer, set) { //* Main Open Main Links Function

            opener = document.querySelector('#openMainLinks').style.display = 'none';
            closer = document.querySelector('#closeMainLinks').style.display = 'flex';

            set = document.querySelector('.main-links-set').classList.toggle('drop');

        }


        function closeML(opener, closer, set) { //* Main Close Main Links Function

            opener = document.querySelector('#openMainLinks').style.display = 'flex';
            closer = document.querySelector('#closeMainLinks').style.display = 'none';

            set = document.querySelector('.main-links-set').classList.remove('drop');

        }


        function openCL(opener, closer, set) { //* Main Open Contact Links Function

            opener = document.querySelector('#openContactLinks').style.display = 'none';
            closer = document.querySelector('#closeContactLinks').style.display = 'flex';

            set = document.querySelector('.contact-links-set').classList.toggle('drop');

        }



        function closeCL(opener, closer, set) { //* Main Close Contact Links Function

            opener = document.querySelector('#openContactLinks').style.display = 'flex';
            closer = document.querySelector('#closeContactLinks').style.display = 'none';

            set = document.querySelector('.contact-links-set').classList.remove('drop');

        }




    //! Event Listeners

        window.addEventListener('resize', () => {

            determineState();

        });

        NAV_TOGGLER.addEventListener('click', () => {

            openNav();

        });

        NAV_CLOSER.addEventListener('click', () => {

            closeNav();

        });

        document.querySelector('#openMainLinks').addEventListener('click', () => {

            openML();

        });

        document.querySelector('#closeMainLinks').addEventListener('click', () => {

            closeML();

        });

        document.querySelector('#openContactLinks').addEventListener('click', () => {

            openCL();

        });

        document.querySelector('#closeContactLinks').addEventListener('click', () => {

            closeCL();

        });