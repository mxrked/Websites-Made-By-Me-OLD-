/*

    This script is for the navigation transitions

*/


    var i;

    toggleNavTransitions();



        function toggleNavTransitions() {

            const NAV_TRANSITIONS = document.getElementsByClassName('nav-transition');

            for (i = 0; i < NAV_TRANSITIONS.length; i++) {

                NAV_TRANSITIONS[i].classList.toggle('window-transition-active');

            }

        }