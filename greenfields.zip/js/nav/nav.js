/* 

    This script is for the mobile nav

*/



    const NAV_LINKS = document.getElementById('navLinks');
    const NAV_TOGGLER = document.getElementById('navToggler');
    const NAV_CLOSER = document.getElementById('navCloser');
    const NAV_LINKS_TOP = document.getElementById('navLinksTop');

    let opened;


    document.body.style.overflowY = 'auto';
    document.querySelector('#mobileNavLogo').classList.remove('deactive');
    document.querySelector('#pageDarken').classList.toggle('deactive');
    NAV_LINKS_TOP.classList.toggle('deactive');
    document.querySelector('#navLinksMain').classList.toggle('deactive');




        //! Open Nav


        function openNav() { //? Main Open Nav Function

            window.scrollTo(0,0); //* Jumps user back up to the top of the page when the nav is opened

            document.body.style.overflowY = 'hidden';

            document.querySelector('#mobileNavLogo').classList.toggle('deactive');
            document.querySelector('#pageDarken').classList.remove('deactive');

            // CB's
            openNavUp();
            determineState();

            opened = 1;
            console.log(`Nav is Open.`);

        }


        function openNavUp() { //? Open Nav Animation

            NAV_TOGGLER.classList.toggle('deactive');
            NAV_LINKS.style.width = '90%';

            setTimeout(() => {

                NAV_LINKS_TOP.classList.remove('deactive');
                document.querySelector('#navLinksMain').classList.remove('deactive');

            }, 750);


        }




        //! Main Links

        function openML(set, closer, toggler) {

            set = document.querySelector('#mLLinks').classList.toggle('drop');
            closer = document.querySelector('#mLCloser').style.display = 'flex';
            toggler = document.querySelector('#mLToggler').style.display = 'none';

        }

        function closeML(set, closer, toggler) {

            set = document.querySelector('#mLLinks').classList.remove('drop');
            closer = document.querySelector('#mLCloser').style.display = 'none';
            toggler = document.querySelector('#mLToggler').style.display = 'flex';

        }




        //! Social Links

        function openSL(set, closer, toggler) {

            set = document.querySelector('#sLLinks').classList.toggle('drop');
            closer = document.querySelector('#sLCloser').style.display = 'flex';
            toggler = document.querySelector('#sLToggler').style.display = 'none';

        }


        function closeSL(set, closer, toggler) {

            set = document.querySelector('#sLLinks').classList.remove('drop');
            closer = document.querySelector('#sLCloser').style.display = 'none';
            toggler = document.querySelector('#sLToggler').style.display = 'flex';

        }





        //! Close Nav

        function closeNav() { //? Main Close Nav Function

            document.body.style.overflowY = 'auto';

            document.querySelector('#pageDarken').classList.toggle('deactive');

            // CB's
            closeNavUp();
            closeML();
            closeSL();

            opened = 0;
            console.log(`Nav is Closed.`);

        }


        function closeNavUp() { //? Close Nav Animation

            NAV_LINKS_TOP.classList.toggle('deactive');
            document.querySelector('#navLinksMain').classList.toggle('deactive');
            NAV_LINKS.style.width = '0';

            setTimeout(() => {

                document.body.style.overflowY = 'auto';
                NAV_TOGGLER.classList.remove('deactive');
                document.querySelector('#mobileNavLogo').classList.remove('deactive');

            }, 700);

        }








        //! Browser Manipulation

        function determineState() { 

        //? Checking browser  width

            if (window.innerWidth <= 954 && opened === 1) {

                document.querySelector('#pageDarken').style.display = 'block';
                document.body.style.overflowY = 'auto';

                closeNav();

            } else if (window.innerWidth >= 954 && opened === 0) {

                document.querySelector('#pageDarken').style.display = 'none';
                document.body.style.overflowY = 'auto';

            } 

        //? Checking browser height

            if (window.innerHeight <= 483 && opened === 1) {

                document.querySelector('#pageDarken').style.display = 'none';
                document.body.style.overflowY = 'auto';

                closeNav();

            }

        }






    window.addEventListener('resize', determineState);
    NAV_TOGGLER.addEventListener('click', openNav);
    NAV_CLOSER.addEventListener('click', closeNav);
    document.querySelector('#mLToggler').addEventListener('click', openML);
    document.querySelector('#mLCloser').addEventListener('click', closeML);
    document.querySelector('#sLToggler').addEventListener('click', openSL);
    document.querySelector('#sLCloser').addEventListener('click', closeSL);