/* 

    This script is for the nav transitions

*/



    toggleNavTransitions();


    var navI;


    function toggleNavTransitions() {

        const ALL_NAV_TRANSITIONS = document.getElementsByClassName('nav-transition');

        for (navI = 0; navI < ALL_NAV_TRANSITIONS.length; navI++) {

            ALL_NAV_TRANSITIONS[navI].classList.toggle('window-transition');

        }

    }