/* 

    !Name:
    lozadMain.js

    !Files Used:
    all

    !Script Desc:
    this script is for the lazy loading imgs


*/



const observer = lozad(); // lazy loads elements with default selector as ".lozad"

observer.observe();