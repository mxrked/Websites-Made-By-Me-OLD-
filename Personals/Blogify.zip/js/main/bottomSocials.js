/*

    This script is for the bottom socials

*/

const bSocials = document.getElementById("bottomSocials");
const bSocialsToggler = document.getElementById("toggleBottomSocials");
const bSocialsCloser = document.getElementById("closeBottomSocials");

bSocials.style.right = "-300px";

bSocialsCloser.style.display = "none";

function triggerBottomSocials(direction, toggler, closer) {
  bSocials.style.right = direction;
  bSocialsToggler.style.display = toggler;
  bSocialsCloser.style.display = closer;
}

bSocialsToggler.addEventListener("click", () => {
  triggerBottomSocials("0px", "none", "grid");
});

bSocialsCloser.addEventListener("click", () => {
  triggerBottomSocials("-156px", "grid", "none");
});

function loadBottomSocials() {
  bSocials.style.right = "-156px";
}
