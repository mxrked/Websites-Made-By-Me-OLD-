/*

    This script is for the backToTopBtn

*/

const backToTopBtn = document.getElementById("b2t");

backToTopBtn.style.bottom = "-50px";

function loadBackToTopBtn() {
  setTimeout(() => {
    backToTopBtn.style.bottom = "20px";
  }, 400);
}

backToTopBtn.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
