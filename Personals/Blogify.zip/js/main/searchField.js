/*

    This script is for the search field

*/

const searchField = document.getElementById("searchFieldInput");
const searchResults = document.getElementById("searchFieldResults");
searchResults.classList.toggle("deactive");

searchField.addEventListener("click", () => {
  searchResults.classList.remove("deactive");
});
searchField.addEventListener("blur", () => {
  searchResults.classList.toggle("deactive");
});

searchField.addEventListener("keyup", () => {
  var searchI;
  let filter;
  filter = searchField.value.toUpperCase();
  const searchResult = searchResults.getElementsByTagName("li");
  let searchResultLink;

  for (searchI = 0; searchI < searchResult.length; searchI++) {
    searchResultLink = searchResult[searchI].getElementsByTagName("a")[0];

    const searchResultTxt =
      searchResultLink.textContent || searchResultLink.innerText;

    if (searchResultTxt.toUpperCase().indexOf(filter) > -1) {
      searchResult[searchI].style.display = "block";
    } else {
      searchResult[searchI].style.display = "none";
    }
  }
});

const searchResultsLinks = document.querySelectorAll(".search-result");
searchResultsLinks.forEach((link) => {
  link.addEventListener("focus", () => {
    searchResults.classList.remove("deactive");
  });
  link.addEventListener("blur", () => {
    searchResults.classList.toggle("deactive");
  });
});

// if user clicks a link
function determineSFLink(link, txt) {
  link = document.getElementById(this);
  console.log(txt);
}

// this will check what the user types into the search field
function checkSFText() {
  const searchFieldValue = searchField.value;
  if (searchFieldValue.toLowerCase().indexOf("movie") > -1) {
    console.log("Movie was entered.");
    // link to movies page
    // window.location.href = "https://netflix.com";
  }

  if (searchFieldValue.toLowerCase().indexOf("gaming") > -1) {
    console.log("Gaming was entered.");
    // link to gaming page
    // window.location.href = "https://twitch.tv";
  }

  if (searchFieldValue.toLowerCase().indexOf("web") > -1) {
    console.log("Web Dev was entered.");
    // link to webdev page
    // window.location.href = "https://github.com";
  }
}

// proceeds to specific page when user types in a specific word and presses enter from the searchField
searchField.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    checkSFText();
  }
});
