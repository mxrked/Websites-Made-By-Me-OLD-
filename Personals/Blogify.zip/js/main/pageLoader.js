/*

    This script is for the pageLoader

*/

const pL = document.getElementById("pageLoader");
const bodyCnt = document.getElementById("mainBodyInner");

bodyCnt.classList.toggle("deactive");

window.addEventListener("load", () => {
  pL.classList.toggle("deactive");

  setTimeout(() => {
    bodyCnt.classList.remove("deactive");
  }, 400);

  setTimeout(() => {
    loadBackToTopBtn();
    loadBottomSocials();
  }, 600);
});
