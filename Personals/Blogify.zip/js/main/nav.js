/*

    This script is for the nav

*/

const navLinks = document.getElementById("mobileNavLinks");
const navToggler = document.getElementById("toggleNav");
const navCloser = document.getElementById("closeNav");
const darkenOverlay = document.getElementById("darkenOL");
const navLinksContent = document.getElementById("mobileNavLinksCnt");
const subToggler = document.getElementById("toggleSub");
const subCloser = document.getElementById("closeSub");
const subSet = document.getElementById("subLinks");

darkenOverlay.style.pointerEvents = "none";
darkenOverlay.style.display = "none";
darkenOverlay.classList.toggle("deactive");

navLinksContent.classList.toggle("deactive");

subCloser.style.display = "none";

// functs
function triggerTogglerSpans(first, third) {
  document.querySelector(".toggler-span:nth-child(1)").style.width = first;
  document.querySelector(".toggler-span:nth-child(3)").style.width = third;
}

function openNav() {
  document.body.style.overflowY = "hidden";

  navToggler.disabled = true;
  navToggler.style.opacity = ".4";

  darkenOverlay.style.display = "block";

  setTimeout(() => {
    darkenOverlay.classList.remove("deactive");
  }, 150);

  setTimeout(() => {
    navLinks.style.width = "100%";
  }, 350);

  setTimeout(() => {
    navLinksContent.classList.remove("deactive");
  }, 650);

  setTimeout(() => {
    darkenOverlay.style.pointerEvents = "auto";
  }, 1000);
}

function closeNav() {
  triggerSub("flex", "none", "0");

  darkenOverlay.style.pointerEvents = "none";

  navLinksContent.classList.toggle("deactive");

  setTimeout(() => {
    navLinks.style.width = "0";
  }, 200);

  setTimeout(() => {
    darkenOverlay.classList.toggle("deactive");
  }, 600);

  setTimeout(() => {
    navToggler.disabled = false;
    navToggler.style.opacity = "1";
    triggerTogglerSpans("25px", "25px");
  }, 1200);

  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 1350);
}

function triggerSub(toggler, closer, mH) {
  subToggler.style.display = toggler;
  subCloser.style.display = closer;
  subSet.style.maxHeight = mH;
}

// events
navToggler.addEventListener("click", () => {
  openNav();
});
navToggler.addEventListener("mouseenter", () => {
  triggerTogglerSpans("13px", "13px");
});
navToggler.addEventListener("mouseleave", () => {
  triggerTogglerSpans("25px", "25px");
});

navCloser.addEventListener("click", closeNav);

subToggler.addEventListener("click", () => {
  triggerSub("none", "flex", "100%");
});
subCloser.addEventListener("click", () => {
  triggerSub("flex", "none", "0");
});

window.onclick = function (event) {
  if (event.target == darkenOverlay) {
    closeNav();
  }
};
