/*

    This script will be used to get rid of the hasttags when the user interacts..... with something...

*/

function removeHashTags() {
  history.pushState(
    "",
    document.title,
    window.location.pathname + window.location.search
  );
}
