/*

    This script is for when the user visits the site for the first time, a newsletter popup appears

*/

document.body.style.overflowY = "hidden";

const newsLetter = document.getElementById("newsLetterPU");
const newsLetterJoiner = document.getElementById("newsLetterJoin");
const newsLetterCloser = document.getElementById("newsLetterCloser");

newsLetter.style.display = "none";
newsLetter.classList.toggle("deactive");

function defaultTriggerNewsLetter() {
  setTimeout(() => {
    newsLetter.style.display = "grid";
  }, 400);

  setTimeout(() => {
    newsLetter.classList.remove("deactive");
  }, 800);
}

// checkNewsLetterVisit(); // this is used in pageLoader
function checkNewsLetterVisit() {
  if (sessionStorage.getItem(newsLetter) !== "true") {
    defaultTriggerNewsLetter();
  } else {
    document.body.style.overflowY = "auto";
  }
}

function closeNewsLetter() {
  newsLetterJoiner.style.pointerEvents = "none";
  newsLetterCloser.style.pointerEvents = "none";
  newsLetter.classList.toggle("deactive");
}

newsLetterCloser.addEventListener("click", () => {
  closeNewsLetter();
  sessionStorage.setItem(newsLetter, "true");

  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 500);
});
