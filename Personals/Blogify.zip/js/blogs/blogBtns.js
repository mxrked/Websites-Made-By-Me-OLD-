/*

    This script is for the blogType Btns

*/

var blogI;
const allBlogTypeBtns_Classes =
  document.getElementsByClassName("blog-types-btn");
const allTypesBtn = document.getElementById("allType");
const movieTypesBtn = document.getElementById("moviesType");
const gamingTypesBtn = document.getElementById("gamingType");
const webDevTypesBtn = document.getElementById("webDevType");

function resetTypeBtns() {
  for (blogI = 0; blogI < allBlogTypeBtns_Classes.length; blogI++) {
    allBlogTypeBtns_Classes[blogI].classList.remove("active");
    allBlogTypeBtns_Classes[blogI].disabled = false;
  }
}

const allBlogTypes_Classes = document.getElementsByClassName("blog-item");
const movieBlogs_Classes = document.getElementsByClassName("blog-m");
const gamingBlogs_Classes = document.getElementsByClassName("blog-g");
const webDevBlogs_Classes = document.getElementsByClassName("blog-w");

function hideAllBlogs() {
  for (blogI = 0; blogI < allBlogTypes_Classes.length; blogI++) {
    allBlogTypes_Classes[blogI].style.display = "none";
  }
}

document.querySelectorAll(".blog-types-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    hideAllBlogs();
    // removes hashes when switching between type btns
    history.pushState(
      "",
      document.title,
      window.location.pathname + window.location.search
    );
  });
});

function determineTypeBtn(btn) {
  resetTypeBtns();
  btn.classList.toggle("active"); //! this will cause a TypeError on other pages besides the Blogs page. (Ignore this)
  btn.disabled = true;
}

// displays allBlogs and stylizes allBlogsBtn by default
determineTypeBtn(allTypesBtn);
showAllBlogs();
function showAllBlogs() {
  for (blogI = 0; blogI < allBlogTypes_Classes.length; blogI++) {
    allBlogTypes_Classes[blogI].style.display = "block";
  }
}
function showMovieBlogs() {
  for (blogI = 0; blogI < movieBlogs_Classes.length; blogI++) {
    movieBlogs_Classes[blogI].style.display = "block";
  }
}
function showGamingBlogs() {
  for (blogI = 0; blogI < gamingBlogs_Classes.length; blogI++) {
    gamingBlogs_Classes[blogI].style.display = "block";
  }
}
function showWebDevBlogs() {
  for (blogI = 0; blogI < webDevBlogs_Classes.length; blogI++) {
    webDevBlogs_Classes[blogI].style.display = "block";
  }
}

// showing types and applying type hashes
allTypesBtn.addEventListener("click", () => {
  showAllBlogs();
  history.replaceState(undefined, undefined, "#all");
});
movieTypesBtn.addEventListener("click", () => {
  showMovieBlogs();
  history.replaceState(undefined, undefined, "#movies");
});
gamingTypesBtn.addEventListener("click", () => {
  showGamingBlogs();
  history.replaceState(undefined, undefined, "#gaming");
});
webDevTypesBtn.addEventListener("click", () => {
  showWebDevBlogs();
  history.replaceState(undefined, undefined, "#webdev");
});

// determining types for nav links
function determineMoviesType() {
  determineTypeBtn(movieTypesBtn);
  hideAllBlogs();
  showMovieBlogs();
}
function determineGamingType() {
  determineTypeBtn(gamingTypesBtn);
  hideAllBlogs();
  showGamingBlogs();
}
function determineWebType() {
  determineTypeBtn(webDevTypesBtn);
  hideAllBlogs();
  showWebDevBlogs();
}

// checks the url for what type to display based on searchfield and nav links
checkBlogsURL();
function checkBlogsURL() {
  if (window.location.href.indexOf("allBlogs.html#movies") > -1) {
    determineMoviesType();
  } else if (window.location.href.indexOf("allBlogs.html#gaming") > -1) {
    determineGamingType();
  } else if (window.location.href.indexOf("allBlogs.html#webdev") > -1) {
    determineWebType();
  }
}

// nav links based
const deskTopM = document.getElementById("dTM");
const deskTopG = document.getElementById("dTG");
const deskTopW = document.getElementById("dTW");

deskTopM.addEventListener("click", determineMoviesType);
deskTopG.addEventListener("click", determineGamingType);
deskTopW.addEventListener("click", determineWebType);

const allMobileTypes = document.querySelectorAll(".mobile-type");
const mobileM = document.getElementById("mM");
const mobileG = document.getElementById("mG");
const mobileW = document.getElementById("mW");
allMobileTypes.forEach((type) => {
  type.addEventListener("click", () => {
    setTimeout(() => {
      closeNav();
    }, 200);
  });
});

mobileM.addEventListener("click", determineMoviesType);
mobileG.addEventListener("click", determineGamingType);
mobileW.addEventListener("click", determineWebType);
