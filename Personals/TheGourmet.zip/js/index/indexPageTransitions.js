/*

    This script is for the index page transitions

*/

function triggerIndexTransitions() {
  // Index Hero Transitions
}
