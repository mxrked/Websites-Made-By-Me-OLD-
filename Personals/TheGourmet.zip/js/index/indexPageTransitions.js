/*

    This script is for the index page transitions

*/

const ALL_INDEX_TRANSITIONS = document.getElementsByClassName(
  "index-transition"
);

for (var i = 0; i < ALL_INDEX_TRANSITIONS.length; i++) {
  ALL_INDEX_TRANSITIONS[i].classList.toggle("deactive");
}

hideIndexContent();

function hideIndexContent() {
  document.querySelector("#indexHero").style.display = "none";
  document.querySelector("#indexRecipes").style.display = "none";
  document.querySelector("#indexAbout").style.display = "none";
  document.querySelector("#indexProductCats").style.display = "none";
}

function triggerIndexTransitions() {
  // Index Hero Transitions
  indexHeroFI();
  indexRecipesFI();
  indexSlickFI();
  indexAboutFI();
  indexProductCatsFI();
}

function indexHeroFI() {
  // This is for the index hero
  setTimeout(() => {
    document.querySelector("#indexHero").style.display = "grid";
  }, 5);

  setTimeout(() => {
    document.querySelector("#indexHero").classList.remove("deactive");
  }, 20);

  setTimeout(() => {
    document.querySelector("#indexHeroContent").classList.remove("deactive");
    document.querySelector("#indexHeroImgs").classList.remove("deactive");
  }, 1200);
}

function indexRecipesFI() {
  // This is for the index recipes
  setTimeout(() => {
    document.querySelector("#indexRecipes").style.display = "grid";
  }, 5);

  setTimeout(() => {
    document.querySelector("#indexRecipes").classList.remove("deactive");
  }, 1200);
}

function indexSlickFI() {
  // This is for the index slick slider
  setTimeout(() => {
    document.querySelector("#indexRecipeExamples").classList.remove("deactive");
  }, 1200);
}

function indexAboutFI() {
  // This is for the index about

  setTimeout(() => {
    document.querySelector("#indexAbout").style.display = "block";
  }, 5);

  setTimeout(() => {
    document.querySelector("#indexAbout").classList.remove("deactive");
  }, 1200);
}

function indexProductCatsFI() {
  // This is for the index about

  setTimeout(() => {
    document.querySelector("#indexProductCats").style.display = "block";
  }, 5);

  setTimeout(() => {
    document.querySelector("#indexProductCats").classList.remove("deactive");
  }, 1200);
}
