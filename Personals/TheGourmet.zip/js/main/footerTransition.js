/*

    This script is for each of the footers

*/

document.querySelector("#footerHolder").style.display = "none";
document.querySelector("#footerHolder").classList.toggle("deactive");

function triggerFooterTransition() {
  setTimeout(() => {
    document.querySelector("#footerHolder").style.display = "block";
  }, 5);

  setTimeout(() => {
    document.querySelector("#footerHolder").classList.remove("deactive");
  }, 1200);
}
