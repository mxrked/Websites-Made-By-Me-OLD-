/*

    This script is for the scrollToTopBtn

*/

const SCROLL_TO_TOP_BTN = document.getElementById("scrollToTopBtn");

SCROLL_TO_TOP_BTN.style.display = "none";

function determineStateForSTTB() {
  // Checks the state of the windows y and if it is = or > 400, it will display the scrollToTopBtn
  if (window.scrollY >= 400) {
    SCROLL_TO_TOP_BTN.style.display = "grid";
  } else if (window.scrollY == 0) {
    SCROLL_TO_TOP_BTN.style.display = "none";
  }
}

window.addEventListener("scroll", determineStateForSTTB);

SCROLL_TO_TOP_BTN.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
