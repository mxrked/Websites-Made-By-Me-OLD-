/*

    This script is for the page loader 

*/

const PAGE_LOADER = document.getElementById("pageLoader");

PAGE_LOADER.classList.remove("deactive");

window.addEventListener("load", () => {
  PAGE_LOADER.classList.toggle("deactive");

  setTimeout(() => {
    triggerIndexTransitions();
  }, 1200);
});
