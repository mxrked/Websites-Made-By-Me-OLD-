/*

    This script is for the nav

*/

//! Script Variables

const NAV = document.getElementById("respNav");
const NAV_TOGGLER = document.getElementById("navToggler");
const NAV_CLOSER = document.getElementById("navCloser");
const NAV_LINKS = document.getElementById("navLinks");
const NAV_LINKS_CONTENT = document.getElementById("navLinksContent");
const DARKEN_LAYER = document.getElementById("darkenLayer");
var navState;

//! Functions

closeNav();

function closeNav() {
  DARKEN_LAYER.classList.toggle("deactive");
  NAV_LINKS.style.width = "0";
  NAV_LINKS_CONTENT.classList.toggle("deactive");
}

NAV_TOGGLER.addEventListener("click", () => {
  DARKEN_LAYER.style.display = "block";

  setTimeout(() => {
    DARKEN_LAYER.classList.remove("deactive");
  }, 3);

  NAV_LINKS.style.width = "100%";

  setTimeout(() => {
    NAV_LINKS_CONTENT.classList.remove("deactive");
  }, 500);
});

function checkNavState() {
  // This will check if the user has scrolled and if so will make the nav fixed
  switch (navState) {
    case 1:
      NAV.style.position = "fixed";
      NAV.style.width = "100%";
      NAV.style.zIndex = "990";
      break;

    case 0:
      NAV.style.position = "relative";
      break;
  }
}

//! Event Listeners

NAV_CLOSER.addEventListener("click", closeNav);

window.addEventListener("click", (e) => {
  if (e.target == NAV_LINKS) {
    closeNav();
  }
});

window.addEventListener("scroll", () => {
  checkNavState();

  navState = 1;
});

window.addEventListener("beforeunload", () => {
  // Makes the user scroll back to top of page on refresh aswell as marks navState = 1 for checkNavState()
  if ("scrollRestoration" in history) {
    navState = 1;

    history.scrollRestoration = "manual";
  }
});
