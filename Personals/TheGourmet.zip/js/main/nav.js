/*

    This script is for the nav

*/

const NAV_TOGGLER = document.getElementById("navToggler");
const NAV_CLOSER = document.getElementById("navCloser");
const NAV_LINKS = document.getElementById("navLinks");
const NAV_LINKS_CONTENT = document.getElementById("navLinksContent");
const DARKEN_LAYER = document.getElementById("darkenLayer");

closeNav();

function closeNav() {
  DARKEN_LAYER.classList.toggle("deactive");
  NAV_LINKS.style.width = "0";
  NAV_LINKS_CONTENT.classList.toggle("deactive");
}

NAV_TOGGLER.addEventListener("click", () => {
  DARKEN_LAYER.style.display = "block";

  setTimeout(() => {
    DARKEN_LAYER.classList.remove("deactive");
  }, 3);

  NAV_LINKS.style.width = "100%";

  setTimeout(() => {
    NAV_LINKS_CONTENT.classList.remove("deactive");
  }, 500);
});

NAV_CLOSER.addEventListener("click", closeNav);

window.addEventListener("click", (e) => {
  if (e.target == NAV_LINKS) {
    closeNav();
  }
});
