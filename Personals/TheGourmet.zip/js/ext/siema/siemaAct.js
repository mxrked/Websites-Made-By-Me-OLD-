/*

    This script is for activating the siema slider

*/

//! Index Siema

const indexSiema = new Siema({
  selector: ".siema",
  perPage: {
    // Adds responsiveness to the siema
    568: 2,
    991: 2,
    1024: 2,
    1366: 3,
  },
  easing: "ease-in-out",
  loop: false,
});

const indexSiemaP = document.getElementById("indexSiemaPrev");
const indexSiemaN = document.getElementById("indexSiemaNext");

indexSiemaP.addEventListener("click", () => indexSiema.prev());
indexSiemaN.addEventListener("click", () => indexSiema.next());
