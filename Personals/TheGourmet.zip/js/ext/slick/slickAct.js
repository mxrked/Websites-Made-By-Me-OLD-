/*

    This script will serve as the activator for each slick slider

*/

// Index Slick

$("#indexRecipeExamplesSlick").slick({
  centerMode: true,
  slidesToShow: 3,
  infinite: false,
  dots: true,

  // Add responsive breakpoints
});
