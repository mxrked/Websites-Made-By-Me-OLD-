<?php 

    // Variables

    $userFirstName = $_POST['contactFN'];
    $userLastName = $_POST['contactLN'];
    $userEmail = $_POST['contactEA'];
    $userTel = $_POST['contactPN'];


    $userFullName = "$userFirstName  $userLastName"; // Pairs the first and last name.


?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="virtual, Aquarium, fish, sharks, whales, crabs, octopus, Aquafy">
    <meta name="description" content="Aquafy is the best virtual Aquarium in the world. Enjoy the sights of the ocean life at the comfort of your home.">
    <meta name="robots" content="index, follow">
    <meta name="author" content="Parker Phelps">
    <meta name="page-topic" content="Animals">
    <meta name="page-type" content="Gallery">
    <title>Aquafy - Virtual Aquarium Gallery. | Results Page</title>

    <!-- Styles -->

        <!--! Bootstrap 5 -->   
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

        <!--! AOS -->
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

        <!-- Original Stylesheets -->

            <!-- Desktop -->
            <link href="styles/scss/resets/resets.css" rel="stylesheet">
            <link href="styles/scss/nav/nav.css" rel="stylesheet">
            <link href="styles/scss/results/results.css" rel="stylesheet">
            <link href="styles/scss/footer/footer.css" rel="stylesheet">

            <!-- Mobile -->
            <link href="styles/css/resp/nav-resp.css" rel="stylesheet">
            <link href="styles/css/resp/results-resp.css" rel="stylesheet">
            <link href="styles/css/resp/footer-resp.css" rel="stylesheet">

            <!-- JS Styles -->
        
                <!-- Add the slick-theme.css if you want default styling -->
                <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
                <!-- Add the slick-theme.css if you want default styling -->
                <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>

                <link href="styles/scss/slick/slick.css" rel="stylesheet">

            <!-- Minified -->


    <!-- Fonts -->
    <!--Logo-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500;600&display=swap" rel="stylesheet">

    <!--Links and Text-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">

    <!--Main Headings-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@700&display=swap" rel="stylesheet">

</head>
<body>


<div id="mainBody">


                <section id="navigation">

                    <nav class="navbar navbar-expand-lg navbar-dark bg-light">

                        <div class="container-fluid navbar-box">

                            <a href="index.html" class="navbar-brand page-transition">

                                <h1>Aquafy</h1>

                            </a>

                            <button class="navbar-toggler page-transition" type="button" data-bs-toggle="collapse" data-bs-target="#navLinks" aria-controls="navLinks" aria-expanded="false" aria-label="Toggle navigation" role="navigation">

                                <span class="navbar-toggler-icon"></span>

                            </button>


                            <div id="navLinks" class="collapse navbar-collapse justify-content-center">

                                <ul class="navbar-nav justify-content-end">

                                    <li class="nav-item">

                                        <a href="about.html" class="nav-link page-transition">About</a>

                                    </li>

                                    <li class="nav-item">

                                        <a href="contact.html" class="nav-link page-transition">Contact</a>

                                    </li>

                                    <li class="nav-item dropdown">

                                        <a class="nav-link dropdown-toggle" href="#" id="navDD" role="button" data-bs-toggle="dropdown" aria-expanded="false">

                                            Categories

                                        </a>

                                        <ul class="dropdown-menu" aria-labelledby="navDD">

                                            <li><a href="fish.html" class="dropdown-item page-transition">Fish</a></li>

                                            <li><a href="sharks.html" class="dropdown-item page-transition">Sharks</a></li>

                                            <li><a href="whales.html" class="dropdown-item page-transition">Whales</a></li>

                                            <li><a href="crabs.html" class="dropdown-item page-transition">Crabs</a></li>

                                            <li><a href="octopus.html" class="dropdown-item page-transition">Octopus</a></li>

                                            <li><a href="categories.html" class="dropdown-menu page-transition">View All</a></li>

                                        </ul>

                                    </li>

                                </ul>

                            </div> <!-- Nav links -->


                        </div> <!-- Nav Box -->

                    </nav> <!-- Nav -->

                </section> <!-- Navigation -->





                <!--? Main Body Inner -->

                <div id="mainBodyInner">

                
                <!--? Results Hero -->

                <section id="resultsHero" class="lozad page-transition-item" data-background-image="https://res.cloudinary.com/dhm6dpv9w/image/upload/v1618508306/Website%20Imgs/Aquafy/contact/hero/pexels-francesco-ungaro-3154150-min_1_bcu0ay.jpg" aria-label="Contact Background">

                        <div class="container-fluid results-hero-box">

                            <div class="row results-hero-row">

                                <div class="col-12 results-hero-side">

                                    <div>

                                        <h2>Contact Form Results</h2>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </section> <!-- Results Hero -->







                <!--? Results Main -->

                <section id="resultsMain">

                    <div id="resultsMainTop">

                        <h2>Here are your results, <?php echo $userFullName ?>.</h2>

                    </div>


                    <div id="resultsMainBoxHolder">

                        <div class="results-main-box">

                            <div class="results-item">

                                <h3>Email Address: </h3>

                                <p><?php echo $userEmail; ?></p>

                            </div>

                            <div class="results-item">

                                <h3>Phone Number: </h3>

                                <p><?php echo $userTel; ?></p>

                            </div>

                            <div class="results-item">

                                <h3>Message: </h3>

                                <p><?php echo htmlspecialchars($_POST['contactMSG']); ?></p>

                            </div>

                        </div>

                    </div>

                </section> <!-- Results Main -->

                    










                    <!--? Footer -->

                    <section id="footerHolder">

                        <footer class="container-fluid footer-box page-transition-item">

                            <div class="row footer-row">

                                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 footer-side" id="footerL">

                                    <div class="footer-side-main">

                                        <div class="footer-logo footer-side-item">

                                            <a href="index.html" class="page-transition-item">

                                                <h1>Aquafy</h1>

                                            </a>

                                        </div>

                                        <div class="footer-under-logo footer-side-item">

                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam ad ducimus aperiam laboriosam.</p>

                                        </div>

                                        <div class="footer-socials footer-side-item">

                                            <a href="#" class="page-transition-item"><i class="fab fa-twitter"></i></a>

                                            <a href="#" class="page-transition-item"><i class="fab fa-facebook"></i></a>

                                            <a href="#" class="page-transition-item"><i class="fab fa-linkedin"></i></a>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 footer-side" id="footerM">

                                    <div class="footer-side-item">

                                        <ul>

                                            <li><a href="about.html" class="page-transition-item">About</a></li>

                                            <li><a href="contact.html" class="page-transition-item">Contact</a></li>

                                            <li><a href="categories.html" class="page-transition-item">Categories</a></li>

                                        </ul>

                                    </div>

                                    <div class="footer-side-item">
                                        
                                        <ul>

                                            <li><a href="fish.html" class="page-transition">Fish</a></li>

                                            <li><a href="sharks.html" class="page-transition">Sharks</a></li>

                                            <li><a href="whales.html" class="page-transition">Whales</a></li>

                                            <li><a href="crabs.html" class="page-transition">Crabs</a></li>

                                            <li><a href="octopus.html" class="page-transition">Octopus</a></li>

                                        </ul>

                                    </div>

                                </div>

                                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 footer-side" id="footerR">

                                    <div class="footer-contact">

                                        <div>

                                            <a href="mailTo:contact@basicallyeasy.com" class="page-transition-item"><i class="fas fa-at"></i> contact@basicallyeasy.com</a>

                                        </div>

                                        <div>

                                            <a href="tel:+13368313432" class="page-transition-item"><i class="fas fa-phone-alt"></i> (336) 831 3432</a>

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div class="footer-under">

                                <p><i class="far fa-copyright"></i> 2021 Aquafy.com.</p>

                            </div>

                        </footer> <!-- Footer Box -->

                    </section> <!-- Footer Holder -->




                </div> <!-- Main Body Inner -->

            </div> <!-- Main Body -->











    <!--! Scripts -->



    <!--* External Scripts -->



        <!--? Bootstrap 5 -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>        



        <!--? FontAwesome -->
        <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>



        <!--? Lozad -->
        <script src="https://cdn.jsdelivr.net/npm/lozad"></script>
        <script>

            // data-src (imgs)
            // data-background-image (background images)

            const observer = lozad(); // lazy loads elements with default selector as ".lozad"

            observer.observe();

        </script>



        <!--? AOS -->
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>

            AOS.init();

            AOS.init({

                once: true,
                disable: 'mobile'

            });

        </script>

    <!--* Original Scripts -->



        <!-- Main -->

        <script src="js/main/screenSizeTransitions.js"></script>

        <!-- Page -->
    
</body>
</html>