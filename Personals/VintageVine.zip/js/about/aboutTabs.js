/*

    This script is for the aboutTabs

*/

const ALL_TAB_TOGGLERS = document.querySelectorAll(".about-tab-toggler");
const ALL_TAB_CONTENTS = document.querySelectorAll(".about-tab-content");
var t1Clicked = 1; // Displays tab1Content by default
var t2Clicked = 0;
var t3Clicked = 0;

deactivateTabs(); // Toggles the deactive class for each tab content

function deactivateTabs() {
  ALL_TAB_CONTENTS.forEach((tab) => {
    tab.classList.toggle("deactive");
  });
}

checkTogglerState(); // This will check which toggler btn is clicked and will display that respected content

function checkTogglerState() {
  switch (t1Clicked) {
    // Toggler 1 Check
    case 1:
      showTC1();

      setTimeout(() => {
        ALL_TAB_CONTENTS[0].classList.remove("deactive");
      }, 700);

      hideTC2();
      hideTC3();

      break;

    case 0:
      hideTC1();

      break;
  }

  switch (t2Clicked) {
    // Toggler 2 Check
    case 1:
      hideTC1();
      showTC2();

      setTimeout(() => {
        ALL_TAB_CONTENTS[1].classList.remove("deactive");
      }, 700);

      hideTC3();

      break;

    case 0:
      hideTC2();

      break;
  }

  switch (t3Clicked) {
    // Toggler 3 Check
    case 1:
      hideTC1();
      hideTC2();
      showTC3();

      setTimeout(() => {
        ALL_TAB_CONTENTS[2].classList.remove("deactive");
      }, 700);

      break;

    case 0:
      hideTC3();

      break;
  }
}

// Shows
function showTC1() {
  ALL_TAB_CONTENTS[0].style.display = "block";
}

function showTC2() {
  ALL_TAB_CONTENTS[1].style.display = "block";
}

function showTC3() {
  ALL_TAB_CONTENTS[2].style.display = "block";
}

// Hides
function hideTC1() {
  ALL_TAB_CONTENTS[0].style.display = "none";
}

function hideTC2() {
  ALL_TAB_CONTENTS[1].style.display = "none";
}

function hideTC3() {
  ALL_TAB_CONTENTS[2].style.display = "none";
}

// Toggler Events
ALL_TAB_TOGGLERS[0].addEventListener("click", () => {
  t1Clicked = 1;
  t2Clicked = 0;
  t3Clicked = 0;

  checkTogglerState();
});

ALL_TAB_TOGGLERS[1].addEventListener("click", () => {
  t1Clicked = 0;
  t2Clicked = 1;
  t3Clicked = 0;

  checkTogglerState();
});

ALL_TAB_TOGGLERS[2].addEventListener("click", () => {
  t1Clicked = 0;
  t2Clicked = 0;
  t3Clicked = 1;

  checkTogglerState();
});
