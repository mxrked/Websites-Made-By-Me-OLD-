/*

    This script is for when the user hovers over a specific imgs, its respected name is displayed

*/

const ALL_TW_IMGS = document.querySelectorAll(".slick-img");
const ALL_TW_NAMES = document.querySelectorAll(".slick-bot-name");

hideITWPNS();

function hideITWPNS() {
  // Hides the item name by default
  ALL_TW_NAMES.forEach((n) => {
    n.classList.toggle("deactive");
    n.innerHTML = "&nbsp;";
  });
}

// Item Imgs Hovers

ALL_TW_IMGS[0].addEventListener("mouseover", () => {
  ALL_TW_NAMES[0].classList.remove("deactive");
  ALL_TW_NAMES[0].innerHTML = "Item 1";
});

ALL_TW_IMGS[1].addEventListener("mouseover", () => {
  ALL_TW_NAMES[0].classList.remove("deactive");
  ALL_TW_NAMES[0].innerHTML = "Item 2";
});

ALL_TW_IMGS[2].addEventListener("mouseover", () => {
  ALL_TW_NAMES[0].classList.remove("deactive");
  ALL_TW_NAMES[0].innerHTML = "Item 3";
});

ALL_TW_IMGS[3].addEventListener("mouseover", () => {
  ALL_TW_NAMES[1].classList.remove("deactive");
  ALL_TW_NAMES[1].innerHTML = "Item 4";
});

ALL_TW_IMGS[4].addEventListener("mouseover", () => {
  ALL_TW_NAMES[1].classList.remove("deactive");
  ALL_TW_NAMES[1].innerHTML = "Item 5";
});

ALL_TW_IMGS[5].addEventListener("mouseover", () => {
  ALL_TW_NAMES[1].classList.remove("deactive");
  ALL_TW_NAMES[1].innerHTML = "Item 6";
});

ALL_TW_IMGS[6].addEventListener("mouseover", () => {
  ALL_TW_NAMES[2].classList.remove("deactive");
  ALL_TW_NAMES[2].innerHTML = "Item 7";
});

ALL_TW_IMGS[7].addEventListener("mouseover", () => {
  ALL_TW_NAMES[2].classList.remove("deactive");
  ALL_TW_NAMES[2].innerHTML = "Item 8";
});

ALL_TW_IMGS[8].addEventListener("mouseover", () => {
  ALL_TW_NAMES[2].classList.remove("deactive");
  ALL_TW_NAMES[2].innerHTML = "Item 9";
});

ALL_TW_IMGS.forEach((img) => {
  // When any of the item imgs are unhovered, the item name is left blank
  img.addEventListener("mouseleave", () => {
    hideITWPNS();
  });
});
