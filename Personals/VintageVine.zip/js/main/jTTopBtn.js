/*

    This script is for the jump to top btn

*/

const JUMP_TO_TOP_BTN = document.getElementById("jumpToTop");

JUMP_TO_TOP_BTN.style.display = "none";

function determineStateForJTTB() {
  // This will determine what position the user has scrolled to
  var windowY = window.scrollY;
  if (windowY >= 800) {
    JUMP_TO_TOP_BTN.style.display = "flex";
  } else if (windowY == 0) {
    JUMP_TO_TOP_BTN.style.display = "none";
  }
}

window.addEventListener("scroll", determineStateForJTTB);
JUMP_TO_TOP_BTN.addEventListener("click", () => {
  // Makes the user jump back to the top of the page when the button is clicked
  window.scrollTo(0, 0);
});
