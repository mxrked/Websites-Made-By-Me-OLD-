/*

    This script will check if the user has been to the site the first time and will ask if they are of/above age or not of/above age.

*/




/*

!NOTE:

    When testing this script, make sure to clear both the session and local storage of the variables below:

        - sE
        - IsThisFirstTime_Log_From_LiveServer //?(ONLY DO THIS ONE IF YOU ARE USING LIVE SERVER TO TEST)


*/





    const SITE_ENTRY = document.getElementById('siteEntry');
    const SITE_ENTRY_MAIN = document.getElementById('siteEntryMain');
    const SITE_ENTRY_YES = document.getElementById('sEY');
    const SITE_ENTRY_NO = document.getElementById('sEN');
    const SITE_ENTRY_CE = document.getElementById('cantEnter');
    


        function checkSiteEntry() { // Main Function


            if (localStorage.sE == 'true') { // Checks if the local storage has visited set to true (if so allow to enter)

                    //* sE = siteEntry local storage variable

                SITE_ENTRY.style.display = 'none';
                SITE_ENTRY.classList.toggle('deactive');

            } else {
                SITE_ENTRY.style.display = 'flex'
                SITE_ENTRY.classList.remove('deactive');

            }

        }
        

        window.addEventListener('load', checkSiteEntry); // Loads the main function

        SITE_ENTRY_YES.addEventListener('click', () => { // Allows user to enter site and marks LS Visited to true

            SITE_ENTRY.classList.toggle('deactive');

            localStorage.sE = (localStorage.sE == "true") ? "false" : "true"; //TODO: sE = true

        });

        SITE_ENTRY_NO.addEventListener('click', () => { // Prevents user from entering the site

            SITE_ENTRY_MAIN.style.display = 'none';

            SITE_ENTRY_CE.style.display = 'block';

            localStorage.sE = (localStorage.sE == "false") ? "false" : "false";  //TODO: sE = false

        });