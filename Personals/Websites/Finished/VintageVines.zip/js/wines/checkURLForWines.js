/*

    This script will be used to determine the URL for a wine type (FOR BOTH THE SEARCH FIELD AND NAV)

*/

determineWinesURL();
function determineWinesURL() {
  if (window.location.href.indexOf("red") > -1) {
    console.log("Red (Chosen from Nav OR Search Field)");
    hideWineTypes();
    everyThingRed();
  }
  if (window.location.href.indexOf("white") > -1) {
    console.log("White (Chosen from Nav OR Search Field)");
    hideWineTypes();
    everyThingWhite();
  }
  if (window.location.href.indexOf("rose") > -1) {
    console.log("Rose (Chosen from Nav OR Search Field)");
    hideWineTypes();
    everyThingRose();
  }
  if (window.location.href.indexOf("sparkling") > -1) {
    console.log("Sparkling (Chosen from Nav OR Search Field)");
    hideWineTypes();
    everyThingSparkling();
  }
}
