/*

    This script is for the nav

*/

const darkOverlay = document.getElementById("darkenOL");
const navToggler = document.getElementById("toggleNav");
const navCloser = document.getElementById("closeNav");
const navLinks = document.getElementById("mobileNavLinks");
const navLinksCnt = document.getElementById("mobileNavLinksCnt");
const subToggler = document.getElementById("toggleSub");
const subCloser = document.getElementById("closeSub");
const subSet = document.getElementById("subLinks");

mainNavDefaults();
function mainNavDefaults() {
  darkOverlay.classList.toggle("deactive");
  darkOverlay.style.pointerEvents = "none";
  navLinksCnt.classList.toggle("deactive");
  navLinksCnt.style.display = "none";
  subCloser.style.display = "none";
}

//
//
/*

    Sub Links Code

*/

function subBtnsState(toggler, closer) {
  subToggler.style.display = toggler;
  subCloser.style.display = closer;

  if (toggler == "none") {
    subSet.style.maxHeight = "100%";
  } else if (toggler == "flex") {
    subSet.style.maxHeight = "0";
  }
}

function openSub() {
  subBtnsState("none", "flex");
}
function closeSub() {
  subBtnsState("flex", "none");
}

subToggler.addEventListener("click", openSub);
subCloser.addEventListener("click", closeSub);

//
//
/*

    Nav Toggler and Closer Code

*/

function togglerSpansState(top, bottom) {
  document.querySelector(".toggle-nav-span:nth-child(1)").style.width = top;
  document.querySelector(".toggle-nav-span:nth-child(3)").style.width = bottom;
}

function togglerApperanceState(able, opac) {
  navToggler.disabled = able;
  navToggler.style.opacity = opac;
}

function openNav() {
  togglerApperanceState(true, ".5");
  togglerSpansState("10px", "10px");

  darkOverlay.classList.remove("deactive");
  document.body.style.overflowY = "hidden";
  navLinks.style.width = "100%";

  setTimeout(() => {
    navLinksCnt.style.display = "block";
  }, 700);
  setTimeout(() => {
    navLinksCnt.classList.remove("deactive");
  }, 780);
  setTimeout(() => {
    darkOverlay.style.pointerEvents = "auto";
  }, 1200);
}

function closeNav() {
  closeSub();
  darkOverlay.style.pointerEvents = "none";
  navLinksCnt.classList.toggle("deactive");

  setTimeout(() => {
    navLinks.style.width = "0";
  }, 500);
  setTimeout(() => {
    darkOverlay.classList.toggle("deactive");
  }, 1200);
  setTimeout(() => {
    togglerApperanceState(false, "1");
    togglerSpansState("20px", "20px");
  }, 1800);
  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 2000);
}

navToggler.addEventListener("mouseenter", () => {
  togglerSpansState("10px", "10px");
});
navToggler.addEventListener("mouseleave", () => {
  togglerSpansState("20px", "20px");
});
navToggler.addEventListener("click", () => {
  openNav();
});

navCloser.addEventListener("click", closeNav);

window.onclick = function (e) {
  if (e.target == darkOverlay) {
    closeNav();
  }
};
