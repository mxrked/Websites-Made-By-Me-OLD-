<!-- 

    This will send me an email when the user uses the contact form 
    as well as a confirmation email back to the user.

-->


<?php

    session_start();

    if(isset($_POST['submit'])) {


        $firstName = $_POST['fName'];
        $lastName = $_POST['lName'];
        $emailAddress = $_POST['emailAdd'];
        $phoneNumber = $_POST['phoneNum'];
        $usersMessage = $_POST['userMsg'];


        // Email Type Messages
        $hostType = 'You have gotten an email from the `Blogify Contact Form` and the results from that form are below: ';

        // Bottom of emails
        $siteMakerName = 'Parker Phelps';
        $siteMakerOccupation = 'Front End Developer\Designer';
        $siteMakerPhoneNumber = '(336) 831-3432';


        // Sending
        $to = 'contact@basicallyeasy.com';
        $subject = 'Contact Form Submission - Blogify | User Form.';
        $subject2 = 'Contact Form Submission - Blogify | Successfully Sent!';
        $message = $hostType."\n\n"."First Name: ".$firstName."\n"."Last Name: ".$lastName."\n"."Email Address: ".$emailAddress."\n"."Phone Number: ".$phoneNumber."\n"."Message: "."\n\n".$usersMessage;
        $message2 = "Your contact form was sent successfully. You will be contacted back shortly!"."\n"."\n".$siteMakerName."\n".$siteMakerOccupation."\n".$siteMakerPhoneNumber;
        $headers = "From: ".$emailAddress;
        $headers2 = "From: ".$to;


        if (mail($to, $subject, $message, $headers)) {
            header("Location: http://basicallyeasy.com"); // Change maybe when upgrading to HTTPS
        } else {
            echo "Something went wrong!";
        }

        // This will send a email to the user stating that their contact form was sent successfully.
        mail($emailAddress, $subject2, $message2, $headers2);
        

    }




?>