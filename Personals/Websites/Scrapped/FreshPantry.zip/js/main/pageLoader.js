/*

    This script is for the pageLoader

*/

document.body.style.overflowY = "hidden";

const pageLoader = document.getElementById("pageLoader");

window.addEventListener("load", () => {
  pageLoader.classList.toggle("deactive");

  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 500);

  setTimeout(() => {
    loadIndexFadeIns();
    showSCAfterLoad();
  }, 1000);
});
