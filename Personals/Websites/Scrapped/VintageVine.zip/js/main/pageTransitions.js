/*

    This script is for the page transitions and full seconds

*/

pageTransitionsInit();

function pageTransitionsInit() {
  // Main Function for the pageTransitions
  const ALL_PAGE_TRANSITIONS = document.querySelectorAll(
    ".page-transition-item"
  );

  ALL_PAGE_TRANSITIONS.forEach((pt) => {
    // Each of the page-transition-items will be tagged with the class
    pt.classList.toggle("page-transition");
  });

  const ALL_FULL_SECONDS = document.querySelectorAll(".full-second-item");

  ALL_FULL_SECONDS.forEach((fs) => {
    // Each of the full-second-item will be tagged with the class
    fs.classList.toggle("full-second");
  });
}
