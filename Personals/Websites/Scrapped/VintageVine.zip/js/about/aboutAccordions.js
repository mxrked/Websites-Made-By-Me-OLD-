/*

    This script is for the about accordions

*/

const ABOUT_ACCORDION_BTNS = document.querySelectorAll(".accordion-toggler");
const ABOUT_ACCORDION_PANELS = document.querySelectorAll(".accordion-panel");
const ABOUT_ACCORDION_ICON = document.querySelectorAll(".accordion-toggler i");
var currentAccordPanel;

// Accordion 1
ABOUT_ACCORDION_BTNS[0].addEventListener("click", () => {
  currentAccordPanel = ABOUT_ACCORDION_PANELS[0];

  if (currentAccordPanel.style.maxHeight) {
    currentAccordPanel.style.maxHeight = null;
    ABOUT_ACCORDION_ICON[0].classList.remove("rotateAccordIcon");
  } else {
    currentAccordPanel.style.maxHeight = currentAccordPanel.scrollHeight + "px";
    ABOUT_ACCORDION_ICON[0].classList.toggle("rotateAccordIcon");
  }
});

// Accordion 1
ABOUT_ACCORDION_BTNS[1].addEventListener("click", () => {
  currentAccordPanel = ABOUT_ACCORDION_PANELS[1];

  if (currentAccordPanel.style.maxHeight) {
    currentAccordPanel.style.maxHeight = null;
    ABOUT_ACCORDION_ICON[1].classList.remove("rotateAccordIcon");
  } else {
    currentAccordPanel.style.maxHeight = currentAccordPanel.scrollHeight + "px";
    ABOUT_ACCORDION_ICON[1].classList.toggle("rotateAccordIcon");
  }
});
