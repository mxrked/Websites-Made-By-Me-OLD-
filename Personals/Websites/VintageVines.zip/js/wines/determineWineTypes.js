/*

    This script will be used to display the respected wine type based 
    on the URL or if the user picks a type

*/

var iBtns;
var iTypes;

const allWBtn = document.getElementById("allWinesBtn");
const redWBtn = document.getElementById("redWinesBtn");
const whiteWBtn = document.getElementById("whiteWinesBtn");
const roseWBtn = document.getElementById("roseWinesBtn");
const sparklingWBtn = document.getElementById("sparklingWinesBtn");

function resetWineBtns() {
  const allWineBtns = document.getElementsByClassName("wines-btn");

  for (iBtns = 0; iBtns < allWineBtns.length; iBtns++) {
    allWineBtns[iBtns].disabled = false;
    allWineBtns[iBtns].classList.remove("active-btn");
  }
}

// this will make the styling for the specific wine btn
function determineWinesBtn(btn) {
  resetWineBtns();
  btn.classList.toggle("active-btn");
  btn.disabled = true;
}
determineWinesBtn(allWBtn); // make all btn defaulted

const allWineTypes = document.getElementsByClassName("wine-type");
function hideWineTypes() {
  for (iTypes = 0; iTypes < allWineTypes.length; iTypes++) {
    allWineTypes[iTypes].style.height = "0";
    allWineTypes[iTypes].classList.toggle("deactive");
  }
}

// each wine btn when pressed, will hide all the wines and remove the hash from the previous btn
document.querySelectorAll(".wines-btn").forEach((wb) => {
  wb.addEventListener("click", () => {
    hideWineTypes();
    history.pushState("", document.title, window.location.pathname);
  });
});

// this main function will display the specific wine type items
function displayWineType(type) {
  for (iTypes = 0; iTypes < type.length; iTypes++) {
    type[iTypes].style.height = "400px";
  }
  setTimeout(() => {
    for (iTypes = 0; iTypes < type.length; iTypes++) {
      type[iTypes].classList.remove("deactive");
    }
  }, 200);
}

// this is a faster way of creating a hash for each wine btn
function addWineHash(txt) {
  window.location.hash = txt;
}

// store the specific code for each wine type
function everyThingAll() {
  determineWinesBtn(allWBtn);
  displayWineType(document.getElementsByClassName("wine-type"));
  addWineHash("all");
}
function everyThingRed() {
  determineWinesBtn(redWBtn);
  displayWineType(document.getElementsByClassName("red-wine"));
  addWineHash("red");
}
function everyThingWhite() {
  determineWinesBtn(whiteWBtn);
  displayWineType(document.getElementsByClassName("white-wine"));
  addWineHash("white");
}
function everyThingRose() {
  determineWinesBtn(roseWBtn);
  displayWineType(document.getElementsByClassName("rose-wine"));
  addWineHash("rose");
}
function everyThingSparkling() {
  determineWinesBtn(sparklingWBtn);
  displayWineType(document.getElementsByClassName("sparkling-wine"));
  addWineHash("sparkling");
}

const allWineHeroTypes = document.querySelectorAll(".wines-hero-type");
allWineHeroTypes.forEach((type) => {
  type.addEventListener("click", hideWineTypes);
});

allWineHeroTypes[0].addEventListener("click", () => {
  everyThingRed();
});
allWineHeroTypes[1].addEventListener("click", () => {
  everyThingWhite();
});
allWineHeroTypes[2].addEventListener("click", () => {
  everyThingRose();
});
allWineHeroTypes[3].addEventListener("click", () => {
  everyThingSparkling();
});

allWBtn.addEventListener("click", () => {
  everyThingAll();
});

redWBtn.addEventListener("click", () => {
  everyThingRed();
});

whiteWBtn.addEventListener("click", () => {
  everyThingWhite();
});

roseWBtn.addEventListener("click", () => {
  everyThingRose();
});

sparklingWBtn.addEventListener("click", () => {
  everyThingSparkling();
});

// this will make so when the user chooses from the search field, it will close it and display that type of wine
document.querySelectorAll(".search-result").forEach((sr) => {
  sr.addEventListener("click", hideWineTypes);
});
document.getElementById("sR3").addEventListener("click", () => {
  everyThingRed();
});
document.getElementById("sR4").addEventListener("click", () => {
  everyThingWhite();
});
document.getElementById("sR5").addEventListener("click", () => {
  everyThingRose();
});
document.getElementById("sR6").addEventListener("click", () => {
  everyThingSparkling();
});
