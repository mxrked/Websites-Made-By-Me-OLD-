/*

    This script is used for stylizing some of the splide items

*/

var splideI;
// Index Products

const allIndexProducts = document.querySelectorAll(".index-product-img");
const indexProductsImgs = document.getElementsByClassName("index-product-img");

function brightenSplideItems(items) {
  for (splideI = 0; splideI < items.length; splideI++) {
    items[splideI].style.opacity = "1";
  }
}

function lightenSplideItems(items) {
  for (splideI = 0; splideI < items.length; splideI++) {
    items[splideI].style.opacity = "0.5";
  }
}

allIndexProducts.forEach((img) => {
  img.addEventListener("mouseover", () => {
    lightenSplideItems(allIndexProducts);
    img.style.opacity = "1";
  });
});

indexSplider.addEventListener("mouseleave", () => {
  brightenSplideItems(allIndexProducts);
});

resetIndexSplide();
function resetIndexSplide() {
  indexSpliderArrows.forEach((arrow) => {
    arrow.addEventListener("click", () => {
      brightenSplideItems(allIndexProducts);
    });
  });
}
