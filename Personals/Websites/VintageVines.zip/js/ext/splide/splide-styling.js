/*

    This script is used for stylizing some of the splide items

*/

var splideI;
// Index Products

const allIndexProducts = document.querySelectorAll(".index-product-img");
const indexProductsImgs = document.getElementsByClassName("index-product-img");
