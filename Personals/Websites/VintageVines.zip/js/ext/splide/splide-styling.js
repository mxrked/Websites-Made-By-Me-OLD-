/*

    This script is for the splide slider stylings

*/

let splideI;

//! Index Page
//* Products Splide
// Determines if the user hovers or unhovers and changes the opacity

const lightenISplideItems = (hovered) => {
  const iSplideItems = document.getElementsByClassName(
    "splide-slide-inner-item"
  );

  if (hovered == true) {
    for (splideI = 0; splideI < iSplideItems.length; splideI++) {
      iSplideItems[splideI].style.opacity = "0.5";
    }
  }

  if (hovered == false) {
    for (splideI = 0; splideI < iSplideItems.length; splideI++) {
      iSplideItems[splideI].style.opacity = "1";
    }
  }
};
// Applys styling for each item
document.querySelectorAll(".splide-slide-inner-item").forEach((item) => {
  item.addEventListener("mouseenter", () => {
    lightenISplideItems(true);
    item.style.opacity = "1";
  });
  item.addEventListener("mouseleave", () => {
    lightenISplideItems(false);
  });
});
