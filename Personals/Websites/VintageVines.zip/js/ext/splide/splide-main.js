/*

    This script will be what holds the activation for the splides

*/

// Index Splide
const indexSplider = document.getElementById("indexProductsSplide");
const indexSpliderArrows = document.querySelectorAll(
  "#indexProductsSplide .splide__arrow"
);

function indexSplide() {
  new Splide("#indexProductsSplide", {
    rewind: "true",
    // autoplay: "true",
    drag: "true",
    perPage: 1,
    breakpoints: {
      1600: {
        perPage: 1,
      },
      1366: {
        perPage: 1,
      },
      1024: {
        perPage: 1,
      },
      991: {
        perPage: 1,
      },
      768: {
        perPage: 1,
      },
    },
  }).mount();
}

function storeSplides() {
  indexSplide();
}

window.addEventListener("DOMContentLoaded", storeSplides);
