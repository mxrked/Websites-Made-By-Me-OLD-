/*

    This script will store the AOS 

*/

function triggerAOS() {
  AOS.init({
    once: true,
    disable: "mobile",
  });
}
