/*

    This script is for activating and closing the shopping cart


*/

const shoppingCart = document.getElementById("sC");
const shoppingCartDarken = document.getElementById("cartDarken");
const shoppingCartToggler = document.getElementById("cartToggler");
const shoppingCartCloser = document.getElementById("cartCloser");
const shoppingCartContent = document.getElementById("cartCnt");

shoppingCart.style.width = "0px";
shoppingCartContent.classList.toggle("deactive");
shoppingCartDarken.classList.toggle("deactive");
shoppingCartDarken.style.pointerEvents = "none";

function darkenShoppingCartBG(state) {
  if (state == true) {
    shoppingCartDarken.classList.remove("deactive");
  } else if (state == false) {
    shoppingCartDarken.classList.toggle("deactive");
    shoppingCartDarken.style.pointerEvents = "none";
  }
}

function openShoppingCart() {
  darkenShoppingCartBG(true);

  shoppingCart.style.width = "100%";

  setTimeout(() => {
    shoppingCartContent.classList.remove("deactive");
  }, 700);
  setTimeout(() => {
    shoppingCartDarken.style.pointerEvents = "auto";
  }, 830);
}

function closeShoppingCart() {
  shoppingCartContent.classList.toggle("deactive");

  setTimeout(() => {
    darkenShoppingCartBG(false);
    shoppingCart.style.width = "0px";
  }, 500);
}

shoppingCartToggler.addEventListener("click", () => {
  openShoppingCart();
});
shoppingCartCloser.addEventListener("click", () => {
  closeShoppingCart();
});
window.addEventListener("click", (e) => {
  if (e.target == shoppingCartDarken) {
    closeShoppingCart();
  }
});
