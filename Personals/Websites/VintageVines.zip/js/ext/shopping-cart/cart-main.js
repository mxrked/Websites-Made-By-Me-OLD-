const shoppingCartTable = document.getElementById("sCTable");
const shoppingCartCart = document.getElementById("sCCart");
const shoppingCartTotal = document.getElementById("sCTotal");

var itemAdded;
function renderSC(items) {
  // <td>${item.img}</td> // Add this in later
  shoppingCartCart.innerHTML = items
    .map(
      (item) => `
        <tr class="shopping-cart-item">
        
        <td class="sc-item-id">#${item.id}</td>
        <td class="sc-item-img">
          <img src="${item.img}" alt="${item.name} Wine.">
        </td>
        <td>${item.name}</td>
        <td>${item.quantity}</td>
        <td style="width: 60px;">

            <button type="button" class="sc-btn quantity-add" onClick="cartLS.quantity(${item.id},1)">+</button>
        
        </td>

        <td style="width: 60px;">
        
            <button type="button" class="sc-btn quantity-remove" onClick="cartLS.quantity(${item.id},-1)">-</button>

        </td>


        <td class="sc-item-price">$${item.price}</td>
        <td class="sc-item-remove">
        <button class="sc-item-remove-btn" onClick="cartLS.remove(${item.id})">Delete</button>
        </td>

        </tr>
    `
    )
    .join("");

  shoppingCartTotal.innerHTML = "$" + cartLS.total();
  checkingSCItems();
}

renderSC(cartLS.list());
cartLS.onChange(renderSC);

console.log(localStorage["__cart"]);

// Check to see if there are any items in the cart, if not; display a message
function checkingSCItems() {
  const shoppingCartHint = document.getElementById("sCHint");
  if (localStorage["__cart"] == "[]") {
    shoppingCartHint.style.display = "grid";
    shoppingCartTable.classList.toggle("deactive");
  }

  if (localStorage["__cart"] != "[]") {
    shoppingCartHint.style.display = "none";
    shoppingCartTable.classList.remove("deactive");
  }
}
