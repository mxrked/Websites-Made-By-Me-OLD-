/*

    This script is for a tribute to our little guy Bubba. Rest in Peace little guy :)

*/

const bubbaMemorial = document.getElementById("bubbaTribute");

if ((pageLoaderState = "true")) {
  setTimeout(() => {
    addBubbaToStorage();
  }, 500);
}

// love you little guy :)
function addBubbaToStorage() {
  localStorage.setItem(bubbaMemorial, "true");
}

checkBubbaState();
function checkBubbaState() {
  if (localStorage.getItem(bubbaMemorial) == "true") {
    bubbaMemorial.classList.toggle("deactive");
  } else {
    addBubbaToStorage();
    setTimeout(() => {
      bubbaMemorial.classList.toggle("deactive");
    }, 5000);
  }
}
