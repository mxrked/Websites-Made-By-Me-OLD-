/*

    This script is for the nav

*/

const nav = document.getElementById("respNav");

nav.classList.toggle("deactive");
window.addEventListener("load", () => {
  setTimeout(() => {
    nav.classList.remove("deactive");
  }, 600);
});

const navToggler = document.getElementById("navToggler");
const navCloser = document.getElementById("navCloser");
const navLinks = document.getElementById("navLinks");
const navLinksCnt = document.getElementById("navLinksCnt");
const darkOL = document.getElementById("darkenOL");
var navI;

const allTogglerSpans = document.querySelectorAll(".nav-t-span");

darkOL.style.display = "none";
darkOL.classList.toggle("deactive");
darkOL.style.pointerEvents = "none";

navLinksCnt.classList.toggle("deactive");

function lockTogglerSpans(span1, span2, w1, w2) {
  span1.style.width = w1;
  span2.style.width = w2;
}

function openNav() {
  navToggler.disabled = true;
  navToggler.style.opacity = ".4";
  lockTogglerSpans(allTogglerSpans[0], allTogglerSpans[2], "15px", "15px");

  darkOL.style.display = "block";

  setTimeout(() => {
    darkOL.classList.remove("deactive");
  }, 200);
  setTimeout(() => {
    darkOL.style.pointerEvents = "auto";
  }, 1000);

  setTimeout(() => {
    navLinks.style.width = "100%";
  }, 220);
  setTimeout(() => {
    navLinksCnt.classList.remove("deactive");
  }, 850);
}

function closeNav() {
  darkOL.style.pointerEvents = "none";
  navLinksCnt.classList.toggle("deactive");

  setTimeout(() => {
    navLinks.style.width = "0";
  }, 500);

  setTimeout(() => {
    darkOL.classList.toggle("deactive");
  }, 800);

  setTimeout(() => {
    navToggler.disabled = false;
    navToggler.style.opacity = "1";

    lockTogglerSpans(allTogglerSpans[0], allTogglerSpans[2], "30px", "30px");
  }, 1400);
}

navToggler.addEventListener("click", () => {
  openNav();
});
navToggler.addEventListener("mouseenter", () => {
  lockTogglerSpans(allTogglerSpans[0], allTogglerSpans[2], "15px", "15px");
});
navToggler.addEventListener("mouseleave", () => {
  lockTogglerSpans(allTogglerSpans[0], allTogglerSpans[2], "30px", "30px");
});
navCloser.addEventListener("click", () => {
  closeNav();
});

window.onclick = function (e) {
  if (e.target == darkOL) {
    closeNav();
  }
};
