/*

    This script is for the nav

*/

function scrollingNav() {
  const navHolder = document.getElementById("fullNav");

  if (window.scrollY <= 100) {
    navHolder.style.top = "0px";
  }

  if (window.scrollY >= 101) {
    navHolder.style.top = "-700px";
  }
}

window.addEventListener("scroll", scrollingNav);
