/*

    This script is for the pageLoader

*/

const pageLoader = document.getElementById("pageLoader");
const pageLoaderCnt = document.querySelector(".page-loader-cnt");

window.addEventListener("load", () => {
  pageLoaderCnt.classList.toggle("deactive");
  pageLoader.style.height = "0";
});
