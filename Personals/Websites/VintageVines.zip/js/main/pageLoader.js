/*

    This script is for the pageLoader

*/

const pageLoaderHolder = document.getElementById("pageLoader");
const pageLoaderContent = document.getElementById("pageLoaderCnt");
var pageLoaderState; // This will be used to check for AOS later

document.querySelector(".page-top-inner").style.opacity = "0.2";

function determinePageContentState(state) {
  if (state == true) {
    document.getElementById("mainBodyInner").classList.remove("deactive");

    setTimeout(() => {
      document.body.style.overflowY = "auto";
    }, 200);
  } else if (state == false) {
    document.getElementById("mainBodyInner").classList.toggle("deactive");
    document.body.style.overflowY = "hidden";
  }
}
determinePageContentState(false);

function determinePageLoaderState() {
  if (pageLoaderState == true) {
    pageLoaderContent.classList.toggle("deactive");

    setTimeout(() => {
      pageLoaderHolder.style.height = "0";
    }, 800);
  }

  if ((pageLoaderHolder.style.height = "0" && pageLoaderState == true)) {
    setTimeout(() => {
      determinePageContentState(true);
    }, 1800);
    setTimeout(() => {
      triggerAOS();
    }, 2400);
    setTimeout(() => {
      document.querySelector(".page-top-inner").style.opacity = "1";
      pageLoaderHolder.style.display = "none";
    }, 2300);
  }
}

window.addEventListener("load", () => {
  pageLoaderState = true;
  determinePageLoaderState();
});
