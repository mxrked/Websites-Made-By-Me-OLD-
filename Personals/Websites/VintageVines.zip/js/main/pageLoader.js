/*

    This script is for the pageLoader

*/

const pageLoader = document.getElementById("pageLoader");
const pageLoaderCnt = document.querySelector(".page-loader-cnt");
var pageLoaderState;

determinePageLoaderState();
function determinePageLoaderState() {
  if (pageLoader.style.height == "0") {
    pageLoaderState = true;
  }
}

window.addEventListener("load", () => {
  pageLoaderCnt.classList.toggle("deactive");
  pageLoader.style.height = "0";
  determinePageLoaderState();
});
