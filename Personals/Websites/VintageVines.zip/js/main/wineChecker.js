/*

    This script will go through the list of the different types of wines on the site

*/

var loggedWine;
const redNames = ["cabernet", "merlot", "malbec"];
const whiteNames = ["chardonnay", "moscato", "riesling"];
const roseNames = ["grenache", "provence", "syran"];
const sparklingNames = ["cava", "cremant", "sekt"];

function determineWineLink(wName) {
  switch (wName) {
    // red wines
    case redNames[0]:
      loggedWine = "Cabernet was choosen.";
      console.log(loggedWine);
      break;
    case redNames[1]:
      loggedWine = "Merlot was choosen.";
      console.log(loggedWine);
      break;
    case redNames[2]:
      loggedWine = "Malbec was choosen.";
      console.log(loggedWine);
      break;
    // white wines
    case whiteNames[0]:
      loggedWine = "Chardonnay was chosen.";
      console.log(loggedWine);
      break;
    case whiteNames[1]:
      loggedWine = "Moscato was chosen.";
      console.log(loggedWine);
      break;
    case whiteNames[2]:
      loggedWine = "Riesling was chosen.";
      console.log(loggedWine);
      break;
    // rose wines
    case roseNames[0]:
      loggedWine = "Grenache was chosen.";
      console.log(loggedWine);
      break;
    case roseNames[1]:
      loggedWine = "Provence was chosen.";
      console.log(loggedWine);
      break;
    case roseNames[2]:
      loggedWine = "Syran was chosen.";
      console.log(loggedWine);
      break;
    // sparkling wines
    case sparklingNames[0]:
      loggedWine = "Cava was chosen.";
      console.log(loggedWine);
      break;
    case sparklingNames[1]:
      loggedWine = "Cremant was chosen.";
      console.log(loggedWine);
      break;
    case sparklingNames[2]:
      loggedWine = "Sekt was chosen.";
      console.log(loggedWine);
      break;
  }
}
