/*

    This script is for the backToTopBtn

*/

const b2T = document.getElementById("backToTopBtn");
b2T.style.bottom = "-50px";

function checkB2TState() {
  if (window.scrollY >= 200) {
    b2T.style.bottom = "15px";
  } else if (window.scrollY < 200) {
    b2T.style.bottom = "-50px";
  }
}

window.addEventListener("scroll", checkB2TState);
b2T.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
