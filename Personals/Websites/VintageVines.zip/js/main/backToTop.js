/*

    This script is for the backToTopBtn

*/

const backToTopBtn = document.getElementById("backToTop");

function manipulateBackToTop(cartT, b2T) {
  document.getElementById("cartToggler").style.bottom = cartT;
  backToTopBtn.style.bottom = b2T;
}

manipulateBackToTop("-80px", "-100px");

function determineBackToTop() {
  if (window.scrollY <= 110) {
    manipulateBackToTop("-80px", "-100px");
  } else if (window.scrollY >= 111) {
    manipulateBackToTop("0px", "0px");
  }
}

window.addEventListener("scroll", determineBackToTop);
backToTopBtn.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
