/*

    This script is for the search field

*/

var searchI;
const searchField = document.getElementById("navSearchInput");
const searchGo = document.getElementById("navSearchSubmit");
const searchResults = document.getElementById("navSearchResults");
searchResults.classList.toggle("deactive");

function manipulateSearchResults(state) {
  if (state == false) {
    searchResults.classList.toggle("deactive");
  } else if (state == true) {
    searchResults.classList.remove("deactive");
  }
}

function filterSearchResults() {
  let filter;
  filter = searchField.value.toUpperCase();

  const searchResult = searchResults.getElementsByTagName("li");
  let searchResultLink;

  for (searchI = 0; searchI < searchResult.length; searchI++) {
    searchResultLink = searchResult[searchI].getElementsByTagName("a")[0];

    const searchResultTxt =
      searchResultLink.textContent || searchResultLink.innerText;

    if (searchResultTxt.toUpperCase().indexOf(filter) > -1) {
      searchResult[searchI].style.display = "block";
    } else {
      searchResult[searchI].style.display = "none";
    }
  }
}

function rerouteLinks(link) {
  window.location.href = link;
}

function rerouteSearchFieldTxt(link) {
  const rerouteValue = searchField.value.toLowerCase();
  switch (true) {
    case rerouteValue.indexOf("home") > -1:
      link = "index.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("index") > -1:
      link = "index.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("about") > -1:
      link = "about.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("red wines") > -1:
      link = "store.html#redW";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("white wines") > -1:
      link = "store.html#whiteW";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("sparkling wines") > -1:
      link = "store.html#sparklingW";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("rose wines") > -1:
      link = "store.html#roseW";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("privacy policy") > -1:
      link = "privacy.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("our team") > -1:
      link = "team.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("our socials") > -1:
      link = "socials.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("contact") > -1:
      link = "contact.html";
      rerouteLinks(link);
      break;
  }

  if (
    rerouteValue.indexOf("store") > -1 ||
    rerouteValue.indexOf("all wines") > -1
  ) {
    link = "store.html";
    rerouteLinks(link);
  }
}

// Events
window.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    rerouteSearchFieldTxt();
  }
});
searchField.addEventListener("click", () => {
  manipulateSearchResults(true);
});
searchField.addEventListener("blur", () => {
  manipulateSearchResults(false);
});
searchField.addEventListener("keyup", () => {
  filterSearchResults();
});
searchGo.addEventListener("click", () => {
  rerouteSearchFieldTxt();
});
