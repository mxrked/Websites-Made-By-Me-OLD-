/*

    This script is for the searchField

*/

// displaying the search field

var searchFieldTriggered = false;

const searchFielder = document.getElementById("searchField");
const searchToggle = document.getElementById("searchToggler");
const searchClose = document.getElementById("searchCloser");
const searchCnt = document.getElementById("searchContent");

function determineSearchFieldState() {
  if (
    (searchFielder.style.maxHeight = "100%" && searchFieldTriggered == true)
  ) {
    document.body.style.overflowY = "hidden";
  } else if (
    (searchFielder.style.maxHeight = "0" && searchFieldTriggered == false)
  ) {
    setTimeout(() => {
      document.body.style.overflowY = "auto";
    }, 700);
  }
}

stylizeSearchField("0", "hide");
function stylizeSearchField(mH, cnt) {
  searchFielder.style.maxHeight = mH;

  if (cnt == "show") {
    setTimeout(() => {
      searchFielder.style.overflowY = "auto";
    }, 400);
    setTimeout(() => {
      searchCnt.classList.remove("deactive");
    }, 1000);
  } else if (cnt == "hide") {
    searchFielder.style.overflowY = "hidden";
    searchCnt.classList.toggle("deactive");

    setTimeout(() => {
      document.body.style.overflowY = "auto";
    }, 600);
  }
}

searchToggle.addEventListener("click", () => {
  searchFieldTriggered = true;

  determineSearchFieldState();
  stylizeSearchField("100%", "show");
});

searchClose.addEventListener("click", () => {
  searchFieldTriggered = false;

  determineSearchFieldState();
  stylizeSearchField("0", "hide");
});

//
//

// search interaction

const searchFieldInput = document.getElementById("searchFieldInput");
const searchFieldGo = document.getElementById("searchGo");
const searchResultsList = document.getElementById("searchResults");

searchResultsList.classList.toggle("deactive");

searchFieldInput.addEventListener("click", () => {
  searchResultsList.classList.remove("deactive");
});
// hides the search results when the user clicks off searchInput
searchFieldInput.addEventListener("blur", () => {
  searchResultsList.classList.toggle("deactive");
});
searchFieldInput.addEventListener("keyup", grabSearchInput);
function grabSearchInput() {
  var searchI;
  let searchFilter;
  searchFilter = searchFieldInput.value.toUpperCase();

  const searchResult = searchResultsList.getElementsByTagName("li");
  let searchResultLink;

  for (searchI = 0; searchI < searchResult.length; searchI++) {
    searchResultLink = searchResult[searchI].getElementsByTagName("a")[0];

    const searchResultTxt =
      searchResultLink.textContent || searchResultLink.innerText;

    if (searchResultTxt.toUpperCase().indexOf(searchFilter) > -1) {
      searchResult[searchI].style.display = "block";
    } else {
      searchResult[searchI].style.display = "none";
    }
  }
}

const allSearchResults = document.querySelectorAll(".search-result");

allSearchResults.forEach((sr) => {
  sr.addEventListener("click", () => {
    stylizeSearchField("0", "hide");
  });
});

// this will determine what link the user clicks
function determineSearchResultClicked(link, txt) {
  link = document.getElementById(this);
  console.log(txt);
}

// makes it so when the user uses the tab button to go through result links, it wont hide the results
fixSearchResultFocus();
function fixSearchResultFocus() {
  const searchResultLinks = document.querySelectorAll(".search-result");

  searchResultLinks.forEach((link) => {
    link.addEventListener("focus", () => {
      searchResultsList.classList.remove("deactive");
    });
    link.addEventListener("blur", () => {
      searchResultsList.classList.toggle("deactive");
    });
  });
}

// this will check what input value was entered and will route the user to the respected page

function checkSearchInput() {
  const searchFieldValue = searchFieldInput.value;
  if (searchFieldValue.toLowerCase().indexOf("home") > -1) {
    console.log("Home was entered.");
    window.location.href = "index.html";
  }
  if (searchFieldValue.toLowerCase().indexOf("wines") > -1) {
    console.log("Wines was entered.");
    window.location.href = "wines.html";
  }
  if (searchFieldValue.toLowerCase().indexOf("red") > -1) {
    console.log("Red Wines was entered.");
    window.location.href = "wines.html#red";
    everyThingRed();
  }
  if (searchFieldValue.toLowerCase().indexOf("white") > -1) {
    console.log("White Wines was entered.");
    window.location.href = "wines.html#white";
    everyThingWhite();
  }
  if (searchFieldValue.toLowerCase().indexOf("rose") > -1) {
    console.log("Rose Wines was entered.");
    window.location.href = "wines.html#rose";
    everyThingRose();
  }
  if (searchFieldValue.toLowerCase().indexOf("sparkling") > -1) {
    console.log("Sparkling Wines was entered.");
    window.location.href = "wines.html#sparkling";
    everyThingSparkling();
  }
  if (searchFieldValue.toLowerCase().indexOf("about") > -1) {
    console.log("About was entered.");
    window.location.href = "about.html";
  }
  if (searchFieldValue.toLowerCase().indexOf("contact") > -1) {
    console.log("Contact was entered.");
    window.location.href = "contact.html";
  }
}

// user presses enter button, will display a log and redirect
searchFieldInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    checkSearchInput();
    stylizeSearchField("0", "hide");
    hideWineTypes();
  }
});
// user clicks the go button, will display a log and redirect
searchFieldGo.addEventListener("click", () => {
  checkSearchInput();
  stylizeSearchField("0", "hide");
  hideWineTypes();
});
