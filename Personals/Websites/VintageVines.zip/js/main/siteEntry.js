/*

    This script is for the site entry

*/

document.body.style.overflowY = "hidden";

const siteEntry = document.getElementById("siteEntry");
const siteEntryN = document.getElementById("siteEN");
const siteEntryY = document.getElementById("siteEY");

siteEntry.style.display = "none";
siteEntry.classList.toggle("deactive");

function triggerSiteEntry() {
  setTimeout(() => {
    siteEntry.style.display = "grid";
  }, 400);

  setTimeout(() => {
    siteEntry.classList.remove("deactive");
  }, 600);
}

checkSiteEntryVisit();
function checkSiteEntryVisit() {
  if (sessionStorage.getItem(siteEntry) !== "true") {
    triggerSiteEntry();
  } else {
    document.body.style.overflowY = "auto";
  }
}

function closeSiteEntry() {
  siteEntry.classList.toggle("deactive");

  setTimeout(() => {
    siteEntry.style.display = "none";
  }, 500);
}

siteEntryY.addEventListener("click", () => {
  closeSiteEntry();
  sessionStorage.setItem(siteEntry, "true");
  siteEntryY.disabled = true;

  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 600);
});

siteEntryN.addEventListener("click", () => {
  window.history.back();
});
