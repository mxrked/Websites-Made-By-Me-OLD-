/*

    This script is for the indexGallery

*/

//* Checking for what img was clicked
const allIndexGalleryItems = document.querySelectorAll(".index-gallery-img");
function determineIndexImg(img) {
  switch (img) {
    case "1":
      console.log("Index Gallery Img 1 Clicked.");
      break;
    case "2":
      console.log("Index Gallery Img 2 Clicked.");
      break;
    case "3":
      console.log("Index Gallery Img 3 Clicked.");
      break;
    case "4":
      console.log("Index Gallery Img 4 Clicked.");
      break;
    case "5":
      console.log("Index Gallery Img 5 Clicked.");
      break;
    case "6":
      console.log("Index Gallery Img 6 Clicked.");
      break;
  }
}

//
//
//

//* Gallery Modal activations

var galleryModalOpen = false;
const galleryDarken = document.getElementById("galleryModalDarken");
galleryDarken.style.display = "none";
galleryDarken.classList.toggle("deactive");

var galleryI;
const allGalleryModals_Classes =
  document.getElementsByClassName("gallery-modal");
const allGalleryModals = document.querySelectorAll(".gallery-modal");

// this will hide all the modals and close the gallery darken at once
hideAllGalleryModals();
function hideAllGalleryModals() {
  for (galleryI = 0; galleryI < allGalleryModals_Classes.length; galleryI++) {
    allGalleryModals_Classes[galleryI].classList.toggle("deactive");
  }

  setTimeout(() => {
    for (galleryI = 0; galleryI < allGalleryModals_Classes.length; galleryI++) {
      allGalleryModals_Classes[galleryI].style.display = "none";
    }
  }, 600);

  galleryDarken.classList.remove("deactive");
  setTimeout(() => {
    galleryDarken.style.display = "none";
  }, 600);
}

// makes the modal close for all modal closers
const allGalleryClosers = document.querySelectorAll(".modal-closer-btn");
allGalleryClosers.forEach((closer) => {
  closer.addEventListener("click", () => {
    hideAllGalleryModals();
    galleryModalOpen = false;
    determineGalleryModalState();
  });
});

// this will determine what modal will be displayed
function determineGalleryModal(modal) {
  modal.style.display = "grid";
  setTimeout(() => {
    modal.classList.remove("deactive");
  }, 120);
}

function determineGalleryModalState() {
  if (galleryModalOpen == true) {
    document.body.style.overflowY = "hidden";
  } else {
    document.body.style.overflowY = "auto";
  }
}

// this is for all of the indexGallery imgs
allIndexGalleryItems.forEach((img) => {
  img.addEventListener("click", () => {
    galleryDarken.style.display = "block";
    setTimeout(() => {
      galleryDarken.classList.remove("deactive");
    }, 1300);
  });
});
allIndexGalleryItems.forEach((img) => {
  img.addEventListener("click", () => {
    galleryModalOpen = true;
    determineGalleryModalState();
  });
});
allIndexGalleryItems[0].addEventListener("click", () => {
  determineGalleryModal(allGalleryModals[0]);
});
allIndexGalleryItems[1].addEventListener("click", () => {
  determineGalleryModal(allGalleryModals[1]);
});
allIndexGalleryItems[2].addEventListener("click", () => {
  determineGalleryModal(allGalleryModals[2]);
});
allIndexGalleryItems[3].addEventListener("click", () => {
  determineGalleryModal(allGalleryModals[3]);
});
allIndexGalleryItems[4].addEventListener("click", () => {
  determineGalleryModal(allGalleryModals[4]);
});
allIndexGalleryItems[5].addEventListener("click", () => {
  determineGalleryModal(allGalleryModals[5]);
});
//TODO: The next gallery modals and items will start with 6

// when user clicks on the galleryDarken it closes the modal
window.onclick = function (e) {
  if (e.target === galleryDarken) {
    hideAllGalleryModals();
    galleryModalOpen = false;
    determineGalleryModalState();
  }
};
