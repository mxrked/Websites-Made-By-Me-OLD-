/*

    This script is for the page load fade ins for the index page

*/

const indexHides = document.getElementsByClassName("i-hide");
var indexI;

hideIndexHides();
function hideIndexHides() {
  for (indexI = 0; indexI < indexHides.length; indexI++) {
    indexHides[indexI].classList.toggle("deactive");
  }
}

// hero

const indexHero = document.getElementById("indexHero");
const indexHeroTextDiv = document.getElementById("indexHeroText");

function indexHeroFadeIns() {
  setTimeout(() => {
    indexHero.classList.remove("deactive");
  }, 600);

  setTimeout(() => {
    indexHeroTextDiv.classList.remove("deactive");
  }, 1100);
}

window.addEventListener("load", () => {
  indexHeroFadeIns();
});
