/*

    This script is for the indexHeroCnt h2 

*/

const indexHeroH2 = document.getElementById("indexHeroCntH2");
const iHeroH2Span = document.getElementById("iH2S");

function animateIHeroH2Span(spanW) {
  iHeroH2Span.style.width = spanW;
}

indexHeroH2.addEventListener("mouseenter", () => {
  animateIHeroH2Span("30%");
});
indexHeroH2.addEventListener("mouseleave", () => {
  animateIHeroH2Span("95%");
});
