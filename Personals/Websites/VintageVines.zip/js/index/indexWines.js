/*

    This script is for the indexWines

*/

var iWines;
const allIndexWinesTogglers = document.querySelectorAll(".i-wine-toggler");
const allIndexWineDown = document.querySelectorAll(".wine-type-down");
const allIndexWineUp = document.querySelectorAll(".wine-type-up");
const allIndexWineLists = document.querySelectorAll(".index-wine-type-list");
const allIndexWineListsCnts = document.querySelectorAll(
  ".index-wine-type-list-cnt"
);
const allIndexWineListLinks = document.getElementsByClassName(
  "index-wine-type-link"
);

function wineListResets() {
  hideIndexWineUp();
  hideIndexWineList();
}

hideIndexWineUp();
function hideIndexWineUp() {
  allIndexWineUp.forEach((up) => {
    up.style.display = "none";
  });
}
hideIndexWineLinks();
function hideIndexWineLinks() {
  for (iWines = 0; iWines < allIndexWineListLinks.length; iWines++) {
    allIndexWineListLinks[iWines].style.pointerEvents = "none";
  }
}

// styling the links when hovering/unhovering
createIndexWineLinksStyling();
function createIndexWineLinksStyling() {
  document.querySelectorAll(".index-wine-type-link").forEach((link) => {
    link.addEventListener("mouseenter", () => {
      link.style.backgroundColor = "rgba(48, 36, 42, 1)";
    });
    link.addEventListener("mouseleave", () => {
      link.style.backgroundColor = "ghostwhite";
    });
  });
}

// removing the disabled = true attributes
function enableIndexTogglers() {
  for (
    iWines = 0;
    iWines < document.getElementsByClassName("i-wine-toggler").length;
    iWines++
  ) {
    document.getElementsByClassName("i-wine-toggler")[iWines].disabled = false;
  }
}

// creating the animation slide down for the wine lists
hideIndexWineList();
function hideIndexWineList() {
  allIndexWineLists.forEach((list) => {
    list.style.maxHeight = "0";
  });
  allIndexWineListsCnts.forEach((cnt) => {
    cnt.style.opacity = 0;
  });
}

// the main function to trigger what list will be triggered
function toggleIndexWineList(up, down, list, cnt) {
  up.style.display = "none";
  down.style.display = "block";
  list.style.maxHeight = "100%";
  setTimeout(() => {
    cnt.style.opacity = 1;
  }, 500);
  setTimeout(() => {
    for (iWines = 0; iWines < allIndexWineListLinks.length; iWines++) {
      allIndexWineListLinks[iWines].style.pointerEvents = "auto";
    }
  }, 550);
}

// each button will reset the lists and disabled = false
allIndexWinesTogglers.forEach((toggler) => {
  toggler.addEventListener("click", () => {
    wineListResets();
    enableIndexTogglers();
  });
});

allIndexWinesTogglers[0].addEventListener("click", () => {
  setTimeout(() => {
    toggleIndexWineList(
      allIndexWineUp[0],
      allIndexWineDown[0],
      allIndexWineLists[0],
      allIndexWineListsCnts[0]
    );
    allIndexWinesTogglers[0].disabled = true;
  }, 140);
});
allIndexWinesTogglers[1].addEventListener("click", () => {
  setTimeout(() => {
    toggleIndexWineList(
      allIndexWineUp[1],
      allIndexWineDown[1],
      allIndexWineLists[1],
      allIndexWineListsCnts[1]
    );
    allIndexWinesTogglers[1].disabled = true;
  }, 140);
});
allIndexWinesTogglers[2].addEventListener("click", () => {
  setTimeout(() => {
    toggleIndexWineList(
      allIndexWineUp[2],
      allIndexWineDown[2],
      allIndexWineLists[2],
      allIndexWineListsCnts[2]
    );
    allIndexWinesTogglers[2].disabled = true;
  }, 140);
});
allIndexWinesTogglers[3].addEventListener("click", () => {
  setTimeout(() => {
    toggleIndexWineList(
      allIndexWineUp[3],
      allIndexWineDown[3],
      allIndexWineLists[3],
      allIndexWineListsCnts[3]
    );
    allIndexWinesTogglers[3].disabled = true;
  }, 140);
});
