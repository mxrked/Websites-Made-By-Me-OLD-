
<?php 

$vVEmail = 'contact@basicallyeasy.com';

    $msgA = 'Thank you for signing up to the Vintage Vines newsletter.';
    $msgB = 'Below is a link to my current Digital Portfolio and on it will display the current projects I have created.';
    $msgC = 'Here are my socials and how to contact me.';
    $msgContact = 'contact@basicallyeasy.com';
    $msgSocials = 'Twitter: '."\n".'https://twitter.com/Parker101P'."\n\n".'Facebook: '."\n".'https://www.facebook.com/parker.phelps.144/'."\n\n".'LinkedIn: '."\n".'https://www.linkedin.com/in/parker-phelps-a121501b6/'."\n\n".'GitHub: '."\n".'https://github.com/mxrked';


    $to = $_POST['newsLetterEmail'];
    $subject = 'Newsletter Signup - Vintage Vines';
    $message = $msgA."\n\n".$msgB."\n".'http://basicallyeasy.com'."\n\n".$msgC."\n".$msgContact."\n".$msgSocials; // add socials and such
    $headers = "From: ".$vVEmail;

    mail($to,$subject,$message,$headers);

    header("refresh:2;url=index.html");

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sending Newsletter Email...</title>
</head>
<body>
</body>
</html>