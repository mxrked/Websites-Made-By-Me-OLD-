
<?php 

    $userFN = $_POST['fName'];
    $userLN = $_POST['lName'];
    $userEmail = $_POST['emailAdd'];
    $userTel = $_POST['phoneNum'];
    $userMessage = $_POST['userMsg'];

    // sends to me
    $to = 'contact@basicallyeasy.com';
    $subject = 'Vintage Vines - Contact Form Submission.';
    $message = 'First Name: '.$userFN."\n\n".'Last Name: '.$userLN."\n\n".'Email Address: '.$userEmail."\n\n".'Phone Number: '.$userTel."\n\n".'Message: '.$userMessage;
    $headers = 'From: '.$_POST[emailAdd];
    
    // sends to user
    $to2 = $_POST['emailAdd'];
    $subject2 = 'Vintage Vines - Contact Form Sent Successfully!';
    $message2 = 'If you are seeing this email, then your contact form was sent successfully! Please wait while someone emails you back regarding your contact form!'."\n\n\n".'+1 (336) 831 3432'."\n".'contact@basicallyeasy.com'."\n".'Front End Developer\Designer'."\n".'Parker Phelps.';
    $headers2 = 'From: '.$to;

    mail($to,$subject,$message,$headers); // sends to me
    mail($to2,$subject2,$message2,$headers2); // sends to user


    header("refresh:2;url=contact.html");

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sending Contact Form Email...</title>
</head>
<body>
</body>
</html>