<!-- 

    This script will be used to send an email to the host and sender from the Contact Form

-->


<?php


    if (isset($_POST['submit'])) {

        $contactInfo = "Parker Phelps"."\n"."Front End Developer"."\n"."+13368313432";

        $cFirstName = $_POST['userFN'];
        $cLastName = $_POST['userLN'];
        $cEmail = $_POST['userEmail'];
        $cPhone = $_POST['userPhone'];
        $cMessage = $_POST['userMessage'];

        $to="contact@basicallyeasy.com"; // Receiver Email ID, Replace with your email ID
		$subject="Sharp Quill - Contact Form Submission";
        $message = "First Name: ".$cFirstName."\n\n"."Last Name: ".$cLastName."\n\n"."Email Address: ".$cEmail."\n\n"."Phone Number: ".$cPhone."\n\n"."Message: ".$cMessage;
        $headers = "From: ".$cEmail;

        $subject2 = "Sharp Quill - Contact Form Was Sent Successfully!";
        $message2 = "Here is a copy of your message. "."\n\n"."First Name: ".$cFirstName."\n\n"."Last Name: ".$cLastName."\n\n"."Email Address: ".$cEmail."\n\n"."Phone Number: ".$cPhone."\n\n"."Message: ".$cMessage."\n\n\n"."We will contact you back shortly!"."\n\n\n\n".$contactInfo;
        $headers2 = "From: ".$to;

        mail($to,$subject,$message,$headers);
        mail($from,$subject2,$message2,$headers2);
        header('Location: contact.html');


    }

    /* 
    
        CROSS YOUR FINGERS!
    
    */

?>