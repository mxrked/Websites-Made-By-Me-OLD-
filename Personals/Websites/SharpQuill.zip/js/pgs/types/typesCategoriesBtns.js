/*

    This script is for the typesCategories btns

*/

var typeCatI;
const allTypeCatBtns = document.querySelectorAll(".type-cat-btn");

// This will be used to fully reset the btns
function resetTypeCatBtns() {
  const resettingTypeCatBtns = document.getElementsByClassName("type-cat-btn");
  for (typeCatI = 0; typeCatI < resettingTypeCatBtns.length; typeCatI++) {
    resettingTypeCatBtns[typeCatI].style.opacity = ".6";
    resettingTypeCatBtns[typeCatI].disabled = false;
  }
}

// This will be used to stylize the btn
function styleTypeCatBtns(btn, num) {
  resetTypeCatBtns();
  setTimeout(() => {
    btn.style.opacity = "1";
    btn.disabled = true;
  }, 100);
  checkingTypeCatBtnNum(num);
}

// This will be used to keep the btns style when the user refreshes
function keepTypeCatBtnStyle(btn) {
  allTypeCatBtns[btn].style.opacity = "1";
  allTypeCatBtns[btn].disabled = true;
}

// This will be used to add a hash based on what btn/link the user presses
function addTypeCatBtnHash(route) {
  window.location.hash = "#" + route;
}

// This will check the number that was applied when the user clicked on a specific btn and then will add a hash link based off that specific btn
function checkingTypeCatBtnNum(num) {
  switch (num) {
    case 1:
      addTypeCatBtnHash("allTypes");
      checkingTypeCatBtnHashes();
      break;
    case 2:
      addTypeCatBtnHash("atelerix");
      checkingTypeCatBtnHashes();
      break;
    case 3:
      addTypeCatBtnHash("erinaceus");
      checkingTypeCatBtnHashes();
      break;
    case 4:
      addTypeCatBtnHash("hemiechinus");
      checkingTypeCatBtnHashes();
      break;
    case 5:
      addTypeCatBtnHash("mesechinus");
      checkingTypeCatBtnHashes();
      break;
    case 6:
      addTypeCatBtnHash("paraechinus");
      checkingTypeCatBtnHashes();
      break;
  }
}

const allTypesItems = document.getElementsByClassName("types-category-item");
const atelerixTypesItems = document.getElementsByClassName("atelerix-item");
const erinaceusTypesItems = document.getElementsByClassName("erinaceus-item");
const hemiechinusTypesItems =
  document.getElementsByClassName("hemiechinus-item");
const mesechinusTypesItems = document.getElementsByClassName("mesechinus-item");
const paraechinusTypesItems =
  document.getElementsByClassName("paraechinus-item");

// This will be used to check the url hash links and will determine what set of cat items will be displayed, this will also allow the user to refresh and keep the btn styling
function checkingTypeCatBtnHashes() {
  const checkingTypeCatHash = window.location.hash;
  if (checkingTypeCatHash.indexOf("allTypes") > -1) {
    showTypeItems(allTypesItems);
    keepTypeCatBtnStyle(0);
  }
  if (checkingTypeCatHash.indexOf("atelerix") > -1) {
    showTypeItems(atelerixTypesItems);
    keepTypeCatBtnStyle(1);
  }
  if (checkingTypeCatHash.indexOf("erinaceus") > -1) {
    showTypeItems(erinaceusTypesItems);
    keepTypeCatBtnStyle(2);
  }
  if (checkingTypeCatHash.indexOf("hemiechinus") > -1) {
    showTypeItems(hemiechinusTypesItems);
    keepTypeCatBtnStyle(3);
  }
  if (checkingTypeCatHash.indexOf("mesechinus") > -1) {
    showTypeItems(mesechinusTypesItems);
    keepTypeCatBtnStyle(4);
  }
  if (checkingTypeCatHash.indexOf("paraechinus") > -1) {
    showTypeItems(paraechinusTypesItems);
    keepTypeCatBtnStyle(5);
  }
}

// This will be used to hide all of the other cat type items
function hideTypeCatItems() {
  const hidingTypeCatItems = document.getElementsByClassName(
    "types-category-item"
  );
  for (typeCatI = 0; typeCatI < hidingTypeCatItems.length; typeCatI++) {
    hidingTypeCatItems[typeCatI].style.height = "0px";
  }
  setTimeout(() => {
    for (typeCatI = 0; typeCatI < hidingTypeCatItems.length; typeCatI++) {
      hidingTypeCatItems[typeCatI].style.display = "none";
    }
  }, 300);
}

// This will be used to display the specific cat type items
function showTypeItems(type) {
  hideTypeCatItems();
  setTimeout(() => {
    for (typeCatI = 0; typeCatI < type.length; typeCatI++) {
      type[typeCatI].style.display = "block";
    }
  }, 300);
  setTimeout(() => {
    for (typeCatI = 0; typeCatI < type.length; typeCatI++) {
      type[typeCatI].style.height = "400px";
    }
  }, 600);
}

allTypeCatBtns[0].addEventListener("click", () => {
  styleTypeCatBtns(allTypeCatBtns[0], 1);
});
allTypeCatBtns[1].addEventListener("click", () => {
  styleTypeCatBtns(allTypeCatBtns[1], 2);
});
allTypeCatBtns[2].addEventListener("click", () => {
  styleTypeCatBtns(allTypeCatBtns[2], 3);
});
allTypeCatBtns[3].addEventListener("click", () => {
  styleTypeCatBtns(allTypeCatBtns[3], 4);
});
allTypeCatBtns[4].addEventListener("click", () => {
  styleTypeCatBtns(allTypeCatBtns[4], 5);
});
allTypeCatBtns[5].addEventListener("click", () => {
  styleTypeCatBtns(allTypeCatBtns[5], 6);
});

document.querySelectorAll(".types-link").forEach((link) => {
  link.addEventListener("click", () => {
    checkingTypeCatBtnHashes();
  });
});
window.addEventListener("load", () => {
  checkingTypeCatBtnHashes();
});
