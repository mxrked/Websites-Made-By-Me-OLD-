/*

    This script is for storing the typesModalTogglers

*/

// Atelerix
typesTogglers[0].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[0]);
  }, 400);
});

typesTogglers[1].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[1]);
  }, 400);
});

typesTogglers[2].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[2]);
  }, 400);
});

typesTogglers[3].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[3]);
  }, 400);
});

// Erinaceus
typesTogglers[4].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[4]);
  }, 400);
});

typesTogglers[5].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[5]);
  }, 400);
});

typesTogglers[6].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[6]);
  }, 400);
});

typesTogglers[7].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[7]);
  }, 400);
});

// Hemiechinus
typesTogglers[8].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[8]);
  }, 400);
});

typesTogglers[9].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[9]);
  }, 400);
});

// Mesechinus
typesTogglers[10].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[10]);
  }, 400);
});

typesTogglers[11].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[11]);
  }, 400);
});

typesTogglers[12].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[12]);
  }, 400);
});

// Paraechinus
typesTogglers[13].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[13]);
  }, 400);
});

typesTogglers[14].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[14]);
  }, 400);
});

typesTogglers[15].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[15]);
  }, 400);
});

typesTogglers[16].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[16]);
  }, 400);
});
