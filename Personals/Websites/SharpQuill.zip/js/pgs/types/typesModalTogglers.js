/*

    This script is for storing the typesModalTogglers

*/

// Atelerix
typesTogglers[0].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[0]);
  }, 400);
});

typesTogglers[1].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[1]);
  }, 400);
});

typesTogglers[2].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[2]);
  }, 400);
});

typesTogglers[3].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[3]);
  }, 400);
});
