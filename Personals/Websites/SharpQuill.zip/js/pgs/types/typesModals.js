/*

    This script is for the types page modals

*/

const typesDarken = document.getElementById("typesModalDarken");
typesDarken.style.display = "none";
typesDarken.classList.toggle("deactive");

const typesModals = document.querySelectorAll(".types-modal");
const typesTogglers = document.querySelectorAll(".types-modal-toggler");

// This will be used to hide all the modals
function hideTypeModals() {
  typesDarken.style.pointerEvents = "none";
  const hidingTypeModals = document.getElementsByClassName("types-modal");
  for (typeCatI = 0; typeCatI < hidingTypeModals.length; typeCatI++) {
    hidingTypeModals[typeCatI].style.opacity = "0";
  }
  setTimeout(() => {
    for (typeCatI = 0; typeCatI < hidingTypeModals.length; typeCatI++) {
      hidingTypeModals[typeCatI].style.display = "none";
    }
  }, 500);
}

// Each toggler will do a specific thing
typesTogglers.forEach((toggler) => {
  toggler.addEventListener("click", () => {
    document.body.style.overflowY = "hidden";
    hideTypeModals();
    typesDarken.style.display = "block";
    setTimeout(() => {
      typesDarken.classList.remove("deactive");
    }, 300);
  });
});

// This will be used to display a specific modal
function displayTypesModal(modal) {
  setTimeout(() => {
    modal.style.display = "grid";
  }, 160);
  setTimeout(() => {
    modal.style.opacity = "1";
  }, 300);
  setTimeout(() => {
    typesDarken.style.pointerEvents = "auto";
  }, 800);
}

window.addEventListener("load", () => {
  hideTypeModals();
});
typesTogglers[0].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[0]);
  }, 400);
});
typesTogglers[1].addEventListener("click", () => {
  setTimeout(() => {
    displayTypesModal(typesModals[1]);
  }, 400);
});

// This will be used to close a modal and remove the dark layer
function closingModal() {
  hideTypeModals();
  typesDarken.classList.toggle("deactive");
  document.body.style.overflowY = "auto";
}

document.querySelectorAll(".close-types-modal").forEach((closer) => {
  closer.addEventListener("click", closingModal);
});

// Closes if user clicks darken layer
window.addEventListener("click", (e) => {
  if (e.target == typesDarken) {
    closingModal();
  }
});
