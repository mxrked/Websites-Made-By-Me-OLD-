/*

    This script is for the search field

*/
//? Prevents user from using tab btn (this will mess up the search list)
function tabBtnManip(state) {
  document.onkeydown = function (e) {
    if (e.key == "Tab") {
      return state;
    }
  };
}
tabBtnManip(false);

const searchField = document.getElementById("navInput");
const searchResults = document.getElementById("searchResults");
searchResults.classList.toggle("deactive");

searchField.addEventListener("click", () => {
  searchResults.classList.remove("deactive");
});

searchField.addEventListener("blur", () => {
  searchResults.classList.toggle("deactive");
});

//? This will filter out the different links based on user input
searchField.addEventListener("keyup", () => {
  var searchI;
  let filter;
  filter = searchField.value.toUpperCase();
  const searchResult = searchResults.getElementsByTagName("li");
  let searchResultLink;

  for (searchI = 0; searchI < searchResult.length; searchI++) {
    searchResultLink = searchResult[searchI].getElementsByTagName("a")[0];

    const searchResultTxt =
      searchResultLink.textContent || searchResultLink.innerText;

    if (searchResultTxt.toUpperCase().indexOf(filter) > -1) {
      searchResult[searchI].style.display = "block";
    } else {
      searchResult[searchI].style.display = "none";
    }
  }
});

//? This will determine what link the user clicks on
function determineSFLinks(link, txt) {
  link = document.getElementById(this);
  console.log(`${txt} was clicked.`);
}

//? This will determine what the user inputs and will allow reroute
function grabSFText(txt, reroute) {
  const grabSFCLTxt = "was entered.";
  const searchFieldValue = searchField.value.toLowerCase();
  //* Main Pages
  if (searchFieldValue.indexOf("home") > -1) {
    txt = "Home";
    reroute = "index.html";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("about") > -1) {
    txt = "About";
    reroute = "about.html";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("adoption") > -1) {
    txt = "Adoption";
    reroute = "adopt.html";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("contact") > -1) {
    txt = "Contact Us";
    reroute = "contact.html";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("bubba") > -1) {
    txt = "Bubba";
    reroute = "bubba.html";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }

  //* Types
  if (searchFieldValue.indexOf("atelerix") > -1) {
    txt = "Atelerix";
    reroute = "types.html#atelerix";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("erinaceus") > -1) {
    txt = "Erinaceus";
    reroute = "types.html#erinaceus";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("hemiechinus") > -1) {
    txt = "Hemiechinus";
    reroute = "types.html#hemiechinus";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("mesechinus") > -1) {
    txt = "Mesehcinus";
    reroute = "types.html#mesechinus";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
  if (searchFieldValue.indexOf("paraechinus") > -1) {
    txt = "Paraechinus";
    reroute = "types.html#paraechinus";
    console.log(`${txt} ${grabSFCLTxt}`);
    window.location.href = reroute;
  }
}

//? This will reroute the user based on what they input after they press the enter btn
searchField.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    grabSFText();
  }
});
