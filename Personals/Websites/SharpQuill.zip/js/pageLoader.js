/*

    This script is for the pageLoader

*/

const pageLoader = document.getElementById("pageLoader");
const pageLoaderCnt = document.getElementById("pageLoaderCnt");
const blankOL = document.getElementById("blankOverlay");

var pageLoaderState = false;
document.body.style.overflowY = "hidden";

window.addEventListener("load", () => {
  pageLoaderState = true;
  checkPageLoaderState();
});

function checkPageLoaderState() {
  if ((pageLoaderState = true)) {
    pageLoaderCnt.classList.toggle("deactive");

    setTimeout(() => {
      pageLoader.style.height = "0";
    }, 500);

    setTimeout(() => {
      blankOL.classList.toggle("deactive");
      document.body.style.overflowY = "auto";
    }, 1500);
  }
}
