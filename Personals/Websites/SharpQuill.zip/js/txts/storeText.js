/*

    This script is for storing all of the text for the store products and store page (This is for easy changing)

*/

const storeProductTexts = document.querySelectorAll(".product-text");
const storeTexts = document.querySelectorAll(".store-text");

const storeProductTextsCnts = [
  {
    item: "Food",
    txt: "Popular Hedgehog formula that provides a healthy diet and great taste.",
  },
  {
    item: "Cage",
    txt: "Created as perfect housing for your adorable hedgehog.",
  },
  {
    item: "Toy",
    txt: "Allows your hedgehog to have some fun inside or outside of the cage.",
  },
  {
    item: "Wheel",
    txt: "Enjoy knowing that your hedgehog will stay in shape and will have fun doing so.",
  },
];

storeProductTexts[0].innerHTML = storeProductTextsCnts[0].txt;
storeProductTexts[1].innerHTML = storeProductTextsCnts[1].txt;
storeProductTexts[2].innerHTML = storeProductTextsCnts[2].txt;
storeProductTexts[3].innerHTML = storeProductTextsCnts[3].txt;
