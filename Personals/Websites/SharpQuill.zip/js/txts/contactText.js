/*

    This script is for storing all of the text for the contact page (This is for easy changing)

*/

contactTextStorage();
function contactTextStorage() {
  const contactTextCnts = [
    {
      txt: "Send us some feedback or just ask a question regarding SharpQuill.",
    },
  ];

  const contactTexts = document.querySelectorAll(".contact-text");
  contactTexts[0].innerHTML = contactTextCnts[0].txt;
}
