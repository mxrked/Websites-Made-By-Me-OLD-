/*

    This script is for storing all of the text for the bubba page (This is for easy changing)

*/

bubbaTextStorage();
function bubbaTextStorage() {
  const bubbaTextCnts = [
    {
      txt: "We dedicate this website in the memory of Bubba the hedgehog. See you in the skies little guy.",
    },
    {
      txt: "Bubba was seen not only as one of the best pets a person could ever ask for but he was greatly seen as a member of my family and the loss of him felt like the loss of a family member.",
    },
    {
      txt: "Bubba was introduced to our family back in 2016 when my sister had decided she wanted a hedgehog as a pet and after obtaining and caring for Bubba up until his passing every memory and second spent with him has always and will stick with us.",
    },
    {
      txt: "Bubba had a gentle soul the meaning that he never had any will of hurting anyone and he thus never did hurt anyone. He did poop and peed on them, however...",
    },
    {
      txt: "Bubba was willing to comfort those who were needing of comfort. He would love to cuddle up to either me or my sister to the point he would try to run up my shirt and I would have to get him out.",
    },
    {
      txt: "Bubba was one of the best things to come out of the last 5 years and his passing has been a difficult one and he will be remembered as being a fighter and a legend.",
    },
    {
      txt: "Rest In Peace Bubba the Hedgehog, 2016 - 2021.",
    },
  ];

  const bubbaTexts = document.querySelectorAll(".bubba-text");
  bubbaTexts[0].innerHTML = bubbaTextCnts[0].txt;

  // Memory 1
  bubbaTexts[1].innerHTML = bubbaTextCnts[1].txt;
  bubbaTexts[2].innerHTML = bubbaTextCnts[2].txt;

  // Memory 2
  bubbaTexts[3].innerHTML = bubbaTextCnts[3].txt;
  bubbaTexts[4].innerHTML = bubbaTextCnts[4].txt;

  // Memory 3
  bubbaTexts[5].innerHTML = bubbaTextCnts[5].txt;
  bubbaTexts[6].innerHTML = bubbaTextCnts[6].txt;
}
