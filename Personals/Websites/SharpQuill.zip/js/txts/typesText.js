/*

    This script is for storing all of the text for the types page (This is for easy changing)

*/

const typesTextCnt = [
  {
    txt: "There are a total of 17 different species of hedgehog, all splited up into 5 different sub categories.",
  },
  {
    name: "Four Toed",
    txt: "Populations tend to be scattered between suitable savannah or cropland habitats, avoiding forested areas. The species common name is derived from the number of toes found on its hind feet.",
  },
  {
    name: "North African",
    txt: "The North African hedgehog (Atelerix algirus) or Algerian hedgehog, is a mammal species in the family Erinaceidae native to Algeria, Libya, Malta, Morocco, Spain, and Tunisia. Little is known about this hedgehog, even though the most common breed of domesticated hedgehogs.",
  },
];

const typesText = document.querySelectorAll(".types-text");

// Top Text
typesText[0].innerHTML = typesTextCnt[0].txt;

// Atelerix
typesText[1].innerHTML = typesTextCnt[1].txt;
typesText[2].innerHTML = typesTextCnt[2].txt;
