/*

    This script is for storing all of the text for the types page (This is for easy changing)

*/

const typesTextCnt = [
  {
    txt: "There are a total of 17 different species of hedgehog, all splited up into 5 different sub categories.",
  },
];

const typesText = document.querySelectorAll(".types-text");

typesText[0].innerHTML = typesTextCnt[0].txt;
