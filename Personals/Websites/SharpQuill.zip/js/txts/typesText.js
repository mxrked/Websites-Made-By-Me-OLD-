/*

    This script is for storing all of the text for the types page (This is for easy changing)

*/

// Types Text
typesTextStorage();
function typesTextStorage() {
  const typesTextCnt = [
    {
      txt: "There are a total of 17 different species of hedgehog, all split up into 5 different subcategories.",
    },
  ];

  const typesText = document.querySelectorAll(".types-text");

  typesText[0].innerHTML = typesTextCnt[0].txt;
}

// Atelerix
atelerixTextStorage();
function atelerixTextStorage() {
  const atelerixTextCnt = [
    {
      name: "Four Toed",
      txt: "Populations tend to be scattered between suitable savannah or cropland habitats, avoiding forested areas. The species common name is derived from the number of toes found on its hind feet.",
    },
    {
      name: "North African",
      txt: "The North African hedgehog (Atelerix algirus) or Algerian hedgehog, is a mammal species in the family Erinaceidae native to Algeria, Libya, Malta, Morocco, Spain, and Tunisia. Little is known about this hedgehog, even though the most common breed of domesticated hedgehogs.",
    },
    {
      name: "Somali",
      txt: "The Somali hedgehog (Atelerix sclateri) is a species of mammal in the family Erinaceidae. It is endemic to Somalia. The Somali hedgehog is nocturnal.",
    },
    {
      name: "Southern African",
      txt: "The Southern African hedgehog (Atelerix frontalis) is a species of mammal in the family Erinaceidae. It is found in Angola, Botswana, Lesotho, Namibia, South Africa, Tanzania and Zimbabwe.",
    },
  ];

  const atelerixText = document.querySelectorAll(".atelerix-text");
  atelerixText[0].innerHTML = atelerixTextCnt[0].txt;
  atelerixText[1].innerHTML = atelerixTextCnt[1].txt;
  atelerixText[2].innerHTML = atelerixTextCnt[2].txt;
  atelerixText[3].innerHTML = atelerixTextCnt[3].txt;
}
// Erinaceus
erinaceusTextStore();
function erinaceusTextStore() {
  const erinaceusTextCnt = [
    {
      name: "Amur",
      txt: "The Amur hedgehog (Erinaceus amurensis), also called the Manchurian hedgehog, is a hedgehog similar to the European hedgehog in appearance and behaviour, although it is more lightly coloured. It is native to Amur Oblast and Primorye in Russia, Manchuria in China, and the Korean Peninsula.",
    },
    {
      name: "European",
      txt: "The European hedgehog (Erinaceus europaeus), also known as the West European hedgehog or common hedgehog, is a hedgehog species found in Europe, from Iberia and Italy northwards into Scandinavia. It is a generally common and widely distributed species that can survive across a wide range of habitat types.",
    },
    {
      name: "Northern White Breasted",
      txt: "The range of the species extends in the west as far as Poland, Austria and the former Yugoslavia, and south to Greece and the Adriatic Islands, including populations on Crete, Corfu and Rhodes. It is found eastwards through Russia and Ukraine, as far east as the Ob River in Siberia",
    },
    {
      name: "Southern White Breasted",
      txt: "The southern white-breasted hedgehog (Erinaceus concolor), sometimes referred to as white-bellied hedgehog or white-chested hedgehog, is a hedgehog native to Eastern Europe and Southwestern Asia. It is very similar in lifestyle and appearance to the European hedgehog (E. europaeus), but the former has a white spot on its chest.",
    },
  ];

  const erinaceusText = document.querySelectorAll(".erinaceus-text");
  erinaceusText[0].innerHTML = erinaceusTextCnt[0].txt;
  erinaceusText[1].innerHTML = erinaceusTextCnt[1].txt;
  erinaceusText[2].innerHTML = erinaceusTextCnt[2].txt;
  erinaceusText[3].innerHTML = erinaceusTextCnt[3].txt;
}
// Hemiechinus
hemiechinusTextStore();
function hemiechinusTextStore() {
  const hemiechinusTextCnt = [
    {
      name: "Indian Long Eared",
      txt: "The Indian long-eared hedgehog is a relatively small hedgehog (~17 cm, 200–500 grams). It is a nocturnal animal that is often found inhabiting burrows. Similar to most hedgehogs it has spines on its back, embedded into a muscle sheath. This sheath forms a bag-like structure that the animal can hide inside for protection. It can also erect its spines to further protect from predators.",
    },
    {
      name: "Long Eared",
      txt: "The long-eared hedgehog (Hemiechinus auritus) is a species of hedgehog native to Central Asian countries and some countries of the Middle East. The long-eared hedgehog lives in burrows that it either makes or finds and is distinguished by its long ears. It is considered one of the smallest Middle Eastern hedgehogs. This hedgehog is insectivorous but may also feed on small vertebrates and plants.",
    },
  ];

  const hemiechinusText = document.querySelectorAll(".hemiechinus-text");
  hemiechinusText[0].innerHTML = hemiechinusTextCnt[0].txt;
  hemiechinusText[1].innerHTML = hemiechinusTextCnt[1].txt;
}

// Mesechinus
mesechinusTextStorage();
function mesechinusTextStorage() {
  const mesechinusTextCnt = [
    {
      name: "Daurian",
      txt: 'The Daurian hedgehog (Mesechinus dauuricus) is a solitary small hedgehog. It is listed in the Red book of Russian Federation as a protected species with an unclear status, generally considered to be endangered, although the IUCN lists it as "least concern". It populates the Transbaikal region of Russia (this region is sometimes called Dauria, hence the name) and Northern Mongolia.',
    },
    {
      name: "Gaoligong Forest",
      txt: "The Gaoligong forest hedgehog (Mesechinus wangi) or Wangs forest hedgehog is a species of hedgehog in the family Erinaceidae found only in China. It is endemic to the slopes of Mt. Gaoligong in the Yunnan Province, where it lives in subtropical evergreen broad-leaved forest at elevations between 2200 m and 2680 m. This distribution is disjunct from that of the other species in this genus.",
    },
    {
      name: "Hugh's",
      txt: "Hugh's hedgehog (Mesechinus hughi), also sometimes referred to as the central Chinese hedgehog, is native to central China and Manchuria. It prefers open areas of dry steppe, but can be found in shrubland and forests. It is known to look for food even in daytime on rainy days.",
    },
  ];

  const mesechinusText = document.querySelectorAll(".mesechinus-text");
  mesechinusText[0].innerHTML = mesechinusTextCnt[0].txt;
  mesechinusText[1].innerHTML = mesechinusTextCnt[1].txt;
  mesechinusText[2].innerHTML = mesechinusTextCnt[2].txt;
}
// Paraechinus
paraechinusTextStorage();
function paraechinusTextStorage() {
  const paraechinusTextCnt = [
    {
      name: "Bare Bellied",
      txt: "The bare-bellied hedgehog (Paraechinus nudiventris), also known as the Madras hedgehog, is a species of hedgehog that is endemic to dry arid regions and scrubby jungles in southeastern India. As it was believed to be rare, it was formerly listed as Vulnerable by the IUCN. It is now known to be locally common in the Indian states of Andhra Pradesh and Tamil Nadu, resulting in its new listing as a species of Least Concern.",
    },
    {
      name: "Brandt's",
      txt: "Brandt's hedgehog is approximately the size of the West European hedgehog (about 500–1,000 g in weight and 25 cm in length), but has distinctively large ears (similar to the long-eared hedgehog), and is a much faster runner, due to lighter needle protection. Unlike the long-eared hedgehog, however, it is predominantly nocturnal.",
    },
    {
      name: "Desert",
      txt: "The desert hedgehog is one of the smallest of hedgehogs. It is 5.5 to 11 inches (140 to 280 mm) long and weighs about 10 to 18 ounces (280 to 510 g). The spines (or quills to give their correct name) on its back can be banded with coloring similar to the four-toed hedgehog. It is usually identified by its dark muzzle. If desert hedgehogs are threatened, their muscles go tight and pull the outer layer of skin around the body, making their quills stick out in all directions.",
    },
    {
      name: "Indian",
      txt: "The Indian hedgehog can be compared to the long-eared hedgehog (Hemiechinus auritus) which has a similar lifestyle and appearance. It is known for its masked face, dark with a white top, somewhat similar to a raccoon. It is relatively small with the adult male weighing about 435 grams and the adult female about 312. They are quite fast, although not as fast as the long-eared hedgehog.",
    },
  ];

  const paraechinusText = document.querySelectorAll(".paraechinus-text");
  paraechinusText[0].innerHTML = paraechinusTextCnt[0].txt;
  paraechinusText[1].innerHTML = paraechinusTextCnt[1].txt;
  paraechinusText[2].innerHTML = paraechinusTextCnt[2].txt;
  paraechinusText[3].innerHTML = paraechinusTextCnt[3].txt;
}
