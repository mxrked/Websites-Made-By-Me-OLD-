/*

    This script is for storing all of the text for the about page (This is for easy changing)

*/

const aboutTexts = document.querySelectorAll(".about-text");
aboutTextStorage();
function aboutTextStorage() {
  const aboutTextCnts = [
    {
      txt: "Learn our history and goals. Stick with us, things will only get better for hedgehogs.",
    },
    {
      txt: "We here at SharpQuill have devoted our time and research to learn more about the loveable creature known as the Hedgehog. What started as an interest has now turned into a loving and caring desire to know more about these animals, We have been wanting to get more familiar with hedgehogs ever since we first laid our eyes upon the cute little critters.",
    },
    {
      txt: "With your help, we can learn more about hedgehogs and can help prevent certain diseases from being transmitted and affecting these poor little guys.",
    },
    {
      txt: "To bring love to all things hedgehog related.",
    },
    {
      txt: "Teach others the understanding and caring of hedgehogs.",
    },
    {
      txt: "Help medical research for hedgehogs.",
    },
  ];

  aboutTexts[0].innerHTML = aboutTextCnts[0].txt;
  aboutTexts[1].innerHTML = aboutTextCnts[1].txt;
  aboutTexts[2].innerHTML = aboutTextCnts[2].txt;
  aboutTexts[3].innerHTML = aboutTextCnts[3].txt;
  aboutTexts[4].innerHTML = aboutTextCnts[4].txt;
  aboutTexts[5].innerHTML = aboutTextCnts[5].txt;
}
