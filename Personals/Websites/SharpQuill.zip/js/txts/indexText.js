/*

    This script is for storing all of the text for the index page (This is for easy changing)

*/

const indexTextCnts = [
  {
    txt: "We provide caring for your little guy with many hedgehog products.",
  },
  {
    txt: "There are a total of 17 different species of hedgehog, all splited up into 5 different sub categories.",
  },
  {
    txt: "All products are created for the sake of taking GREAT care of your hedgehog.",
  },
  {
    txt: "Go over the qualifications to be able to adopt your very own hedgehog and understanding the important rules when taking care the little guy.",
  },
  {
    txt: "Owner must provide valid proof of housing before applying for hedgehog adoption.",
  },
];

const indexTexts = document.querySelectorAll(".index-text");
indexTexts[0].innerHTML = indexTextCnts[0].txt;
indexTexts[1].innerHTML = indexTextCnts[1].txt;
indexTexts[2].innerHTML = indexTextCnts[2].txt;
indexTexts[3].innerHTML = indexTextCnts[3].txt;
indexTexts[4].innerHTML = indexTextCnts[4].txt;
