/*

    This script is for storing all of the text for the index page (This is for easy changing)

*/

const indexTextCnts = [
  {
    txt: "We provide caring for your little guy with many hedgehog products.",
  },
  {
    txt: "There are a total of 17 different species of hedgehog, all splited up into 5 different sub categories.",
  },
];

const indexTexts = document.querySelectorAll(".index-text");
indexTexts[0].innerHTML = indexTextCnts[0].txt;
indexTexts[1].innerHTML = indexTextCnts[1].txt;
