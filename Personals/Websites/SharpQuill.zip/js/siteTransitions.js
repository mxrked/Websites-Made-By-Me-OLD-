/*

    This script is for the site transitions (page-transition, full-second)

*/

mainSiteTransitionsInit();
function mainSiteTransitionsInit() {
  const pageTransitionItems = document.getElementsByClassName(
    "page-transition-item"
  );
  const fullSecondTransitionItems =
    document.getElementsByClassName("full-second-item");
  var siteTransitionsI;

  togglePageTransitions();
  function togglePageTransitions() {
    for (
      siteTransitionsI = 0;
      siteTransitionsI < pageTransitionItems.length;
      siteTransitionsI++
    ) {
      pageTransitionItems[siteTransitionsI].classList.toggle("page-transition");
    }
  }

  toggleFullSecondTransitions();
  function toggleFullSecondTransitions() {
    for (
      siteTransitionsI = 0;
      siteTransitionsI < fullSecondTransitionItems.length;
      siteTransitionsI++
    ) {
      fullSecondTransitionItems[siteTransitionsI].classList.toggle(
        "full-second"
      );
    }
  }
}
