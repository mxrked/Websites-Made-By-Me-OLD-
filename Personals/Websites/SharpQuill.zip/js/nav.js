/*

    This script is for the nav

*/

const navToggler = document.getElementById("navToggler");
const navCloser = document.getElementById("navCloser");
const navLinks = document.getElementById("navLinks");
const navDarken = document.getElementById("navDarken");
const navBox = document.getElementById("navBox");

navDarken.classList.toggle("deactive");
navDarken.style.pointerEvents = "none";
navBox.classList.toggle("deactive");

function openNav() {
  document.body.style.overflowY = "hidden";
  navToggler.disabled = true;
  document.getElementById("mainBodyInner").style.opacity = ".1";
  navDarken.classList.remove("deactive");
  navLinks.style.maxWidth = "360px";

  setTimeout(() => {
    navBox.classList.remove("deactive");
    navDarken.style.pointerEvents = "auto";
    navCloser.disabled = false;
  }, 770);
}

const typesToggler = document.getElementById("typesToggler");
const typesCloser = document.getElementById("typesCloser");
const typesLinks = document.getElementById("typesLinks");
const typesLinksInner = document.getElementById("typesLinksInner");

function determineTypes(btn1, btn2, h) {
  btn1.style.display = "none";
  btn2.style.display = "flex";
  typesLinks.style.height = h;
}

typesToggler.addEventListener("click", () => {
  determineTypes(typesToggler, typesCloser, "250px", typesLinksInner);
});
typesCloser.addEventListener("click", () => {
  determineTypes(typesCloser, typesToggler, "0");
});

function closeNav() {
  navCloser.disabled = true;
  navDarken.style.pointerEvents = "none";
  navBox.classList.toggle("deactive");
  determineTypes(typesCloser, typesToggler, "0");

  setTimeout(() => {
    navDarken.classList.toggle("deactive");
    navLinks.style.maxWidth = "0";
  }, 770);

  setTimeout(() => {
    document.body.style.overflowY = "auto";
    navToggler.disabled = false;
    document.getElementById("mainBodyInner").style.opacity = "1";
  }, 900);
}

navToggler.addEventListener("click", openNav);
navCloser.addEventListener("click", closeNav);
window.onclick = function (e) {
  if (e.target == navDarken) {
    closeNav();
  }
};
