/*

    This script is for the nav

*/

const navToggler = document.getElementById("navToggler");
const navCloser = document.getElementById("navCloser");
const navLinks = document.getElementById("navLinks");
const navDarken = document.getElementById("navDarken");
const navBox = document.getElementById("navBox");

navDarken.classList.toggle("deactive");
navDarken.style.pointerEvents = "none";
navBox.classList.toggle("deactive");

function openNav() {
  navToggler.disabled = true;
  document.getElementById("mainBodyInner").style.opacity = ".1";
  navDarken.classList.remove("deactive");
  navLinks.style.maxWidth = "360px";

  setTimeout(() => {
    navBox.classList.remove("deactive");
    navDarken.style.pointerEvents = "auto";
    navCloser.disabled = false;
  }, 770);
}

function closeNav() {
  navCloser.disabled = true;
  navDarken.style.pointerEvents = "none";
  navBox.classList.toggle("deactive");

  setTimeout(() => {
    navDarken.classList.toggle("deactive");
    navLinks.style.maxWidth = "0";
  }, 770);

  setTimeout(() => {
    navToggler.disabled = false;
    document.getElementById("mainBodyInner").style.opacity = "1";
  }, 900);
}

navToggler.addEventListener("click", openNav);
navCloser.addEventListener("click", closeNav);
window.onclick = function (e) {
  if (e.target == navDarken) {
    closeNav();
  }
};
