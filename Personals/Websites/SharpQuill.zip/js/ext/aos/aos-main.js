/*

    This script will store the AOS library's main function

*/

triggerAOS();
function triggerAOS() {
  AOS.init({
    once: true,
    disable: "mobile",
  });
}
