/*

    This script will hold the owl carousel activations

*/

// Index Products

document.addEventListener("DOMContentLoaded", function () {
  new Splide("#iProductsSplide", {
    perPage: 2,
    breakpoints: {
      992: {
        perPage: 1,
      },
      992: {
        perPage: 1,
      },
    },
  }).mount();
});
