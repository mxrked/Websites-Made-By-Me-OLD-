var typesPI;

// This will check if the pageloader has finished before loading in the typesPageFades
function checkTypesPageFades() {
  if (pageLoaderState == true && blankPageState == true) {
    setTimeout(() => {
      triggerTypesPageFades();
    }, 2000);
  }
}

// This will hide the typesPageFades by default
const hideTypesPageFades = document.getElementsByClassName("types-page-fade");
function hideTypesPageFade() {
  for (typesPI = 0; typesPI < hideTypesPageFades.length; typesPI++) {
    hideTypesPageFades[typesPI].classList.toggle("deactive");
    hideTypesPageFades[typesPI].style.position = "relative";
  }
}
hideTypesPageFade();

const typesPageFades = document.querySelectorAll(".types-page-fade");
typesPageFades[0].style.top = "-100px";
typesPageFades[1].style.top = "100px";
function triggerTypesPageFades() {
  setTimeout(() => {
    typesPageFades[0].classList.remove("deactive");
  }, 400);
  setTimeout(() => {
    typesPageFades[0].style.top = "0";
  }, 450);

  setTimeout(() => {
    typesPageFades[1].classList.remove("deactive");
  }, 600);
  setTimeout(() => {
    typesPageFades[1].style.top = "0";
  }, 650);
}

window.addEventListener("load", () => {
  checkTypesPageFades();
});
