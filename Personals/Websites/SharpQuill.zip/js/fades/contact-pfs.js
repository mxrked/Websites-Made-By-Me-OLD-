/*

    This script will trigger some page fade ins based on pageLoader state.

*/

var contactPI;

// This will check if the pageloader has finished before loading in the contactPageFades
function checkContactPageFades() {
  if (pageLoaderState == true && blankPageState == true) {
    setTimeout(() => {
      triggerContactPageFades();
    }, 2000);
  }
}

// This will hide the contactPageFades by default
const hideContactPageFades =
  document.getElementsByClassName("contact-page-fade");
function hideContactPageFade() {
  for (contactPI = 0; contactPI < hideContactPageFades.length; contactPI++) {
    hideContactPageFades[contactPI].classList.toggle("deactive");
    hideContactPageFades[contactPI].style.position = "relative";
  }
}
hideContactPageFade();

// This will change the opacity for each contact-type
const lightenContactPageTypes = document.getElementsByClassName("contact-type");
function ligthenContactTypes() {
  for (contactPI = 0; contactPI < lightenContactPageTypes.length; contactPI++) {
    lightenContactPageTypes[contactPI].style.opacity = ".8";
  }
}

const contactPageFades = document.querySelectorAll(".contact-page-fade");
contactPageFades[0].style.top = "-100px";
contactPageFades[1].style.top = "100px";
function triggerContactPageFades() {
  setTimeout(() => {
    contactPageFades[0].classList.remove("deactive");
  }, 400);
  setTimeout(() => {
    contactPageFades[0].style.top = "0";
  }, 450);

  setTimeout(() => {
    contactPageFades[1].classList.remove("deactive");
  }, 600);
  setTimeout(() => {
    contactPageFades[1].style.top = "0";
  }, 650);
}

window.addEventListener("load", () => {
  checkContactPageFades();
});
