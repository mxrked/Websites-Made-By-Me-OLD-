/*

    This script will trigger some page fade ins based on pageLoader state.

*/

var indexPI;

// This will check if the pageloader has finished before loading in the indexPageFades
function checkIndexPageFades() {
  if (pageLoaderState == true && blankPageState == true) {
    setTimeout(() => {
      triggerIndexPageFades();
    }, 2000);
  }
}

// This will hide the indexPageFades by default
const hideIndexPageFades = document.getElementsByClassName("index-page-fade");
function hideIndexPageFade() {
  for (indexPI = 0; indexPI < hideIndexPageFades.length; indexPI++) {
    hideIndexPageFades[indexPI].classList.toggle("deactive");
    hideIndexPageFades[indexPI].style.position = "relative";
  }
}
hideIndexPageFade();

// This will change the opacity for each index-type
const lightenIndexPageTypes = document.getElementsByClassName("index-type");
function ligthenIndexTypes() {
  for (indexPI = 0; indexPI < lightenIndexPageTypes.length; indexPI++) {
    lightenIndexPageTypes[indexPI].style.opacity = ".8";
  }
}

const indexPageFades = document.querySelectorAll(".index-page-fade");
indexPageFades[0].style.top = "-100px";
indexPageFades[1].style.top = "100px";
function triggerIndexPageFades() {
  setTimeout(() => {
    indexPageFades[0].classList.remove("deactive");
  }, 400);
  setTimeout(() => {
    indexPageFades[0].style.top = "0";
  }, 450);

  setTimeout(() => {
    indexPageFades[1].classList.remove("deactive");
  }, 600);
  setTimeout(() => {
    indexPageFades[1].style.top = "0";
  }, 650);
}

const indexTypeItems = document.querySelectorAll(".index-type");
indexTypeItems[0].addEventListener("mouseover", () => {
  ligthenIndexTypes();
  indexTypeItems[0].style.opacity = "1";
});
indexTypeItems[1].addEventListener("mouseover", () => {
  ligthenIndexTypes();
  indexTypeItems[1].style.opacity = "1";
});
indexTypeItems[2].addEventListener("mouseover", () => {
  ligthenIndexTypes();
  indexTypeItems[2].style.opacity = "1";
});
indexTypeItems[3].addEventListener("mouseover", () => {
  ligthenIndexTypes();
  indexTypeItems[3].style.opacity = "1";
});
indexTypeItems[4].addEventListener("mouseover", () => {
  ligthenIndexTypes();
  indexTypeItems[4].style.opacity = "1";
});

window.addEventListener("load", () => {
  checkIndexPageFades();
});
