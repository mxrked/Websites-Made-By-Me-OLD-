/*

    This script will trigger some page fade ins based on pageLoader state.

*/

var bubbaPI;

// This will check if the pageloader has finished before loading in the bubbaPageFades
function checkBubbaPageFades() {
  if (pageLoaderState == true && blankPageState == true) {
    setTimeout(() => {
      triggerBubbaPageFades();
    }, 2000);
  }
}

// This will hide the bubbaPageFades by default
const hideBubbaPageFades = document.getElementsByClassName("bubba-page-fade");
function hideBubbaPageFade() {
  for (bubbaPI = 0; bubbaPI < hideBubbaPageFades.length; bubbaPI++) {
    hideBubbaPageFades[bubbaPI].classList.toggle("deactive");
    hideBubbaPageFades[bubbaPI].style.position = "relative";
  }
}
hideBubbaPageFade();

// This will change the opacity for each bubba-type
const lightenBubbaPageTypes = document.getElementsByClassName("bubba-type");
function ligthenBubbaTypes() {
  for (bubbaPI = 0; bubbaPI < lightenBubbaPageTypes.length; bubbaPI++) {
    lightenBubbaPageTypes[bubbaPI].style.opacity = ".8";
  }
}

const bubbaPageFades = document.querySelectorAll(".bubba-page-fade");
bubbaPageFades[0].style.top = "-100px";
bubbaPageFades[1].style.top = "100px";
function triggerBubbaPageFades() {
  setTimeout(() => {
    bubbaPageFades[0].classList.remove("deactive");
  }, 400);
  setTimeout(() => {
    bubbaPageFades[0].style.top = "0";
  }, 450);

  setTimeout(() => {
    bubbaPageFades[1].classList.remove("deactive");
  }, 600);
  setTimeout(() => {
    bubbaPageFades[1].style.top = "0";
  }, 650);
}

window.addEventListener("load", () => {
  checkBubbaPageFades();
});
