var aboutPI;

// This will check if the pageloader has finished before loading in the aboutPageFades
function checkAboutPageFades() {
  if (pageLoaderState == true && blankPageState == true) {
    setTimeout(() => {
      triggerAboutPageFades();
    }, 2000);
  }
}

// This will hide the aboutPageFades by default
const hideAboutPageFades = document.getElementsByClassName("about-page-fade");
function hideAboutPageFade() {
  for (aboutPI = 0; aboutPI < hideAboutPageFades.length; aboutPI++) {
    hideAboutPageFades[aboutPI].classList.toggle("deactive");
    hideAboutPageFades[aboutPI].style.position = "relative";
  }
}
hideAboutPageFade();

const aboutPageFades = document.querySelectorAll(".about-page-fade");
aboutPageFades[0].style.top = "-100px";
aboutPageFades[1].style.top = "100px";
function triggerAboutPageFades() {
  setTimeout(() => {
    aboutPageFades[0].classList.remove("deactive");
  }, 400);
  setTimeout(() => {
    aboutPageFades[0].style.top = "0";
  }, 450);

  setTimeout(() => {
    aboutPageFades[1].classList.remove("deactive");
  }, 600);
  setTimeout(() => {
    aboutPageFades[1].style.top = "0";
  }, 650);
}

window.addEventListener("load", () => {
  checkAboutPageFades();
});
