/*

    This script will fix the issue of the type-hover not dissappearing when the user hovers over the index type inner

*/

const indexTypeHolders = document.querySelectorAll(".index-type-holder");
const indexTypeHovers = document.querySelectorAll(".type-hover");

function resetITHS() {
  var iTI;
  const allIndexTypeHovers = document.getElementsByClassName("type-hover");

  for (iTI = 0; iTI < allIndexTypeHovers.length; iTI++) {
    allIndexTypeHovers[iTI].style.opacity = "1";
    allIndexTypeHovers[iTI].style.visiblity = "visible";
  }
}

function hideITHS(th, state) {
  if (state == "in") {
    th.style.opacity = "0";
    th.style.visiblity = "hidden";
  } else if (state == "out") {
    th.style.opacity = "1";
    th.style.visiblity = "visible";
  }
}

indexTypeHolders[0].addEventListener("mouseenter", () => {
  hideITHS(indexTypeHovers[0], "in");
});
indexTypeHolders[0].addEventListener("mouseleave", () => {
  hideITHS(indexTypeHovers[0], "out");
});
indexTypeHolders[1].addEventListener("mouseenter", () => {
  hideITHS(indexTypeHovers[1], "in");
});
indexTypeHolders[1].addEventListener("mouseleave", () => {
  hideITHS(indexTypeHovers[1], "out");
});
indexTypeHolders[2].addEventListener("mouseenter", () => {
  hideITHS(indexTypeHovers[2], "in");
});
indexTypeHolders[2].addEventListener("mouseleave", () => {
  hideITHS(indexTypeHovers[2], "out");
});
indexTypeHolders[3].addEventListener("mouseenter", () => {
  hideITHS(indexTypeHovers[3], "in");
});
indexTypeHolders[3].addEventListener("mouseleave", () => {
  hideITHS(indexTypeHovers[3], "out");
});
indexTypeHolders[4].addEventListener("mouseenter", () => {
  hideITHS(indexTypeHovers[4], "in");
});
indexTypeHolders[4].addEventListener("mouseleave", () => {
  hideITHS(indexTypeHovers[4], "out");
});
