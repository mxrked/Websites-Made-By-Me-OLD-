/*

    This script will be used to create cool hover effects for the index page

*/

var indexHovers;
function indexImgHover(box, img) {
  box.addEventListener("mouseenter", () => {
    img.style.opacity = ".8";
  });
  box.addEventListener("mouseleave", () => {
    img.style.opacity = "1";
  });
}

function indexToolTip(tt, hover) {
  hover.addEventListener("mouseover", () => {
    tt.classList.remove("deactive");
  });

  hover.addEventListener("mouseleave", () => {
    tt.classList.toggle("deactive");
  });
}

const indexToolTips = document.querySelectorAll(".img-tooltip");

const hideIndexToolTips = document.getElementsByClassName("img-tooltip");
for (indexHovers = 0; indexHovers < hideIndexToolTips.length; indexHovers++) {
  hideIndexToolTips[indexHovers].classList.toggle("deactive");
}

function indexTopHovers() {
  const iTopBox = document.getElementById("indexTopBox");
  const iTopImg = document.getElementById("indexDTTopImg");
  indexImgHover(iTopBox, iTopImg);
  indexToolTip(indexToolTips[0], iTopImg);
}

window.addEventListener("load", () => {
  indexTopHovers();
});
