/*

    This script will be used to create cool hover effects for the index page

*/

var indexHovers;

//* Hovers
function indexImgHover(box, img) {
  box.addEventListener("mouseenter", () => {
    img.style.opacity = ".8";
  });
  box.addEventListener("mouseleave", () => {
    img.style.opacity = "1";
  });
}

const indexToolTips = document.querySelectorAll(".img-tooltip");
function indexToolTip(tt, hover) {
  hover.addEventListener("mouseover", () => {
    tt.classList.remove("deactive");
  });

  hover.addEventListener("mouseleave", () => {
    tt.classList.toggle("deactive");
  });
}

const hideIndexToolTips = document.getElementsByClassName("img-tooltip");
for (indexHovers = 0; indexHovers < hideIndexToolTips.length; indexHovers++) {
  hideIndexToolTips[indexHovers].classList.toggle("deactive");
}

const indexHeadings = document.querySelectorAll(".index-sect-heading");
function indexHeadingsSlant(heading, hover) {
  hover.addEventListener("mouseover", () => {
    heading.style.transform = "skew(10deg)";
  });
  hover.addEventListener("mouseleave", () => {
    heading.style.transform = "skew(0deg)";
  });
}

const indexProducts = document.querySelectorAll(".index-product-holder");
function indexProductsOpacity() {
  const lightenIndexProducts = document.getElementsByClassName(
    "index-product-holder"
  );

  indexProducts.forEach((product) => {
    product.addEventListener("mouseover", () => {
      for (
        indexHovers = 0;
        indexHovers < lightenIndexProducts.length;
        indexHovers++
      ) {
        lightenIndexProducts[indexHovers].style.opacity = ".5";
      }
    });
    product.addEventListener("mouseleave", () => {
      for (
        indexHovers = 0;
        indexHovers < lightenIndexProducts.length;
        indexHovers++
      ) {
        lightenIndexProducts[indexHovers].style.opacity = "1";
      }
    });
  });
}

//? Hovers HOLDERS
function indexTopHovers() {
  const iTopBox = document.getElementById("indexTopBox");
  const iTopImg = document.getElementById("indexDTTopImg");
  indexImgHover(iTopBox, iTopImg);
  indexToolTip(indexToolTips[0], iTopImg);
}

function indexTypeHovers() {
  const iTypesTop = document.getElementById("indexTypesTop");
  indexHeadingsSlant(indexHeadings[0], iTypesTop);
}

function indexProductHovers() {
  const iProductsTop = document.getElementById("indexProductsTop");
  indexHeadingsSlant(indexHeadings[1], iProductsTop);
  indexProductsOpacity();
  indexProducts[0].addEventListener("mouseover", () => {
    indexProducts[0].style.opacity = "1";
  });
  indexProducts[1].addEventListener("mouseover", () => {
    indexProducts[1].style.opacity = "1";
  });
  indexProducts[2].addEventListener("mouseover", () => {
    indexProducts[2].style.opacity = "1";
  });
  indexProducts[3].addEventListener("mouseover", () => {
    indexProducts[3].style.opacity = "1";
  });
}

window.addEventListener("load", () => {
  indexTopHovers();
  indexTypeHovers();
  indexProductHovers();
});
