/*

    This script will be used to create cool hover effects for the index page

*/

var indexHovers;

//* Hovers

const indexHeadings = document.querySelectorAll(".index-sect-heading");
function indexHeadingsSlant(heading, hover) {
  hover.addEventListener("mouseover", () => {
    heading.style.transform = "skew(10deg)";
  });
  hover.addEventListener("mouseleave", () => {
    heading.style.transform = "skew(0deg)";
  });
}

const indexProducts = document.querySelectorAll(".index-product-holder");
function indexProductsOpacity() {
  const lightenIndexProducts = document.getElementsByClassName(
    "index-product-holder"
  );

  indexProducts.forEach((product) => {
    product.addEventListener("mouseover", () => {
      for (
        indexHovers = 0;
        indexHovers < lightenIndexProducts.length;
        indexHovers++
      ) {
        lightenIndexProducts[indexHovers].style.opacity = ".5";
      }
    });
    product.addEventListener("mouseleave", () => {
      for (
        indexHovers = 0;
        indexHovers < lightenIndexProducts.length;
        indexHovers++
      ) {
        lightenIndexProducts[indexHovers].style.opacity = "1";
      }
    });
  });
}

//? Hovers HOLDERS

function indexTypeHovers() {
  const iTypesTop = document.getElementById("indexTypesTop");
  indexHeadingsSlant(indexHeadings[0], iTypesTop);
}

function indexProductHovers() {
  const iProductsTop = document.getElementById("indexProductsTop");
  indexHeadingsSlant(indexHeadings[1], iProductsTop);
  indexProductsOpacity();
  indexProducts[0].addEventListener("mouseover", () => {
    indexProducts[0].style.opacity = "1";
  });
  indexProducts[1].addEventListener("mouseover", () => {
    indexProducts[1].style.opacity = "1";
  });
  indexProducts[2].addEventListener("mouseover", () => {
    indexProducts[2].style.opacity = "1";
  });
  indexProducts[3].addEventListener("mouseover", () => {
    indexProducts[3].style.opacity = "1";
  });
}

function indexAdoptHovers() {
  const iAdoptBox = document.getElementById("indexAdoptBox");
  indexHeadingsSlant(indexHeadings[2], iAdoptBox);
}

window.addEventListener("load", () => {
  indexTypeHovers();
  indexProductHovers();
  indexAdoptHovers();
});
