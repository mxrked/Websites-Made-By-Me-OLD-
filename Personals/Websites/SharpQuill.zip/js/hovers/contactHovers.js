/*

    This script will be used to create cool hover effects for the contact page

*/

const contactHeadings = document.querySelectorAll(".contact-sect-heading");
function contactHeadingsSlant(heading, hover) {
  hover.addEventListener("mouseover", () => {
    heading.style.transform = "skew(10deg)";
  });
  hover.addEventListener("mouseleave", () => {
    heading.style.transform = "skew(0deg)";
  });
}

function contactFormTopHovers() {
  const cFormTop = document.getElementById("contactFormHolder");
  contactHeadingsSlant(contactHeadings[0], cFormTop);
}

window.addEventListener("load", () => {
  contactFormTopHovers();
});
