/*

    This script will be used to create cool hover effects for the about page

*/

const aboutHeadings = document.querySelectorAll(".about-sect-heading");
function aboutHeadingsSlant(heading, hover) {
  hover.addEventListener("mouseover", () => {
    heading.style.transform = "skew(10deg)";
  });
  hover.addEventListener("mouseleave", () => {
    heading.style.transform = "skew(0deg)";
  });
}

function aboutStoryHovers() {
  const aStory = document.getElementById("aboutStory");
  aboutHeadingsSlant(aboutHeadings[0], aStory);
}

window.addEventListener("load", () => {
  aboutStoryHovers();
});
