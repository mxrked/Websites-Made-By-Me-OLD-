/*

    This script is for the search field

*/
var searchI;
const searchField = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");
searchResults.classList.toggle("deactive");

function preventResultsTabbing(state) {
  document.onkeydown = function (e) {
    if (e.key == "Tab") {
      return state;
    }
  };
}

searchField.addEventListener("click", () => {
  searchResults.classList.remove("deactive");
  preventResultsTabbing(false);
});
searchField.addEventListener("blur", () => {
  searchResults.classList.toggle("deactive");
  preventResultsTabbing(true);
});

//? This will filter out and try to decide what the user may be typing into the search field
function grabSearchFieldTxt() {
  let filter;
  filter = searchField.value.toUpperCase();
  const searchResult = searchResults.getElementsByTagName("li");
  let searchResultLink;

  for (searchI = 0; searchI < searchResult.length; searchI++) {
    searchResultLink = searchResult[searchI].getElementsByTagName("a")[0];

    const searchResultTxt =
      searchResultLink.textContent || searchResultLink.innerText;

    if (searchResultTxt.toUpperCase().indexOf(filter) > -1) {
      searchResult[searchI].style.display = "block";
    } else {
      searchResult[searchI].style.display = "none";
    }
  }
}
searchField.addEventListener("keyup", grabSearchFieldTxt);

//? This will decide what the user types and when they press the enter or search button, it will reroute them to the respected page

function rerouteSearchFieldTxt(link) {
  const rerouteValue = searchField.value.toLowerCase();

  //* Checking what the user input was after user presses enter or go button
  switch (true) {
    case rerouteValue.indexOf("home") > -1:
      link = "index.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("about") > -1:
      link = "about.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("store") > -1:
      link = "store.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("types") > -1:
      link = "types.html#allTypes";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("atelerix") > -1:
      link = "types.html#atelerix";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("erinaceus") > -1:
      link = "types.html#erinaceus";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("hemiechinus") > -1:
      link = "types.html#hemiechinus";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("mesechinus") > -1:
      link = "types.html#mesechinus";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("paraechinus") > -1:
      link = "types.html#paraechinus";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("bubba") > -1:
      link = "bubba.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("adoption") > -1:
      link = "adopt.html";
      rerouteLinks(link);
      break;
    case rerouteValue.indexOf("contact") > -1:
      link = "contact.html";
      rerouteLinks(link);
      break;
  }
}

//* Checks what the user input is and makes it the link to reroute to
function rerouteLinks(link) {
  window.location.href = link;
}

window.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    rerouteSearchFieldTxt();
  }
});
document.getElementById("searchGo").addEventListener("click", () => {
  rerouteSearchFieldTxt();
});
