/*

    This script is for the searchField

*/

const sFToggler = document.getElementById("toggleSF");
const sFCloser = document.getElementById("closeSF");

//? determining what sF btn was clicked (open or close)
function determineSFState(btn) {
  if (btn == sFToggler) {
    console.log("Search Field was toggled.");
  } else if (btn == sFCloser) {
    console.log("Search Field was closed.");
  }
}

//? allows the tab btn to be disabled to prevent disappearing results list and reenabling when sF is closed
function tabBtnManip(state) {
  document.onkeydown = function (t) {
    if (t.key == "Tab") {
      return state;
    }
  };
}

sFToggler.addEventListener("click", () => {
  determineSFState(sFToggler);
  openSF();
  tabBtnManip(false);
});
sFCloser.addEventListener("click", () => {
  determineSFState(sFCloser);
  closeSF();
  tabBtnManip(true);
});

//! interactions
const sFBox = document.getElementById("searchFieldBox");
const sFCnt = document.getElementById("sFCnt");
const sFInput = document.getElementById("sFInput");
var sFInputClicked;
const sFSearch = document.getElementById("sFSearch");
const sFResultsHolder = document.getElementById("searchResultsHolder");
const sFResults = document.getElementById("searchResults");

sFBox.style.display = "none";
sFBox.classList.toggle("deactive");
sFResultsHolder.classList.toggle("deactive");
sFResults.classList.toggle("deactive");

function openSF() {
  document.body.style.overflowY = "hidden";
  sFToggler.style.opacity = ".5";
  sFToggler.disable = true;
  sFBox.style.display = "grid";

  setTimeout(() => {
    sFBox.classList.remove("deactive");
    sFCnt.classList.remove("deactive");
    sFCloser.disable = false;
  }, 200);
}

function closeSF() {
  sFCloser.disable = true;

  setTimeout(() => {
    sFCnt.classList.toggle("deactive");
  }, 500);

  setTimeout(() => {
    sFBox.classList.toggle("deactive");
  }, 900);

  setTimeout(() => {
    document.body.style.overflowY = "auto";
    sFBox.style.display = "none";
    sFToggler.style.opacity = "1";
    sFToggler.disable = false;
  }, 1200);
}

function showSFResults() {
  sFResultsHolder.classList.remove("deactive");
  sFResults.classList.remove("deactive");
}
function hideSFResults() {
  sFResultsHolder.classList.toggle("deactive");
  sFResults.classList.toggle("deactive");
}

sFInput.addEventListener("click", () => {
  sFInputClicked = true;
});
sFInput.addEventListener("click", showSFResults);
sFInput.addEventListener("blur", () => {
  sFInputClicked = false;
});
sFInput.addEventListener("blur", hideSFResults);

//? checking if the input is empty and if so it will show all results
if (sFInput.value.length == 0 && sFInputClicked == true) {
  showSFResults();
} else if (sFInput.value.length == 0 && sFInputClicked == false) {
  hideSFResults();
} else {
  hideSFResults();
}

//? check what the user types into the search field
sFInput.addEventListener("keyup", grabSFInput);
function grabSFInput() {
  var sFI;
  let sFFilter;
  sFFilter = sFInput.value.toUpperCase();
  const sFResult = sFResults.getElementsByTagName("li");
  let sFResultLink;

  for (sFI = 0; sFI < sFResult.length; sFI++) {
    sFResultLink = sFResult[sFI].getElementsByTagName("a")[0];
    const sFResultTxt = sFResultLink.textContent || sFResultLink.innerText;

    if (sFResultTxt.toUpperCase().indexOf(sFFilter) > -1) {
      sFResult[sFI].style.display = "block";
    } else {
      sFResult[sFI].style.display = "none";
    }
  }
}

//? for ease of sanity, check what result link the user clicks
function determineSFResultClicked(link, txt) {
  link = document.getElementById(this);
  console.log(txt);
}

//? check what the user types in and route them to dedicated page
// this may be ugly... cant really think of another way ATM
function checkSFInput() {
  const sFValue = sFInput.value;

  if (sFValue.toLowerCase().indexOf("home") > -1) {
    console.log("Home was entered.");
    window.location.href = "index.html";
  }
  if (sFValue.toLowerCase().indexOf("about") > -1) {
    console.log("About was entered.");
    window.location.href = "about.html";
  }
  if (sFValue.toLowerCase().indexOf("types") > -1) {
    console.log("Types was entered.");
    window.location.href = "types.html";
  }
  if (sFValue.toLowerCase().indexOf("atelerix") > -1) {
    console.log("Atelerix was entered.");
    window.location.href = "types.html#atelerix";
  }
  if (sFValue.toLowerCase().indexOf("erinaceus") > -1) {
    console.log("Erinaceus was entered.");
    window.location.href = "types.html#erinaceus";
  }
  if (sFValue.toLowerCase().indexOf("hemiechinus") > -1) {
    console.log("Hemiechinus was entered.");
    window.location.href = "types.html#hemiechinus";
  }
  if (sFValue.toLowerCase().indexOf("mesechinus") > -1) {
    console.log("Mesechinus was entered.");
    window.location.href = "types.html#mesechinus";
  }
  if (sFValue.toLowerCase().indexOf("paraechinus") > -1) {
    console.log("Paraechinus was entered.");
    window.location.href = "types#paraechinus.html";
  }
  if (sFValue.toLowerCase().indexOf("bubba") > -1) {
    console.log("Remembering Bubba was entered.");
    window.location.href = "bubba.html";
  }
  if (sFValue.toLowerCase().indexOf("contact") > -1) {
    console.log("Contact was entered.");
    window.location.href = "contact.html";
  }
  if (sFValue.toLowerCase().indexOf("adoption") > -1) {
    console.log("Adoption was entered.");
    window.location.href = "adopt.html";
  }
  if (sFValue.toLowerCase().indexOf("store") > -1) {
    console.log("Store was entered.");
    window.location.href = "store.html";
  }
  if (sFValue.toLowerCase().indexOf("food") > -1) {
    console.log("Food was entered.");
    window.location.href = "store.html#food";
  }
  if (sFValue.toLowerCase().indexOf("toys") > -1) {
    console.log("Toys was entered.");
    window.location.href = "store.html#toys";
  }
  if (sFValue.toLowerCase().indexOf("caring") > -1) {
    console.log("Caring was entered.");
    window.location.href = "store.html#caring";
  }
}

//? user presses enter
sFInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    checkSFInput();
  }
});
//? user presses go btn
sFSearch.addEventListener("click", () => {
  checkSFInput();
});
