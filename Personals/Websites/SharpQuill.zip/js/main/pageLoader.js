/*

    This script is for the pageLoader

*/

const pageLoader = document.getElementById("pageLoader");
const pageLoaderCnt = document.getElementById("pageLoaderCnt");
var pageLoaderAfter;

function checkPageLoaderAfter() {
  if (pageLoaderAfter === false) {
    document.getElementById("mainBodyInner").style.opacity = "1";
    console.log("Page Loader finished.");
  } else if (pageLoaderAfter === true) {
    document.getElementById("mainBodyInner").style.opacity = "0";
  }
}

checkPageLoaderState("false");
function checkPageLoaderState(state) {
  if (state == "true") {
    pageLoaderCnt.classList.toggle("deactive");

    setTimeout(() => {
      pageLoader.classList.toggle("deactive");
      pageLoaderAfter = true;
      document.body.style.overflowY = "auto";
    }, 500);

    checkPageLoaderAfter();
  } else if (state == "false") {
    document.body.style.overflowY = "hidden";
    pageLoaderCnt.classList.remove("deactive");
    pageLoader.classList.remove("deactive");
    pageLoaderAfter = false;

    checkPageLoaderAfter();
  }
}

window.addEventListener("load", () => {
  checkPageLoaderState("true");
});
