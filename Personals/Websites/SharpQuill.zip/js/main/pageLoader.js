/*

    This script is for the pageLoader

*/

const pageLoaderHolder = document.getElementById("pageLoader");
const pageLoaderContent = document.getElementById("pageLoaderCnt");
const theBlankPage = document.getElementById("blankPage");
var pageLoaderState;
pageLoaderState = false;

function determinePageLoaderState() {
  if (pageLoaderState == true) {
    pageLoaderContent.classList.toggle("deactive");

    setTimeout(() => {
      pageLoaderHolder.style.height = "0";
    }, 600);

    setTimeout(() => {
      theBlankPage.classList.toggle("deactive");
    }, 1500);
  }
}

window.addEventListener("load", () => {
  pageLoaderState = true;
  determinePageLoaderState();
});
