/*

    This script is for the backToTopBtn

*/

const backToTopBtn = document.getElementById("b2Top");
backToTopBtn.style.bottom = "-100px";

function b2TopDetermine() {
  if (window.scrollY <= 100) {
    backToTopBtn.style.bottom = "-100px";
  } else if (window.scrollY > 100) {
    backToTopBtn.style.bottom = "20px";
  }
}

window.addEventListener("scroll", () => {
  b2TopDetermine();
});
backToTopBtn.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
