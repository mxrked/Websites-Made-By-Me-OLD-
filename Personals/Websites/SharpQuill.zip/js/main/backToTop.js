/*

    This script is for the backToTopBtn and this will also move the sFToggler when the backToTopBtn appears

*/

const backToTopBtn = document.getElementById("b2Top");

function checkB2TState() {
  if (window.scrollY >= 100) {
    backToTopBtn.style.bottom = "20px";
    sFToggler.style.bottom = "70px";
  } else if (window.scrollY <= 99) {
    backToTopBtn.style.bottom = "-50px";
    sFToggler.style.bottom = "20px";
  }
}

window.addEventListener("scroll", checkB2TState);
backToTopBtn.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
