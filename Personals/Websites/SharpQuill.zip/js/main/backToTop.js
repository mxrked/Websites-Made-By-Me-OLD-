/*

    This script is for the backToTopBtn

*/

const backToTopBtn = document.getElementById("b2Top");
backToTopBtn.style.bottom = "-100px";
document.getElementById("cartToggler").style.bottom = "20px";

function b2TopDetermine() {
  if (window.scrollY <= 100) {
    document.getElementById("cartToggler").style.bottom = "20px";
    backToTopBtn.style.bottom = "-100px";
  } else if (window.scrollY > 100) {
    document.getElementById("cartToggler").style.bottom = "70px";
    backToTopBtn.style.bottom = "20px";
  }
}

window.addEventListener("scroll", () => {
  b2TopDetermine();
});
backToTopBtn.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
