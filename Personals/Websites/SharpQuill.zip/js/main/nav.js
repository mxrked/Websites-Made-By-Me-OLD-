/*

    This script is for the nav

*/

// Making the nav disappear on scroll and reappear when user gets closer to the top
function scrollingNav() {
  const navHolder = document.getElementById("fullNav");

  const scrollPos = window.scrollY;

  if (scrollPos <= 250) {
    navHolder.style.top = "0px";
  }

  if (scrollPos >= 251 || scrollPos != 0) {
    navHolder.style.top = "-700px";
  }
}

window.addEventListener("scroll", scrollingNav);

const nToggler = document.getElementById("navToggler");
const nCloser = document.getElementById("navCloser");
const nLinks = document.getElementById("navLinks");
const nLinksCnt = document.getElementById("navLinksCnt");
const nDarken = document.getElementById("navDarken");

nDarken.style.opacity = "0";
nDarken.style.pointerEvents = "none";
nLinks.style.width = "0px";
nLinksCnt.classList.toggle("deactive");

function openNav() {
  document.body.style.overflowY = "hidden";
  document.getElementById("mainBodyInner").style.opacity = "0.5";
  nDarken.style.opacity = "1";
  nLinks.style.width = "100%";

  setTimeout(() => {
    nLinksCnt.classList.remove("deactive");
  }, 800);
  setTimeout(() => {
    nDarken.style.pointerEvents = "auto";
  }, 900);
}

function closeNav() {
  closeSubSets();
  nLinksCnt.classList.toggle("deactive");
  nDarken.style.pointerEvents = "none";

  setTimeout(() => {
    nLinks.style.width = "0px";
    nDarken.style.opacity = "0";
  }, 600);
  setTimeout(() => {
    document.getElementById("mainBodyInner").style.opacity = "1";

    document.body.style.overflowY = "auto";
  }, 1200);
}

nToggler.addEventListener("click", openNav);
nCloser.addEventListener("click", closeNav);
window.addEventListener("click", (e) => {
  if (e.target == nDarken) {
    closeNav();
  }
});

function hoverNavLinks() {
  const navLink = document.querySelectorAll(".nav-link");

  navLink.forEach((link) => {
    link.addEventListener("mouseover", () => {
      link.style.background = "#36263b";
    });
    link.addEventListener("mouseleave", () => {
      link.style.background = "#2a1b2e";
    });
  });
}
hoverNavLinks();

function determineNavSubSet(btn1, btn2, set) {
  btn1.addEventListener("click", () => {
    btn1.style.display = "none";
    btn2.style.display = "flex";
    set.style.height = "100%";
  });
  btn2.addEventListener("click", () => {
    btn1.style.display = "flex";
    btn2.style.display = "none";
    set.style.height = "0px";
  });
}
const sToggler = document.getElementById("storeToggler");
const sCloser = document.getElementById("storeCloser");
const sLinks = document.getElementById("storeLinks");

determineNavSubSet(sToggler, sCloser, sLinks);

function closeSubSets() {
  sCloser.style.display = "none";
  sLinks.style.height = "0px";
}
closeSubSets();
