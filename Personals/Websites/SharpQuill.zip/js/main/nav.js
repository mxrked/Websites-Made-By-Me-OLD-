/*

    This script is for the nav

*/

const darkNav = document.getElementById("darkenNav");
const navLinks = document.getElementById("mobileNavLinks");
const navToggler = document.getElementById("mobileNavToggler");
const navCloser = document.getElementById("mobileNavCloser");
const navCnt = document.getElementById("mobileNavCnt");

document.querySelectorAll(".mobile-nav-links-set div").forEach((div) => {
  div.style.height = "0";
});

navLinks.style.display = "none";
darkNav.style.display = "none";
darkNav.classList.toggle("deactive");
darkNav.style.pointerEvents = "none";
navCnt.classList.toggle("deactive");

navLinks.style.maxWidth = "0";

function animateNav(mW) {
  navLinks.style.maxWidth = mW;
}

function openNav() {
  document.body.style.overflowY = "hidden";

  navToggler.disabled = true;
  navToggler.style.opacity = ".5";
  darkNav.style.display = "block";

  setTimeout(() => {
    darkNav.classList.remove("deactive");
  }, 50);
  navLinks.style.display = "block";
  setTimeout(() => {
    animateNav("320px");
    navCloser.disabled = false;
  }, 100);

  setTimeout(() => {
    navCnt.classList.remove("deactive");
  }, 800);

  setTimeout(() => {
    darkNav.style.pointerEvents = "auto";
  }, 850);
}

function closeNav() {
  navCloser.disabled = true;
  darkNav.style.pointerEvents = "none";
  navCnt.classList.toggle("deactive");

  setTimeout(() => {
    animateNav("0");
    darkNav.classList.toggle("deactive");
  }, 400);

  setTimeout(() => {
    navToggler.disabled = false;
    navToggler.style.opacity = "1";
    document.body.style.overflowY = "auto";
  }, 600);

  closeTypes();
  closeConnect();
  closeShop();
}

function animateNavSet(navSet, h) {
  navSet.style.height = h;
}

const typesToggler = document.getElementById("typesToggler");
const typesCloser = document.getElementById("typesCloser");
typesCloser.style.display = "none";
const typesSet = document.getElementById("typesSet");

function openTypes() {
  typesToggler.style.display = "none";
  typesCloser.style.display = "flex";
  animateNavSet(typesSet, "100%");
}
function closeTypes() {
  typesToggler.style.display = "flex";
  typesCloser.style.display = "none";
  animateNavSet(typesSet, "0");
}

const connectToggler = document.getElementById("connectToggler");
const connectCloser = document.getElementById("connectCloser");
connectCloser.style.display = "none";
const connectSet = document.getElementById("connectSet");

function openConnect() {
  connectToggler.style.display = "none";
  connectCloser.style.display = "flex";
  animateNavSet(connectSet, "100%");
}
function closeConnect() {
  connectToggler.style.display = "flex";
  connectCloser.style.display = "none";
  animateNavSet(connectSet, "0");
}

const shopToggler = document.getElementById("shopToggler");
const shopCloser = document.getElementById("shopCloser");
shopCloser.style.display = "none";
const shopSet = document.getElementById("shopSet");

function openShop() {
  shopToggler.style.display = "none";
  shopCloser.style.display = "flex";
  animateNavSet(shopSet, "100%");
}
function closeShop() {
  shopToggler.style.display = "flex";
  shopCloser.style.display = "none";
  animateNavSet(shopSet, "0");
}

navToggler.addEventListener("click", () => {
  openNav();
});
navCloser.addEventListener("click", () => {
  closeNav();
});

typesToggler.addEventListener("click", openTypes);
typesCloser.addEventListener("click", closeTypes);
connectToggler.addEventListener("click", openConnect);
connectCloser.addEventListener("click", closeConnect);
shopToggler.addEventListener("click", openShop);
shopCloser.addEventListener("click", closeShop);

window.onclick = function (e) {
  if (e.target == darkNav) {
    closeNav();
  }
};
