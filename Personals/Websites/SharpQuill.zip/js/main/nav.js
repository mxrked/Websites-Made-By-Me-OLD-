/*

    This script is for the nav

*/

const nav = document.getElementById("navLinks");
const nBox = document.getElementById("navLinksBox");
const navOpener = document.getElementById("navToggler");
const navLeaver = document.getElementById("navCloser");
const nDarken = document.getElementById("navDarken");

nDarken.classList.toggle("deactive");
nDarken.style.pointerEvents = "none";
nBox.classList.toggle("deactive");
nav.style.width = "0";

function openNav() {
  document.body.style.overflowY = "hidden";
  navOpener.disabled = true;
  navOpener.style.opacity = ".5";

  nDarken.classList.remove("deactive");
  setTimeout(() => {
    nav.style.width = "100%";
  }, 300);
  setTimeout(() => {
    nBox.classList.remove("deactive");
    navLeaver.disabled = false;
  }, 1000);
  setTimeout(() => {
    nDarken.style.pointerEvents = "auto";
  }, 1800);
}

function closeNav() {
  navLeaver.disabled = true;
  nBox.classList.toggle("deactive");
  nDarken.style.pointerEvents = "none";
  setTimeout(() => {
    nav.style.width = "0";
    nDarken.classList.toggle("deactive");
  }, 500);
  setTimeout(() => {
    navOpener.disabled = false;
    navOpener.style.opacity = "1";
    document.body.style.overflowY = "auto";
  }, 1000);
}

navOpener.addEventListener("click", () => {
  openNav();
});
navLeaver.addEventListener("click", () => {
  closeNav();
  closingNavSets();
});

//? Let user click outside nav to close it
window.addEventListener("click", (e) => {
  if (e.target == nDarken) {
    closeNav();
    closingNavSets();
  }
});

const typesOpener = document.getElementById("typesToggler");
const typesLeaver = document.getElementById("typesCloser");
const tLinks = document.getElementById("typeLinks");
const determineTypeLinks = (btn1, btn2, links) => {
  typesOpener.style.display = btn1;
  typesLeaver.style.display = btn2;
  tLinks.style.height = links;
};

typesOpener.addEventListener("click", () => {
  determineTypeLinks("none", "flex", "250px");
});
typesLeaver.addEventListener("click", () => {
  determineTypeLinks("flex", "none", "0px");
});

const connectOpener = document.getElementById("connectToggler");
const connectLeaver = document.getElementById("connectCloser");
const cLinks = document.getElementById("connectLinks");

const determineConnectLinks = (btn1, btn2, links) => {
  connectOpener.style.display = btn1;
  connectLeaver.style.display = btn2;
  cLinks.style.height = links;
};

connectOpener.addEventListener("click", () => {
  determineConnectLinks("none", "flex", "150px");
});
connectLeaver.addEventListener("click", () => {
  determineConnectLinks("flex", "none", "0px");
});

function closingNavSets() {
  determineTypeLinks("flex", "none", "0px");
  determineConnectLinks("flex", "none", "0px");
}
