/*

    This script is for the shopping cart

*/

var cartI;
const cartBox = document.getElementById("shoppingCartBox");
const cartCnt = document.getElementById("shoppingCartCnt");
const cartToggler = document.getElementById("toggleSC");
const cartClearer = document.getElementById("clearSC");
const cartCloser = document.getElementById("closeSC");
const cartItemsHolder = document.getElementById("itemsHolderSC");

cartBox.classList.toggle("deactive");

function slideCart(cntMW) {
  cartCnt.style.maxWidth = cntMW;
}

function showCartCnt(state) {
  const allCartSides = document.getElementsByClassName(
    "shopping-cart-box-cnt-side"
  );

  if (state == "true") {
    for (cartI = 0; cartI < allCartSides.length; cartI++) {
      allCartSides[cartI].classList.toggle("deactive");
    }
  } else if (state == "false") {
    for (cartI = 0; cartI < allCartSides.length; cartI++) {
      allCartSides[cartI].classList.remove("deactive");
    }
  }
}

showCartCnt("true");

cartToggler.addEventListener("click", () => {
  cartToggler.disabled = true;
  cartToggler.style.opacity = ".5";
  cartBox.classList.remove("deactive");

  setTimeout(() => {
    slideCart("500px");
  }, 400);
  setTimeout(() => {
    showCartCnt("false");
  }, 1400);
});

cartCloser.addEventListener("click", () => {
  showCartCnt("true");
  setTimeout(() => {
    slideCart("0px");
  }, 500);

  setTimeout(() => {
    cartBox.classList.toggle("deactive");
  }, 1000);
  setTimeout(() => {
    cartToggler.disabled = false;
    cartToggler.style.opacity = "1";
  }, 1500);
});

// Cart

/**/
/**/
