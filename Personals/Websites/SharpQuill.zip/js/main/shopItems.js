/*

    This script will be used to grab the shop items

*/
