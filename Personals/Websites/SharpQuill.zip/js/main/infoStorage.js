/*

    This script will be used to store information relating to hedgehogs

*/

const indexTypesInfo = [
  { txt: "It contains four species, all native to Africa." },
  { txt: "There are four main species, found across European countries." },
  { txt: "It contains two species, found in Central and South Asia." },
  { txt: "It contains four species from East Asia" },
  {
    txt: "The genus contains four species from North Africa, Middle East and South Asia",
  },
];

const indexTypesP = document.querySelectorAll(".index-type-p");
indexTypesP[0].innerHTML = indexTypesInfo[0].txt;
indexTypesP[1].innerHTML = indexTypesInfo[1].txt;
indexTypesP[2].innerHTML = indexTypesInfo[2].txt;
indexTypesP[3].innerHTML = indexTypesInfo[3].txt;
indexTypesP[4].innerHTML = indexTypesInfo[4].txt;
