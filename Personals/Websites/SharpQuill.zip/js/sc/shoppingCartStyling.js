/*

    This script is for toggling the shopping cart.

*/

const shoppingCartToggler = document.getElementById("toggleSC");
const shoppingCartCloser = document.getElementById("closeSC");
const shoppingCartDarken = document.getElementById("sCDarken");
const shoppingCartBox = document.getElementById("sCBox");
const shoppingCartHolder = document.getElementById("sCHolder");

shoppingCartDarken.style.pointerEvents = "none";
shoppingCartDarken.classList.toggle("deactive");
shoppingCartHolder.classList.toggle("deactive");

function openShoppingCart() {
  shoppingCartDarken.classList.remove("deactive");

  setTimeout(() => {
    shoppingCartBox.style.width = "100%";
  }, 300);

  setTimeout(() => {
    shoppingCartHolder.classList.remove("deactive");
    shoppingCartDarken.style.pointerEvents = "auto";
  }, 800);
}

function closeShoppingCart() {
  shoppingCartDarken.style.pointerEvents = "none";
  shoppingCartHolder.classList.toggle("deactive");

  setTimeout(() => {
    shoppingCartDarken.classList.toggle("deactive");
    shoppingCartBox.style.width = "0";
  }, 500);
}

shoppingCartToggler.addEventListener("click", openShoppingCart);
shoppingCartCloser.addEventListener("click", closeShoppingCart);
window.addEventListener("click", (e) => {
  if (e.target == shoppingCartDarken) {
    closeShoppingCart();
  }
});
