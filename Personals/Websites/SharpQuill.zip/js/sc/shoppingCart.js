/*

    This script is for the shopping cart.

  source: https://peet86.github.io/cart-localstorage/


*/

function renderSC(items) {
  const shoppingCartCart = document.getElementById("sCCart");
  const shoppingCartTotal = document.getElementById("sCTotal");

  shoppingCartCart.innerHTML = items
    .map(
      (item) => `
        <tr>
        
        <td><img src="${item.img}"></td>
        <td>#${item.id}</td>
        <td>${item.name}</td>
        <td>${item.quantity}</td>
        <td style="width: 60px;">

            <button type="button" class="sc-btn quantity-add" onClick="cartLS.quantity(${item.id},1)">+</button>
        
        </td>

        <td style="width: 60px;">
        
            <button type="button" class="sc-btn quantity-remove" onClick="cartLS.quantity(${item.id},-1)">-</button>

        </td>


        <td class="sc-item-price">$${item.price}</td>
        <td class="sc-item-remove">
        <button class="sc-item-remove-btn" onClick="cartLS.remove(${item.id})">Delete</button>
        </td>

        </tr>
    `
    )
    .join("");

  shoppingCartTotal.innerHTML = "$" + cartLS.total();
}

renderSC(cartLS.list());
cartLS.onChange(renderSC);
