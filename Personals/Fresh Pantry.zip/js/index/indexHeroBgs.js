/*

    This script is for the indexHero bgs

*/

const allIndexHeroBGS_Classes =
  document.getElementsByClassName("index-hero-bg");

var indexHeroI;

hideAllBGS();
function hideAllBGS() {
  for (
    indexHeroI = 0;
    indexHeroI < allIndexHeroBGS_Classes.length;
    indexHeroI++
  ) {
    allIndexHeroBGS_Classes[indexHeroI].style.opacity = "0";
  }
}

const background1 = document.getElementById("bg1");
const background2 = document.getElementById("bg2");
const background3 = document.getElementById("bg3");

showFirstBG();
function showFirstBG() {
  background1.style.opacity = "1";
}

function showSecondBG() {
  background2.style.opacity = "1";
}

function showThirdBG() {
  background3.style.opacity = "1";
}

changeBg();
function changeBg() {
  setInterval(() => {
    hideAllBGS();
    showFirstBG();
  }, 6000);
  setInterval(() => {
    hideAllBGS();
    showSecondBG();
  }, 12000);
  setInterval(() => {
    hideAllBGS();
    showThirdBG();
  }, 18000);
}

const loopBGS = setInterval(changeBg, 24000);
