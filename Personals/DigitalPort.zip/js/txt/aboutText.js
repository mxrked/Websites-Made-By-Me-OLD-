/*

    This script is for the aboutText

*/

const aboutTexts = document.querySelectorAll(".about-text");
const aboutTextsCnt = [
  {
    txt: "I have been studying in the Web Development field for about 3 years now and have no intention to stop learning. I currently create my projects by hand and use the resources to my advantage to get the best results possible.",
  },
  {
    txt: "I have an Associate's Degree in Web Technologies and I am currently earning my Associates Degree in Programming and Software Development, both of which are from Forsyth Tech Community College, NC.",
  },
];

aboutTexts[0].innerHTML = aboutTextsCnt[0].txt;
aboutTexts[1].innerHTML = aboutTextsCnt[1].txt;
