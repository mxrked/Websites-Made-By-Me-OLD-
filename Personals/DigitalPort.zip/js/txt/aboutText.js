/*

    This script is for the aboutText

*/

// const aboutTexts = document.querySelectorAll('.about-text');
// const aboutTextsCnt = [];
