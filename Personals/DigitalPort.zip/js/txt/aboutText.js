/*

    This script is for the aboutText

*/

const aboutTexts = document.querySelectorAll(".about-text");
const aboutTextsCnt = [
  {
    txt: "I have been studying in the Web Development field for about 3 years now and have no intention to stop learning. I currently create my projects by hand and use the resources to my advantage to get the best results possible.",
  },
  {
    txt: "I have an Associate's Degree in Web Technologies and I am currently earning my Associates Degree in Programming and Software Development, both of which are from Forsyth Tech Community College, NC.",
  },
  {
    txt: "My main goal is to become an expert in the field of Web Development and being able to create a DYNAMIC and COMPLEX website for myself or a company. I am willing to work with a team to get the job done if necessary.",
  },
  {
    txt: "I would also like to become more fluid with JavaScript and start working with a framework such as React, etc.",
  },
];

aboutTexts[0].innerHTML = aboutTextsCnt[0].txt;
aboutTexts[1].innerHTML = aboutTextsCnt[1].txt;
aboutTexts[2].innerHTML = aboutTextsCnt[2].txt;
aboutTexts[3].innerHTML = aboutTextsCnt[3].txt;
