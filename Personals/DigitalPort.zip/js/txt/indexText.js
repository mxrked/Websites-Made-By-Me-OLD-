/*

    This script is for the indexText

*/

const indexTexts = document.querySelectorAll(".index-text");

// Text storage
const indexTextsCnt = [
  {
    txt: "Currently, I am studying for my Programming Degree and so far I have an Associates Degree in Web Techonologies and during my freetime, I learn and build with the Web Fundamentals (HTML, CSS, JavaScript) and much more.",
  },
  {
    txt: "When I am not working my craft, I am enjoying my time as a big brother for 2, watching movies and playing games with friends or just relaxing in general.",
  },
  {
    txt: "The Websites section will display the different websites I have created during my time studying and crafting.",
  },
  {
    txt: "The Snippets section will display the different JavaScript side projects I have created that are not really related to my websites.",
  },
  {
    txt: "If you have interest in having a website/webpage created for personal or company reasons, you can contact me via phone or contact form. ",
  },
];

// Linking text
indexTexts[0].innerHTML = indexTextsCnt[0].txt;
indexTexts[1].innerHTML = indexTextsCnt[1].txt;
indexTexts[2].innerHTML = indexTextsCnt[2].txt;
indexTexts[3].innerHTML = indexTextsCnt[3].txt;
indexTexts[4].innerHTML = indexTextsCnt[4].txt;
