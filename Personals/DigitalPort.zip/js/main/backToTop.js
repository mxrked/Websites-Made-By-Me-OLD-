/*

    This script is for the backToTop btn

*/

mainBackToTopBtnInit();
function mainBackToTopBtnInit() {
  const backToTopBtn = document.getElementById("backToTop");
  backToTopBtn.style.display = "none";

  function checkBackToTopBtn() {
    if (window.scrollY >= 920) {
      backToTopBtn.style.display = "grid";
    } else {
      backToTopBtn.style.display = "none";
    }
  }

  backToTopBtn.addEventListener("click", () => {
    window.scrollTo(0, 0);
  });
  window.addEventListener("scroll", checkBackToTopBtn);
}
