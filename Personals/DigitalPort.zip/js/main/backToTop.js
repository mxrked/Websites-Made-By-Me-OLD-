/*

    This script is for the backToTopBtn

*/

const backToTopBtn = document.getElementById("backToTop");

determineBackToTop();
function determineBackToTop() {
  if (window.scrollY >= 400) {
    backToTopBtn.style.bottom = "10px";
  } else if (window.scrollY <= 100) {
    backToTopBtn.style.bottom = "-100px";
  }
}

window.addEventListener("scroll", determineBackToTop);
backToTopBtn.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
