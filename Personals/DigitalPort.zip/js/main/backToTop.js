/*

    This script is for the backToTopBtn

*/

mainBackToTopBtnInit();
function mainBackToTopBtnInit() {
  const backToTopBtn = document.getElementById("backToTop");

  backToTopBtn.style.bottom = "-60px";

  function checkBackToTop() {
    if (window.scrollY <= 300) {
      backToTopBtn.style.bottom = "-60px";
    } else {
      backToTopBtn.style.bottom = "20px";
    }
  }

  window.addEventListener("scroll", checkBackToTop);
  backToTopBtn.addEventListener("click", () => {
    window.scrollTo(0, 0);
  });
}
