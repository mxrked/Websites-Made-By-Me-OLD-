/*

    This script is for the page transitions and full seconds

*/

pageTransitionsInit();

function pageTransitionsInit() {
  const ALL_PAGE_TRANSITIONS = document.querySelectorAll(
    ".page-transition-item"
  );
  ALL_PAGE_TRANSITIONS.forEach((pt) => {
    pt.classList.toggle("page-transition");
  });

  const ALL_FULL_SECONDS = document.querySelectorAll(".full-second-item");
  ALL_FULL_SECONDS.forEach((fs) => {
    fs.classList.toggle("full-second");
  });
}
