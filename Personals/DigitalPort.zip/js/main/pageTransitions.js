/*

    This script is for the page transitions and full seconds

*/

pageTransitionsInit();

function pageTransitionsInit() {
  const allPageTransitions = document.querySelectorAll(".page-transition-item");

  allPageTransitions.forEach((pt) => {
    pt.classList.toggle("page-transition");
  });

  const allFullSeconds = document.querySelectorAll(".full-second-item");

  allFullSeconds.forEach((fs) => {
    fs.classList.toggle("full-second");
  });
}
