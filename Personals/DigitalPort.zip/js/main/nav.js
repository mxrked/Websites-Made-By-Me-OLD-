/*

    This script is for the nav

*/

const navToggler = document.getElementById("mobileNavToggler");
const navCloser = document.getElementById("mobileNavCloser");
const navLinks = document.getElementById("mobileNavLinks");
const navLink = document.querySelectorAll(".nav-link");
const navLinksCnt = document.querySelector(".mobile-nav-links-cnt");
navLinks.style.overflowY = "hidden";
navLinksCnt.classList.toggle("deactive");

function openNav() {
  document.body.style.overflowY = "hidden";
  navToggler.disabled = true;
  navLinks.style.maxHeight = "100%";

  backToTopBtn.disabled = true;
  backToTopBtn.style.opacity = ".3";

  setTimeout(() => {
    navLinks.style.overflowY = "auto";
  }, 1200);
  setTimeout(() => {
    navLinksCnt.classList.remove("deactive");
    navCloser.disabled = false;
  }, 1200);

  checkNavToggler();
}

function closeNav() {
  document.body.style.overflowY = "hidden";
  navLinks.style.overflowY = "hidden";
  navLinksCnt.classList.toggle("deactive");

  navCloser.disabled = true;

  setTimeout(() => {
    navLinks.style.maxHeight = "0";
  }, 500);
  setTimeout(() => {
    backToTopBtn.disabled = false;
    backToTopBtn.style.opacity = "1";
  }, 1200);
  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 2000);
  setTimeout(() => {
    navToggler.disabled = false;
    navToggler.style.opacity = 1;
  }, 2600);
}

// Opacity change for navToggler based on disabled
function checkNavToggler() {
  if (navToggler.disabled == true) {
    navToggler.style.opacity = ".4";
  }
}

navLink.forEach((link) => {
  link.addEventListener("click", closeNav);
});

navToggler.addEventListener("click", openNav);
navCloser.addEventListener("click", closeNav);
