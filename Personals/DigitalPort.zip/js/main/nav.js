/*

    This script is for the nav

*/

const navToggler = document.getElementById("mobileNavToggler");
const navCloser = document.getElementById("mobileNavCloser");
const navLinks = document.getElementById("mobileNavLinks");
const navLinksCnt = document.querySelector(".mobile-nav-links-cnt");
document.body.style.overflowY = "auto";
navLinksCnt.classList.toggle("deactive");

function openNav() {
  document.body.style.overflowY = "hidden";
  navToggler.disabled = true;
  navLinks.style.maxHeight = "100%";

  setTimeout(() => {
    navLinks.style.overflowY = "auto";
  }, 1200);
  setTimeout(() => {
    navLinksCnt.classList.remove("deactive");
  }, 1200);

  checkNavToggler();
}

function closeNav() {
  document.body.style.overflowY = "hidden";
  navLinks.style.overflowY = "hidden";
  navLinksCnt.classList.toggle("deactive");

  setTimeout(() => {
    navLinks.style.maxHeight = "0";
  }, 500);
  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 2000);
  setTimeout(() => {
    navToggler.disabled = false;
    navToggler.style.opacity = 1;
  }, 2600);
}

// Opacity change for navToggler based on disabled
function checkNavToggler() {
  if (navToggler.disabled == true) {
    navToggler.style.opacity = ".4";
  }
}

navToggler.addEventListener("click", openNav);
navCloser.addEventListener("click", closeNav);
