/*

    This script is for the nav.

*/

const NAV_TOGGLER = document.getElementById("navToggler");
const NAV_CLOSER = document.getElementById("navCloser");
const NAV_LINKS = document.getElementById("navLinks");
const NAV_LINKS_CONTENT = document.getElementById("navLinksContent");
const DARKEN_LAYER = document.getElementById("darkenLayer");

DARKEN_LAYER.classList.toggle("deactive");
DARKEN_LAYER.style.display = "none";
NAV_LINKS_CONTENT.classList.toggle("deactive");

NAV_TOGGLER.style.top = "0px";

// Open Nav

NAV_TOGGLER.addEventListener("click", () => {
  setTimeout(() => {
    NAV_TOGGLER.style.top = "-70px";
    hideJumpers(); //* pageJumperFadeIns.js
  }, 100);

  DARKEN_LAYER.style.display = "block";

  setTimeout(() => {
    DARKEN_LAYER.classList.remove("deactive");
  }, 50);

  NAV_LINKS.style.width = "100%";

  setTimeout(() => {
    NAV_LINKS_CONTENT.classList.remove("deactive");
  }, 500);
});

// Close Nav

NAV_CLOSER.addEventListener("click", closeNav);

function closeNav() {
  DARKEN_LAYER.classList.toggle("deactive");

  NAV_LINKS.style.width = "0";

  NAV_LINKS_CONTENT.classList.toggle("deactive");

  setTimeout(() => {
    NAV_TOGGLER.style.top = "0px";
    showJumpers(); //* pageJumperFadeIns.js
  }, 1000);
}

window.onclick = function (event) {
  // Allows user to click outside of nav to close it
  if (event.target == NAV_LINKS) {
    closeNav();
  }
};
