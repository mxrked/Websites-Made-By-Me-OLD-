/*

    This script is for the nav

*/

const NAV_TOGGLER = document.getElementById("navToggler");
const NAV_CLOSER = document.getElementById("navCloser");
const NAV_LINKS = document.getElementById("navLinks");
const NAV_LINKS_CONTENT = document.getElementById("navLinksContent");
const DARKEN_LAYER = document.getElementById("darkenLayer");

setTimeout(() => {
  // Drops the navToggler after the video background has fully loaded in
  NAV_TOGGLER.style.top = "0";
}, 2150);

DARKEN_LAYER.classList.toggle("deactive");
DARKEN_LAYER.style.display = "none";
NAV_LINKS_CONTENT.classList.toggle("deactive");

// Open Nav

NAV_TOGGLER.addEventListener("click", () => {
  // Makes the toggler and pageSectJumper slide out of frame
  NAV_TOGGLER.style.top = "-60px";
  pageSectJumper.style.bottom = "-250px";

  DARKEN_LAYER.style.display = "block";

  setTimeout(() => {
    DARKEN_LAYER.classList.remove("deactive");
  }, 50);

  NAV_LINKS.style.width = "100%";

  setTimeout(() => {
    NAV_LINKS_CONTENT.classList.remove("deactive");
  }, 500);
});

function closeNav() {
  DARKEN_LAYER.classList.toggle("deactive");

  NAV_LINKS.style.width = "0";

  NAV_LINKS_CONTENT.classList.toggle("deactive");

  setTimeout(() => {
    // Slides navToggler and pageSectJumper back into frame
    NAV_TOGGLER.style.top = "0";
    PAGE_SECT_JUMPER.style.bottom = "0";
  }, 900);
}

NAV_CLOSER.addEventListener("click", closeNav);

window.onclick = function (e) {
  // Allows user to click outside of the nav to close it

  if (e.target == NAV_LINKS) {
    closeNav();
  }
};
