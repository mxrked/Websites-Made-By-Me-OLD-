/*

    This script is for the nav

*/

const NAV_TOGGLER = document.getElementById("navToggler");
const NAV_CLOSER = document.getElementById("navCloser");
const NAV_LINKS = document.getElementById("respNavLinks");
const ALL_RESP_NAV_ITEMS = document.getElementsByClassName("resp-nav-item");
var respNavI;

//
//
//

// Hides the respNavLinks content
hideRespNavItems();
function hideRespNavItems() {
  for (respNavI = 0; respNavI < ALL_RESP_NAV_ITEMS.length; respNavI++) {
    ALL_RESP_NAV_ITEMS[respNavI].classList.toggle("deactive");
  }
}

function toggleNav() {
  document.body.style.overflowY = "hidden";

  NAV_TOGGLER.classList.toggle("deactive");

  setTimeout(() => {
    NAV_LINKS.style.maxHeight = "100vh";
  }, 600);

  setTimeout(() => {
    for (respNavI = 0; respNavI < ALL_RESP_NAV_ITEMS.length; respNavI++) {
      ALL_RESP_NAV_ITEMS[respNavI].classList.remove("deactive");
    }
  }, 1800);
}

function closeNav() {
  hideRespNavItems();

  setTimeout(() => {
    NAV_LINKS.style.maxHeight = "0";
  }, 700);

  setTimeout(() => {
    NAV_TOGGLER.classList.remove("deactive");
    document.body.style.overflowY = "auto";
  }, 1800);
}

//
//
//

NAV_TOGGLER.addEventListener("click", toggleNav);
NAV_CLOSER.addEventListener("click", closeNav);
