/*

    This script is for the nav

*/

const navToggler = document.getElementById("navToggler");
const navCloser = document.getElementById("navCloser");
const navLinks = document.getElementById("navLinks");
const allNavTogglerBars = document.querySelectorAll(".nav-toggler-bar");
const navLinksCnt = document.getElementById("navLinksCnt");

navLinks.style.display = "none";
navLinks.classList.toggle("deactive");
navLinksCnt.classList.toggle("deactive");

const defaultColor = "#4828ec";
const hoveredColor = "#170e42";

function lockNTBars(w, bgc) {
  allNavTogglerBars[0].style.width = w;
  allNavTogglerBars[2].style.width = w;
  allNavTogglerBars.forEach((bar) => {
    bar.style.backgroundColor = bgc;
  });
}

function openNav() {
  document.getElementById("mainBodyInner").style.opacity = ".5";
  navLinks.style.display = "grid";
  lockNTBars("15px", hoveredColor);
  navToggler.disabled = true;

  setTimeout(() => {
    navLinks.classList.remove("deactive");
  }, 200);

  setTimeout(() => {
    navCloser.disabled = false;
    navLinksCnt.classList.remove("deactive");
  }, 400);
}

function closeNav() {
  navCloser.disabled = true;
  navLinksCnt.classList.toggle("deactive");
  setTimeout(() => {
    navLinks.classList.toggle("deactive");
  }, 300);

  setTimeout(() => {
    navLinks.style.display = "none";
  }, 1100);

  setTimeout(() => {
    lockNTBars("30px", defaultColor);
    navToggler.disabled = false;
    document.getElementById("mainBodyInner").style.opacity = "1";
  }, 1300);
}

navToggler.addEventListener("click", openNav);
navCloser.addEventListener("click", closeNav);
navToggler.addEventListener("mouseenter", () => {
  allNavTogglerBars.forEach((bar) => {
    bar.style.backgroundColor = hoveredColor;
  });
});
navToggler.addEventListener("mouseleave", () => {
  allNavTogglerBars.forEach((bar) => {
    bar.style.backgroundColor = defaultColor;
  });
});
