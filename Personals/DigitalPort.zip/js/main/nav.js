/*

    This script is for the nav

*/

mainRespNavInit();
function mainRespNavInit() {
  const navToggler = document.getElementById("navToggler");
  const navCloser = document.getElementById("navCloser");
  const navLinks = document.getElementById("respNavLinks");
  const navLinksCnt = document.getElementById("respNavLinksCnt");

  navLinksCnt.classList.toggle("deactive");

  // Open nav
  function toggleNav() {
    document.body.style.overflowY = "hidden";
    navCloser.disabled = false;
    navToggler.disabled = true;
    navToggler.classList.toggle("deactive");
    setTimeout(() => {
      navLinks.style.height = "100%";
    }, 300);

    setTimeout(() => {
      navLinksCnt.classList.remove("deactive");
    }, 1200);
  }

  // Closer nav
  function closeNav() {
    navCloser.disabled = true;
    navToggler.disabled = false;

    navLinksCnt.classList.toggle("deactive");

    setTimeout(() => {
      navLinks.style.height = "0";
    }, 300);

    setTimeout(() => {
      navToggler.classList.remove("deactive");
      document.body.style.overflowY = "auto";
    }, 1200);
  }

  // Change navBtn divs bg color to a different color contrast
  checkNavScreenSize();
  function checkNavScreenSize() {
    const indexNavBoxBtnDivs = document.querySelectorAll(
      "#indexNavBox button div"
    );

    if (window.innerWidth <= 1370) {
      indexNavBoxBtnDivs.forEach((div) => {
        div.style.background = "white";
      });
    } else {
      indexNavBoxBtnDivs.forEach((div) => {
        div.style.background = "#09348a";
      });
    }
  }

  window.addEventListener("resize", () => {
    checkNavScreenSize();
  });
  navToggler.addEventListener("click", toggleNav);
  navCloser.addEventListener("click", closeNav);
}
