/*

    This script is for the nav

*/

mainRespNavInit();
function mainRespNavInit() {
  const navToggler = document.getElementById("navToggler");
  const navCloser = document.getElementById("navCloser");
  const navLinks = document.getElementById("respNavLinks");
  const navLinksCnt = document.getElementById("respNavLinksCnt");

  navLinksCnt.classList.toggle("deactive");

  function toggleNav() {
    document.body.style.overflowY = "hidden";
    navCloser.disabled = false;
    navToggler.disabled = true;
    navToggler.classList.toggle("deactive");
    setTimeout(() => {
      navLinks.style.height = "100%";
    }, 300);

    setTimeout(() => {
      navLinksCnt.classList.remove("deactive");
    }, 1200);
  }

  function closeNav() {
    navCloser.disabled = true;
    navToggler.disabled = false;

    navLinksCnt.classList.toggle("deactive");

    setTimeout(() => {
      navLinks.style.height = "0";
    }, 300);

    setTimeout(() => {
      navToggler.classList.remove("deactive");
      document.body.style.overflowY = "auto";
    }, 1200);
  }

  navToggler.addEventListener("click", toggleNav);
  navCloser.addEventListener("click", closeNav);
}
