/*

    This script is for the responsive nav.

*/

// This will be the main function that will be a MAIN SCOPE
mainNavInit();
function mainNavInit() {
  const navLinks = document.getElementById("navLinks");
  const navToggler = document.getElementById("navToggler");
  const navCloser = document.getElementById("navCloser");
  const navLinksCnt = document.getElementById("navLinksCnt");

  // Closing nav
  closeNav();
  function closeNav() {
    navLinks.style.maxHeight = 0;
    navCloser.classList.toggle("deactive");
    navLinks.style.overflowY = "hidden";

    setTimeout(() => {
      navToggler.classList.remove("deactive");
      document.body.style.overflowY = "auto";
    }, 1200);

    setTimeout(() => {
      navLinksCnt.classList.toggle("deactive");
    }, 100);
  }

  // Opening nav
  function openNav() {
    navLinks.style.maxHeight = "100vh";
    navToggler.classList.toggle("deactive");
    document.body.style.overflowY = "hidden";

    setTimeout(() => {
      navLinks.style.overflowY = "auto";
    }, 600);

    setTimeout(() => {
      navCloser.classList.remove("deactive");
      navLinksCnt.classList.remove("deactive");
    }, 900);
  }

  //
  //
  //

  // Work Links Code
  workLinksManip();
  function workLinksManip() {
    const workLinksToggler = document.getElementById("navWorkToggler");
    const workLinksCloser = document.getElementById("navWorkCloser");
    const workLinks = document.getElementById("navWorkLinks");

    // Opening workLinks
    function openWorkLinks() {
      workLinksToggler.style.display = "none";
      workLinksCloser.style.display = "inline";
      workLinks.style.maxHeight = "300px";
    }

    // Closing workLinks
    closeWorkLinks();
    function closeWorkLinks() {
      workLinksToggler.style.display = "inline";
      workLinksCloser.style.display = "none";
      workLinks.style.maxHeight = "0";
    }

    // WorkLinks events
    workLinksToggler.addEventListener("click", openWorkLinks);
    workLinksCloser.addEventListener("click", closeWorkLinks);
    navCloser.addEventListener("click", closeWorkLinks); // if user closes navLinks, it closes the workLinks aswell
  } //* Leaving workLinksManip()

  //
  //
  //

  // Resp Nav Events
  navToggler.addEventListener("click", openNav);
  navCloser.addEventListener("click", closeNav);
} //* Leaving mainNavInit()
