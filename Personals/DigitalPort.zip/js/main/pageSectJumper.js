/*

    This script is for the pageSectJumper

    !THIS SCRIPT WAS A P̲A̲I̲N̲ ̲I̲N̲ ̲T̲H̲E̲ ̲A̲S̲S̲ but it was fun :)


*/

const ALL_PAGE_JUMP_BTNS = document.querySelectorAll(".page-jumper-btn");
const ALL_PAGE_JUMP_SHAPES = document.querySelectorAll(".page-jumper-btn span");
const ALL_PAGE_SECTIONS = [
  (indexSect1 = document.getElementById("indexIntro")),

  //TODO: Uncomment when working on indexAbout
  // (indexSect2 = document.getElementById("indexAbout")),
];

var i;

//! Functions

//* Styling Resets
function resetPageJumpBtns() {
  const ALL_PJ_BTN_CLASSES = document.getElementsByClassName("page-jumper-btn");
  for (i = 0; i < ALL_PJ_BTN_CLASSES.length; i++) {
    ALL_PJ_BTN_CLASSES[i].style.background = "rgb(24,24,24)";
  }
}

function resetPageJumpShapes() {
  const ALL_PJ_BTN_SHAPE_CLASSES = document.getElementsByClassName(
    "page-jumper-btn-shape"
  );
  for (i = 0; i < ALL_PJ_BTN_SHAPE_CLASSES.length; i++) {
    ALL_PJ_BTN_SHAPE_CLASSES[i].style.transform = "rotate(0deg)";
  }
}

//* Checking what btns to highlight and not highlight
checkSectionTops(); //The setTimeOuts is for whenever the section is hit, that btn will highlight as the scrolling resets the btns styling so this will counter act that.

function checkSectionTops() {
  //? Top of Index Intro
  if (window.scrollY == ALL_PAGE_SECTIONS[0].offsetTop) {
    setTimeout(() => {
      ALL_PAGE_JUMP_BTNS[0].style.background = "black";
      ALL_PAGE_JUMP_SHAPES[0].style.transform = "rotate(90deg)";
    }, 70);
  } else {
    resetPageJumpBtns();
    resetPageJumpShapes();
  }

  //TODO: Uncomment when working on indexAbout
  // if (window.scrollY == ALL_PAGE_SECTIONS[1].offsetTop) {
  //   // Top of Index About
  //   setTimeout(() => {
  //     ALL_PAGE_JUMP_BTNS[1].style.background = "black";
  //     ALL_PAGE_JUMP_SHAPES[1].style.transform = "rotate(90deg)";
  //   }, 70);
  // } else {
  //   resetPageJumpBtns();
  //   resetPageJumpShapes();
  // }
}

//! Event Listeners

//* Btn Events
//The setTimeOuts is for whenever the section is hit, that btn will highlight as the scrolling resets the btns styling so this will counter act that.
ALL_PAGE_JUMP_BTNS[0].addEventListener("click", () => {
  setTimeout(() => {
    ALL_PAGE_JUMP_BTNS[0].style.background = "black";
    ALL_PAGE_JUMP_SHAPES[0].style.transform = "rotate(90deg)";
  }, 70);
  ALL_PAGE_SECTIONS[0].scrollIntoView();
});

//TODO: Uncomment when working on indexAbout
// ALL_PAGE_JUMP_BTNS[1].addEventListener("click", () => {
//   setTimeout(() => {
//     ALL_PAGE_JUMP_BTNS[1].style.background = "black";
//     ALL_PAGE_JUMP_SHAPES[1].style.transform = "rotate(90deg)";
//   }, 70);
//   ALL_PAGE_SECTIONS[1].scrollIntoView();
// });

//* Scrolling Event
window.addEventListener("scroll", () => {
  resetPageJumpBtns();
  resetPageJumpShapes();
  checkSectionTops();
});
