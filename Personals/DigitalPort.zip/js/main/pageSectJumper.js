/*

    This script is for the pageSectJumper

*/

const PAGE_SECT_JUMPER = document.getElementById("pageSectJumper");

PAGE_SECT_JUMPER.style.bottom = "-250px";

setTimeout(() => {
  // Slides pageSectJumper into frame
  PAGE_SECT_JUMPER.style.bottom = "0";
}, 2150);

const INDEX_PAGE_JUMPER_SHAPES = [
  (jumperShape1 = document.getElementById("jumper1Shape")),
  (jumperShape2 = document.getElementById("jumper2Shape")),
];

const INDEX_PAGE_JUMPER_TRIGGERS = [
  (jumperTrigger1 = document.getElementById("indexJT1")),
  (jumperTrigger2 = document.getElementById("indexJT2")),
];

// Reseting the animations
resetShapes();
resetJumpers();

function resetShapes() {
  INDEX_PAGE_JUMPER_SHAPES.forEach((shape) => {
    shape.style.transform = "rotate(0deg)";
  });
}

function resetJumpers() {
  INDEX_PAGE_JUMPER_TRIGGERS.forEach((jumper) => {
    jumper.style.background = "rgb(24, 24, 24)";
  });
}

// Trigger Events
INDEX_PAGE_JUMPER_TRIGGERS[0].addEventListener("click", () => {
  resetShapes();
  resetJumpers();
  INDEX_PAGE_JUMPER_SHAPES[0].style.transform = "rotate(90deg)";
  INDEX_PAGE_JUMPER_TRIGGERS[0].style.background = "black";
});

INDEX_PAGE_JUMPER_TRIGGERS[1].addEventListener("click", () => {
  resetShapes();
  resetJumpers();
  INDEX_PAGE_JUMPER_SHAPES[1].style.transform = "rotate(90deg)";
  INDEX_PAGE_JUMPER_TRIGGERS[1].style.background = "black";
});
