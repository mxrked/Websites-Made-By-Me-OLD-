/*

    This script is for the pageSectJumper

*/

const PAGE_SECT_JUMPER = document.getElementById("pageSectJumper");
const ALL_PAGE_SECTS = [
  document.getElementById("indexHero"),
  document.getElementById("indexAbout"),
  document.getElementById("indexWork"),
];
const ALL_PAGE_SECT_JUMPER_STICKS = document.querySelectorAll(
  ".page-sect-jumper-stick"
);
const ALL_SECT_JUMPER_BTNS = document.querySelectorAll(".page-sect-jumper-btn");
var stickTrigger;

// Main Jump function
function pageSectJumper(jump) {
  var jumpTop = document.getElementById(jump).offsetTop;
  window.scrollTo(0, jumpTop);
}

function resetSticks() {
  for (
    stickTrigger = 0;
    stickTrigger < ALL_PAGE_SECT_JUMPER_STICKS.length;
    stickTrigger++
  ) {
    ALL_PAGE_SECT_JUMPER_STICKS[stickTrigger].style.borderRadius = "0";
    ALL_PAGE_SECT_JUMPER_STICKS[stickTrigger].style.height = "3px";
  }
}

function checkScrollYSect() {
  switch (window.scrollY) {
    case ALL_PAGE_SECTS[0].offsetTop:
      ALL_PAGE_SECT_JUMPER_STICKS[0].style.borderRadius = "100%";
      ALL_PAGE_SECT_JUMPER_STICKS[0].style.height = "10px";
      break;
    case ALL_PAGE_SECTS[1].offsetTop:
      ALL_PAGE_SECT_JUMPER_STICKS[1].style.borderRadius = "100%";
      ALL_PAGE_SECT_JUMPER_STICKS[1].style.height = "10px";
      break;

    case ALL_PAGE_SECTS[2].offsetTop:
      ALL_PAGE_SECT_JUMPER_STICKS[2].style.borderRadius = "100%";
      ALL_PAGE_SECT_JUMPER_STICKS[2].style.height = "10px";
      break;

    default:
      resetSticks();
  }
}

// When user jumps
function checkSectStateScreenY() {
  // Index Page
  if (window.screenY == ALL_PAGE_SECTS[0].offsetTop) {
    ALL_PAGE_SECT_JUMPER_STICKS[0].style.borderRadius = "100%";
    ALL_PAGE_SECT_JUMPER_STICKS[0].style.height = "10px";
  } else if (window.screenY == ALL_PAGE_SECTS[1].offsetTop) {
    ALL_PAGE_SECT_JUMPER_STICKS[1].style.borderRadius = "100%";
    ALL_PAGE_SECT_JUMPER_STICKS[1].style.height = "10px";
  } else {
    resetSticks();
  }
}

window.addEventListener("load", () => {
  checkSectStateScreenY();
});
// window.addEventListener("scroll", checkSectStateScrollY);
window.addEventListener("scroll", checkScrollYSect);
