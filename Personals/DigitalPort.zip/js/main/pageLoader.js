/*

    This script is for the pageLoader

    PAIRS with indexTopFadeIns.js

*/

var pageLoaderState;

function determinePageLoaderState(state) {
  pageLoaderState = state;

  checkPageLoader();
}

determinePageLoaderState("false");

function checkPageLoader() {
  if (pageLoaderState === "true") {
    closePageLoader();
  } else if (pageLoaderState === "false") {
    document.body.style.overflowY = "hidden";
    return false;
  }
}

const pageLoader = document.getElementById("pageLoader");
const pageLoaderCnt = document.getElementById("pageLoaderCnt");
function closePageLoader() {
  pageLoaderCnt.classList.toggle("deactive");

  setTimeout(() => {
    pageLoader.style.height = "0";
  }, 1000);

  if ((pageLoader.style.height = "0")) {
    setTimeout(() => {
      document.body.style.overflowY = "auto";
    }, 500);
  }
}

window.addEventListener("load", () => {
  determinePageLoaderState("true");
});
