/*

    This script is for the pageLoader

*/

const pageLoader = document.getElementById("pageLoader");
document.body.style.overflowY = "hidden";

window.addEventListener("load", () => {
  setTimeout(() => {
    pageLoader.classList.toggle("deactive");
  }, 700);

  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 1700);
});
