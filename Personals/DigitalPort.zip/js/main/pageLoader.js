/*

    This script is for the pageLoader

*/

window.addEventListener("load", () => {
  const PAGE_LOADER = document.getElementById("pageLoader");

  PAGE_LOADER.classList.toggle("deactive");

  triggerIndexHeroFadeIns();
});
