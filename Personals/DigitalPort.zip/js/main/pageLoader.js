/*

    This script is for the pageLoader

*/

const pageLoader = document.getElementById("pageLoader");

window.addEventListener("load", () => {
  setTimeout(() => {
    pageLoader.classList.toggle("deactive");
  }, 700);
});
