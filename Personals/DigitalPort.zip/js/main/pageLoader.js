/*

    This script is for the pageLoader

*/

mainPageLoaderInit();
function mainPageLoaderInit() {
  const pageLoader = document.getElementById("pageLoader");

  document.body.style.overflowY = "hidden";

  window.addEventListener("load", () => {
    pageLoader.classList.toggle("deactive");

    setTimeout(() => {
      document.body.style.overflowY = "auto";
    }, 500);

    // Triggers indexHero after pageLoader fades on load
    setTimeout(() => {
      mainIndexHeroInit();
    }, 600);
  });
} //* Leaving mainPageLoaderInit()
