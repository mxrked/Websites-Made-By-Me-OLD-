/*

    This script is for the page jumper section fade ins

*/

const ALL_PAGE_JUMPER_HOLDERS = document.querySelectorAll(
  ".page-sect-jumper-holder"
);
const ALL_PAGE_JUMPER_LINKS = document.querySelectorAll(
  ".page-sect-jumper-link"
);

showJumpers();

function showJumpers() {
  ALL_PAGE_JUMPER_LINKS.forEach((link) => {
    link.classList.remove("deactive");
  });
}

function hideJumpers() {
  ALL_PAGE_JUMPER_LINKS.forEach((link) => {
    link.classList.toggle("deactive");
  });
}
