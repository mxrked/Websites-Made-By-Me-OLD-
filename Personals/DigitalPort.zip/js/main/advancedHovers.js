/*

    This script is for the advanced hovers that can be down better in js

*/

//* Index Advanced Hovers

const ALL_INDEX_AHS = [
  (heroImg = document.getElementById("indexHeroImg")),
  (indexAboutH2 = document.getElementById("indexAboutH2")),
  (indexAboutH2Span = document.getElementById("indexAboutH2Span")),
  (indexWorkTopH2 = document.getElementById("indexWorkTopH2")),
  (indexWorkTopH2Span = document.getElementById("indexWorkTopH2Span")),
  (indexContactH2 = document.getElementById("indexContactH2")),
  (indexContactH2Span = document.getElementById("indexContactH2Span")),
  (indexContactImg = document.getElementById("indexContactImg")),
];

// Index Hero
document.querySelector("#indexHeroBox").addEventListener("mouseenter", () => {
  ALL_INDEX_AHS[0].style.transform = "rotate(30deg)";
  setTimeout(() => {
    ALL_INDEX_AHS[0].style.transform = "rotate(-30deg)";
  }, 300);
  setTimeout(() => {
    ALL_INDEX_AHS[0].style.transform = "rotate(0deg)";
  }, 500);
});
document.querySelector("#indexHeroBox").addEventListener("mouseleave", () => {
  ALL_INDEX_AHS[0].style.transform = "rotate(0deg)";
});

// Index About
document.querySelector("#indexAboutBox").addEventListener("mouseenter", () => {
  ALL_INDEX_AHS[1].style.color = "#b24c7b";
  ALL_INDEX_AHS[2].style.color = "black";
});

document.querySelector("#indexAboutBox").addEventListener("mouseleave", () => {
  ALL_INDEX_AHS[1].style.color = "black";
  ALL_INDEX_AHS[2].style.color = "#b24c7b";
});

// Index Work
document
  .querySelector("#indexWorkTopBox")
  .addEventListener("mouseenter", () => {
    ALL_INDEX_AHS[3].style.color = "#b24c7b";
    ALL_INDEX_AHS[4].style.color = "black";
  });

document
  .querySelector("#indexWorkTopBox")
  .addEventListener("mouseleave", () => {
    ALL_INDEX_AHS[3].style.color = "black";
    ALL_INDEX_AHS[4].style.color = "#b24c7b";
  });

// Index Contact
document
  .querySelector("#indexContactBox")
  .addEventListener("mouseenter", () => {
    ALL_INDEX_AHS[5].style.color = "#b24c7b";
    ALL_INDEX_AHS[6].style.color = "black";

    ALL_INDEX_AHS[7].style.transform = "rotate(30deg)";
    setTimeout(() => {
      ALL_INDEX_AHS[7].style.transform = "rotate(-30deg)";
    }, 300);
    setTimeout(() => {
      ALL_INDEX_AHS[7].style.transform = "rotate(0deg)";
    }, 500);
  });

document
  .querySelector("#indexContactBox")
  .addEventListener("mouseleave", () => {
    ALL_INDEX_AHS[5].style.color = "black";
    ALL_INDEX_AHS[6].style.color = "#b24c7b";

    ALL_INDEX_AHS[7].style.transform = "rotate(0deg)";
  });
