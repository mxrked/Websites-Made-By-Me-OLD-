/*

    This script is for the workProjects

*/

const allWorkBtns = document.querySelectorAll(".work-project-btn");

// Resets the btns for each click
disableWorkBtns();
function disableWorkBtns() {
  allWorkBtns.forEach((btn) => {
    btn.classList.remove("active");
    btn.style.color = "#143067";
    btn.style.background = "white";
    btn.disabled = false;
  });
}

//
//
//

// Manipulating the work project rows based on btn clicked
const workWebsitesRow = document.getElementById("workWebsitesRow");
const workSnippetsRow = document.getElementById("workSnippetsRow");
function hideAllWorkRows() {
  workWebsitesRow.style.display = "none";
  workSnippetsRow.style.display = "none";
}

const workAllBtn = document.getElementById("workAllBtn");
const workWebsitesBtn = document.getElementById("workWebsitesBtn");
const workSnippetsBtn = document.getElementById("workSnippetsBtn");

//
//
//

// Setting workAllBtn to be displayed by default
workAllBtn.classList.add("active");
workAllBtn.disabled = true;

function forWorkAllBtn() {
  disableWorkBtns();
  workAllBtn.classList.add("active");
  workAllBtn.disabled = true;
  resetWorkClicks();
  workAllClicked = 1;
}
workAllBtn.addEventListener("click", forWorkAllBtn);

function forWorkWebsitesBtn() {
  disableWorkBtns();
  workWebsitesBtn.classList.add("active");
  workWebsitesBtn.disabled = true;
  resetWorkClicks();
  workWebsitesClicked = 1;
}
workWebsitesBtn.addEventListener("click", forWorkWebsitesBtn);

function forWorkSnippetsBtn() {
  disableWorkBtns();
  workSnippetsBtn.classList.add("active");
  workSnippetsBtn.disabled = true;
  resetWorkClicks();
  workSnippetsClicked = 1;
}
workSnippetsBtn.addEventListener("click", forWorkSnippetsBtn);

//
//
//

// Work Hero Triggers
const workHeroWebsiteTrigger = document.getElementById(
  "workHeroWebsitesTrigger"
);
workHeroWebsiteTrigger.addEventListener("click", () => {
  forWorkWebsitesBtn();
  checkWorkProjectsType();

  document.getElementById("workProjects").scrollIntoView();
});

const workHeroSnippetsTrigger = document.getElementById(
  "workHeroSnippetsTrigger"
);
workHeroSnippetsTrigger.addEventListener("click", () => {
  forWorkSnippetsBtn();
  checkWorkProjectsType();

  document.getElementById("workProjects").scrollIntoView();
});

//
//
//

var workAllClicked;
var workWebsitesClicked;
var workSnippetsClicked;

// Faster way of setting clicks to zero
function resetWorkClicks() {
  workAllClicked = 0;
  workWebsitesClicked = 0;
  workSnippetsClicked = 0;
}

// Determines what btn was clicked and what type projects to display
function checkWorkProjectsType() {
  switch (workAllClicked) {
    case 1:
      //   alert("All Clicked.");
      workWebsitesRow.style.display = "flex";
      workSnippetsRow.style.display = "flex";
      break;
  }

  switch (workWebsitesClicked) {
    case 1:
      //   alert("Websites Clicked.");
      hideAllWorkRows();
      workWebsitesRow.style.display = "flex";
      break;
  }

  switch (workSnippetsClicked) {
    case 1:
      //   alert("Snippets Clicked.");
      hideAllWorkRows();
      workSnippetsRow.style.display = "flex";
      break;
  }
}

//
//
//

// This will check the work type clicked for each btn
allWorkBtns.forEach((btn) => {
  btn.addEventListener("click", checkWorkProjectsType);
});
