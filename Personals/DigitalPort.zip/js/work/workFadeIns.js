/*

    This script is for the work page fade ins

*/

// Hiding in work page contents
const allWorkItems = document.getElementsByClassName("work-page-item");
var workPageI;

hideWorkPageItems();
function hideWorkPageItems() {
  for (workPageI = 0; workPageI < allWorkItems.length; workPageI++) {
    allWorkItems[workPageI].classList.toggle("deactive");
  }
}

// Index Hero Fade Ins
const workHero = document.getElementById("workHero");
const workHeroCnt = document.getElementById("workHeroCnt");

workHeroCnt.style.left = "-50px";

function showWorkHeroItems() {
  setTimeout(() => {
    workHero.classList.remove("deactive");
  }, 500);

  setTimeout(() => {
    workHeroCnt.classList.remove("deactive");
  }, 1500);

  setTimeout(() => {
    workHeroCnt.style.left = "0";
  }, 1700);
}

window.addEventListener("load", () => {
  setTimeout(() => {
    showWorkHeroItems();
  }, 500);
});
