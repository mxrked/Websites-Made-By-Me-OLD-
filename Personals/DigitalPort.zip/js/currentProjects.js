/*

    This script is for the currentProjects section

*/

var cPI;
const allCurrentProjectInners = document.getElementsByClassName(
  "current-project-inner"
);

shrinkCPIS();
function shrinkCPIS() {
  for (cPI = 0; cPI < allCurrentProjectInners.length; cPI++) {
    allCurrentProjectInners[cPI].style.height = "85%";
  }
}

document.querySelectorAll(".current-project-inner").forEach((cpi) => {
  cpi.addEventListener("mouseleave", () => {
    for (cPI = 0; cPI < allCurrentProjectInners.length; cPI++) {
      allCurrentProjectInners[cPI].style.height = "85%";
    }
  });
});

document.getElementById("cPI1").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI1").style.height = "100%";
});
document.getElementById("cPI2").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI2").style.height = "100%";
});
document.getElementById("cPI3").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI3").style.height = "100%";
});
document.getElementById("cPI4").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI4").style.height = "100%";
});
document.getElementById("cPI5").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI5").style.height = "100%";
});
document.getElementById("cPI6").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI6").style.height = "100%";
});

const allProjectBtns = document.querySelectorAll(".current-projects-btn");
const allProjectBtns_Classes = document.getElementsByClassName(
  "current-projects-btn"
);

const allBtn = document.getElementById("allProjects");
const websitesBtn = document.getElementById("websiteProjects");
const snippetsBtn = document.getElementById("snippetProjects");

const allProjectItems = document.getElementsByClassName("current-project");
const websiteItems = document.getElementsByClassName("website");
const snippetItems = document.getElementsByClassName("snippet");

// resets
function resetBtns() {
  for (cPI = 0; cPI < allProjectBtns_Classes.length; cPI++) {
    allProjectBtns_Classes[cPI].classList.remove("active-btn");
    allProjectBtns_Classes[cPI].disabled = false;
  }
}
function hideAllProjects() {
  for (cPI = 0; cPI < allProjectItems.length; cPI++) {
    allProjectItems[cPI].style.display = "none";
  }
}

function determineBtn(btn) {
  btn.classList.add("active-btn");
  btn.disabled = true;
}

// shows all projects by default
determineBtn(allBtn);
function determineType(type) {
  for (cPI = 0; cPI < type.length; cPI++) {
    type[cPI].style.display = "grid";
  }
}

allProjectBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    hideAllProjects();
    resetBtns();
  });
});
allBtn.addEventListener("click", () => {
  determineBtn(allBtn);
  determineType(allProjectItems);
});
websitesBtn.addEventListener("click", () => {
  determineBtn(websitesBtn);
  determineType(websiteItems);
});
snippetsBtn.addEventListener("click", () => {
  determineBtn(snippetsBtn);
  determineType(snippetItems);
});
