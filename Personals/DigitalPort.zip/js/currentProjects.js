/*

    This script is for the currentProjects section

*/

var cPI;
const allCurrentProjectInners = document.getElementsByClassName(
  "current-project-inner"
);

shrinkCPIS();
function shrinkCPIS() {
  for (cPI = 0; cPI < allCurrentProjectInners.length; cPI++) {
    allCurrentProjectInners[cPI].style.height = "85%";
  }
}

document.querySelectorAll(".current-project-inner").forEach((cpi) => {
  cpi.addEventListener("mouseleave", () => {
    for (cPI = 0; cPI < allCurrentProjectInners.length; cPI++) {
      allCurrentProjectInners[cPI].style.height = "85%";
    }
  });
});

document.getElementById("cPI1").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI1").style.height = "100%";
});
document.getElementById("cPI2").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI2").style.height = "100%";
});
document.getElementById("cPI3").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI3").style.height = "100%";
});
document.getElementById("cPI4").addEventListener("mouseenter", () => {
  shrinkCPIS();
  document.getElementById("cPI4").style.height = "100%";
});
