/*

    This script is for the social media box

*/

const socialMediaContainer = document.getElementById("socialMediaBox");
const socialMediaToggler = document.getElementById("openSMB");
const socialMediaCloser = document.getElementById("closeSMB");
const socialMediaDeets = document.getElementById("socialMediaLinks");
const socialMediaDeetsCnt = document.getElementById("socialMediaLinksCnt");

socialMediaContainer.style.top = "-175px";

socialMediaDeetsCnt.classList.toggle("deactive");

socialMediaToggler.addEventListener("click", () => {
  socialMediaToggler.style.display = "none";
  socialMediaCloser.style.display = "block";

  socialMediaContainer.style.top = "0";

  socialMediaCloser.disabled = true;

  setTimeout(() => {
    socialMediaDeetsCnt.classList.remove("deactive");
  }, 400);

  setTimeout(() => {
    socialMediaCloser.disabled = false;
  }, 500);
});

socialMediaCloser.addEventListener("click", () => {
  socialMediaToggler.style.display = "block";
  socialMediaCloser.style.display = "none";

  socialMediaToggler.disabled = true;

  socialMediaDeetsCnt.classList.toggle("deactive");

  setTimeout(() => {
    socialMediaContainer.style.top = "-175px";
  }, 400);
  setTimeout(() => {
    socialMediaToggler.disabled = false;
  }, 600);
});
