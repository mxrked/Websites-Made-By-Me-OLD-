/*

    This will make fade ins for aboutTop

*/

var aboutTopI;
const allAboutTopText = document.getElementsByClassName("about-top-item");
const allAboutTopItems = document.querySelectorAll(".about-top-item");

hideAboutTopCnt();
function hideAboutTopCnt() {
  for (aboutTopI = 0; aboutTopI < allAboutTopText.length; aboutTopI++) {
    allAboutTopText[aboutTopI].style.opacity = 0;
  }
}

indexTopCntFadeIns();
function indexTopCntFadeIns() {
  if ((pageLoader.style.height = "0")) {
    setTimeout(() => {
      allAboutTopItems[0].style.opacity = 0.4;
    }, 1300);
    setTimeout(() => {
      allAboutTopItems[0].style.top = "-50px";
    }, 1400);

    setTimeout(() => {
      allAboutTopItems[1].style.opacity = 1;
    }, 1500);
    setTimeout(() => {
      allAboutTopItems[1].style.left = "0px";
    }, 1600);
  }
}
