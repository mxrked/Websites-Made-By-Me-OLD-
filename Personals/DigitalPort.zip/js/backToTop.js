/*

    This script is for the backToTopBtn

*/

const b2T = document.getElementById("backToTopBtn");

function displayB2T(btm) {
  b2T.style.bottom = btm;
}
displayB2T("-100px");

function determineB2T() {
  if (window.scrollY >= 300) {
    displayB2T("20px");
  } else if (window.scrollY < 299) {
    displayB2T("-100px");
  }
}

window.addEventListener("scroll", determineB2T);
b2T.addEventListener("click", () => {
  window.scrollTo(0, 0);
});
