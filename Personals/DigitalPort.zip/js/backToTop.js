/*

    This script is for the backToTopBtn

*/

b2Top();
function b2Top() {
  const backToTopBtn = document.getElementById("b2Top");

  determineB2Top();
  function determineB2Top() {
    if (window.scrollY < 400) {
      backToTopBtn.disabled = true;
      backToTopBtn.style.opacity = "0.5";
      backToTopBtn.style.bottom = "-100px";
    } else if (window.scrollY > 400) {
      backToTopBtn.style.bottom = "10px";
      setTimeout(() => {
        backToTopBtn.disabled = false;
        backToTopBtn.style.opacity = "1";
      }, 200);
    }
  }

  window.addEventListener("scroll", determineB2Top);
  backToTopBtn.addEventListener("click", () => {
    window.scrollTo(0, 0);
  });
}
