/*

    This script is for the aboutSkills

*/

var skillsI;
const allSkills = document.querySelectorAll(".inner-bar");
const allInnerBarPercs = document.querySelectorAll(".inner-bar-perc");
const allSkillHints = document.querySelectorAll(".skill-bar-hint");

hideSkills();
function hideSkills() {
  const skills = document.getElementsByClassName("inner-bar");
  const percs = document.getElementsByClassName("inner-bar-perc");
  const hints = document.getElementsByClassName("skill-bar-hint");

  for (skillsI = 0; skillsI < skills.length; skillsI++) {
    skills[skillsI].style.width = "0";
  }
  for (skillsI = 0; skillsI < percs.length; skillsI++) {
    percs[skillsI].classList.toggle("deactive");
  }
  for (skillsI = 0; skillsI < hints.length; skillsI++) {
    hints[skillsI].classList.toggle("deactive");
  }
}

const skillsMain = document.getElementById("skillsMain");
const passedDiv = document.getElementById("aboutBackground");
const skillsBox = document.getElementById("skillsBox");

var skillsPassed;

// function checkSkillsScrolled(state) {
//   skillsPassed = state;

//   if (window.scrollY > passedDiv.offsetTop + passedDiv.offsetHeight) {
//     skillsPassed = true;
//     return skillsPassed;
//   }
// }

skillsMain.classList.toggle("deactive");

window.addEventListener("scroll", () => {
  if (window.scrollY > passedDiv.offsetTop + passedDiv.offsetHeight) {
    skillsPassed = true;
    displaySkillsMain();
  }
});

function displaySkillsMain() {
  if ((skillsPassed = true)) {
    skillsMain.classList.remove("deactive");
    displaySkills();
  }
}

function displaySkills() {
  setTimeout(() => {
    allSkills[0].style.width = "100%";
    setTimeout(() => {
      allInnerBarPercs[0].classList.remove("deactive");
    }, 100);
  }, 300);
  setTimeout(() => {
    allSkills[1].style.width = "100%";
    setTimeout(() => {
      allInnerBarPercs[1].classList.remove("deactive");
    }, 100);
  }, 450);
  setTimeout(() => {
    allSkills[2].style.width = "100%";
    setTimeout(() => {
      allInnerBarPercs[2].classList.remove("deactive");
    }, 100);
  }, 600);
  setTimeout(() => {
    allSkills[3].style.width = "100%";
    setTimeout(() => {
      allInnerBarPercs[3].classList.remove("deactive");
    }, 100);
  }, 750);
  setTimeout(() => {
    allSkills[4].style.width = "100%";
    setTimeout(() => {
      allInnerBarPercs[4].classList.remove("deactive");
    }, 100);
  }, 900);
}

function displaySkillHint(skill, hint) {
  allSkills[skill].addEventListener("mouseenter", () => {
    allSkillHints[hint].classList.remove("deactive");
  });
  allSkills[skill].addEventListener("mouseleave", () => {
    allSkillHints[hint].classList.toggle("deactive");
  });
}

displaySkillHint(0, 0);
displaySkillHint(1, 1);
displaySkillHint(2, 2);
displaySkillHint(3, 3);
displaySkillHint(4, 4);
