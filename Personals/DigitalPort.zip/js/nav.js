/*

    This script is for the nav

*/

const navToggler = document.getElementById("navToggler");
const navTogglerI = document.querySelector("#navToggler i");
const navCloser = document.getElementById("navCloser");
const navLinks = document.getElementById("navLinks");
const navLinksCnt = document.getElementById("navLinksCnt");

navLinks.classList.toggle("deactive");
navLinksCnt.classList.toggle("deactive");

function lockNavToggler(spin, opac, able) {
  navTogglerI.style.transform = `rotate(${spin}deg)`;
  navToggler.style.opacity = opac;
  navToggler.disabled = able;
}

function openNav() {
  document.body.style.overflowY = "hidden";
  document.getElementById("mainBodyInner").style.filter = "brightness(55%)";

  navLinks.classList.remove("deactive");

  setTimeout(() => {
    navLinksCnt.classList.remove("deactive");
    navCloser.disabled = false;
  }, 600);
}

function closeNav() {
  navCloser.disabled = true;
  navLinksCnt.classList.toggle("deactive");

  setTimeout(() => {
    navLinks.classList.toggle("deactive");
  }, 600);

  setTimeout(() => {
    lockNavToggler(0, "1", false);
    document.getElementById("mainBodyInner").style.filter = "brightness(100%)";
    document.body.style.overflowY = "auto";
  }, 1000);
}

navToggler.addEventListener("click", () => {
  lockNavToggler(90, ".4", true);
  openNav();
});
navCloser.addEventListener("click", () => {
  closeNav();
});
