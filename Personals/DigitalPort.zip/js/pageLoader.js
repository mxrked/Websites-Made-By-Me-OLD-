/*

    This script is for the pageLoader

    PAIRS with indexTopFadeIns.js

*/

var pageLoaderState;

function determinePageLoaderState(state) {
  pageLoaderState = state;

  checkPageLoader();
}

function checkPageLoader() {
  if (pageLoaderState === "true") {
    closePageLoader();
    console.log("Page Loader has finished... now loading page content");
  } else if (pageLoaderState === "false") {
    document.body.style.overflowY = "hidden";
    pageLoader.style.height = "100%";
  }
}

const pageLoader = document.getElementById("pageLoader");
const pageLoaderCnt = document.getElementById("pageLoaderCnt");
function closePageLoader() {
  pageLoaderCnt.classList.toggle("deactive");

  setTimeout(() => {
    pageLoader.style.height = "0";
  }, 1000);

  if ((pageLoader.style.height = "0")) {
    setTimeout(() => {
      document.body.style.overflowY = "auto";
    }, 500);
  }
}
window.addEventListener("beforeunload", () => {
  determinePageLoaderState(false);
});
window.addEventListener("load", () => {
  document.getElementById("mainBodyInner").style.opacity = "0.5";
  setTimeout(() => {
    document.getElementById("mainBodyInner").style.opacity = "1";
  }, 1000);
  determinePageLoaderState("true");
});
