/*

    This script is for the pageLoader

*/

var pageLoaded = false;
const pL = document.getElementById("pageLoader");

function loadPageLoader() {
  const pLCnt = document.querySelector(".page-loader-cnt");

  setTimeout(() => {
    pLCnt.classList.toggle("deactive");
  }, 200);
  setTimeout(() => {
    pL.style.maxHeight = "0";
  }, 800);
  setTimeout(() => {
    pL.classList.toggle("deactive");
  }, 1100);
}

window.addEventListener("load", () => {
  loadPageLoader();
  pageLoaded = true;
  setTimeout(() => {
    loadPageContent();
  }, 2500);
});

const actualPageContent = document.getElementById("actualPageCnt");
actualPageContent.classList.toggle("deactive");

function loadPageContent() {
  if (pageLoaded == true && pL.style.height == 0) {
    actualPageContent.classList.remove("deactive");
    triggerTopContent(); // this will trigger the top content after the users page has loaded (checks conditions)
  }
}
