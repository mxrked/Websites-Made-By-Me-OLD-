/*

    This script goes along with the TypewriterJS 

*/

const typeWriterApp = document.getElementById("topSectTW");

const typeWriter = new Typewriter(typeWriterApp, {
  loop: true,
});

typeWriter
  .typeString("Web Developer.")
  .pauseFor(2500)
  .deleteAll()
  .typeString("Web Designer.")
  .pauseFor(2500)
  .deleteAll()
  .typeString("Coder.")
  .pauseFor(2500)
  .deleteAll()
  .typeString("Programmer.")
  .pauseFor(2500)
  .start();
