/*

    This script is for the index page projects section

*/

//! ======= WEBSITES ======= //
const WEBSITES_SLIDER = document.getElementById("websiteSlider");
const WEBSITES_OVERLAY = document.getElementById("websiteOverlay");
const WEBSITES_OVERLAY_CLOSER = document.getElementById("websiteOverlayCloser");

// Hiding website snippet overlay contents
hideWebsiteOverlayContent();
function hideWebsiteOverlayContent() {
  document.querySelector(".website-overlay-cnt").classList.toggle("deactive");
  WEBSITES_OVERLAY_CLOSER.classList.toggle("deactive");
}

// Website Events
//* Slider
WEBSITES_SLIDER.addEventListener("click", () => {
  WEBSITES_SLIDER.classList.toggle("deactive");

  WEBSITES_OVERLAY.style.maxHeight = "100%";

  setTimeout(() => {
    document.querySelector(".website-overlay-cnt").classList.remove("deactive");
    WEBSITES_OVERLAY_CLOSER.classList.remove("deactive");
  }, 900);
});
//* Closer
WEBSITES_OVERLAY_CLOSER.addEventListener("click", () => {
  hideWebsiteOverlayContent();

  WEBSITES_OVERLAY.style.maxHeight = "0";

  setTimeout(() => {
    WEBSITES_SLIDER.classList.remove("deactive");
  }, 900);
});

//! ======= SNIPPETS ======= //
const SNIPPETS_SLIDER = document.getElementById("snippetSlider");
const SNIPPETS_OVERLAY = document.getElementById("snippetOverlay");
const SNIPPETS_OVERLAY_CLOSER = document.getElementById("snippetOverlayCloser");

// Hiding snippet slider overlay contents
hideSnippetOverlayContent();
function hideSnippetOverlayContent() {
  document.querySelector(".snippet-overlay-cnt").classList.toggle("deactive");
  SNIPPETS_OVERLAY_CLOSER.classList.toggle("deactive");
}

// Snippet Events
//* Slider
SNIPPETS_SLIDER.addEventListener("click", () => {
  SNIPPETS_SLIDER.classList.toggle("deactive");

  SNIPPETS_OVERLAY.style.maxHeight = "100%";

  setTimeout(() => {
    document.querySelector(".snippet-overlay-cnt").classList.remove("deactive");
    SNIPPETS_OVERLAY_CLOSER.classList.remove("deactive");
  }, 900);
});
//* Closer
SNIPPETS_OVERLAY_CLOSER.addEventListener("click", () => {
  hideSnippetOverlayContent();

  SNIPPETS_OVERLAY.style.maxHeight = "0";

  setTimeout(() => {
    SNIPPETS_SLIDER.classList.remove("deactive");
  }, 900);
});
