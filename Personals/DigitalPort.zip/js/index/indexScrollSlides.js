/*

    This script is used to slide in content based on scrolling

*/

//
//
//

// Hide all of the indexSlideIns by default
hideIndexSlides();
function hideIndexSlides() {
  const INDEX_ABOUT_L_SLIDE = document.getElementById("indexAboutSideCntL");
  const INDEX_ABOUT_L_SIDE_BOXES_SLIDE = document.getElementById(
    "indexAboutSideBoxes"
  );
  const INDEX_ABOUT_IMG = document.getElementById("indexAboutImg");

  INDEX_ABOUT_L_SLIDE.style.marginLeft = "-400%";
  INDEX_ABOUT_L_SIDE_BOXES_SLIDE.style.marginLeft = "-400%";
  INDEX_ABOUT_IMG.style.marginRight = "-400%";
}

//
//
//

// This will trigger the
function triggerScrollSlideIns() {
  const SCROLL_INDEX_HERO_CNT = document.getElementById("indexHeroCnt");
  const SCROLL_INDEX_ABOUT = document.getElementById("indexAbout");
  const SCROLL_INDEX_ABOUT_L = document.getElementById("indexAboutSideCntL");
  const SCROLL_INDEX_ABOUT_L_BOXES = document.getElementById(
    "indexAboutSideBoxes"
  );
  const SCROLL_INDEX_ABOUT_IMG = document.getElementById("indexAboutImg");

  // Scrolling past Index Hero...slides in indexAbout
  if (
    window.scrollY >
    SCROLL_INDEX_HERO_CNT.offsetTop + SCROLL_INDEX_HERO_CNT.offsetHeight
  ) {
    SCROLL_INDEX_ABOUT_L.style.marginLeft = "0";
    SCROLL_INDEX_ABOUT_L_BOXES.style.marginLeft = "0";
    SCROLL_INDEX_ABOUT_IMG.style.marginRight = "0";
  }
}

//
//
//

window.addEventListener("scroll", triggerScrollSlideIns);
