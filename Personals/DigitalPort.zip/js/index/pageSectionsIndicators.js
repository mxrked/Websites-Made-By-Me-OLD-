/*

    This script will be used to indicate what section of the page the user is on.

*/

const topSection = document.getElementById("topSect");
const topIndicate = document.querySelector("#topIndicator");

const aboutSection = document.getElementById("aboutSect");
const aboutIndicate = document.querySelector("#aboutIndicator");

const workSection = document.getElementById("workSect");
const workIndicate = document.querySelector("#workIndicator");

const skillsSection = document.getElementById("skillsSect");
const skillsIndicate = document.querySelector("#skillsIndicator");

const contactSection = document.getElementById("contactSect");
const contactIndicate = document.querySelector("#contactIndicator");

function scrollToSect(indicator, sect) {
  indicator.addEventListener("click", () => {
    sect.scrollIntoView();
    indicator.style.opacity = "0.3";

    setTimeout(() => {
      indicator.style.opacity = "1";
    }, 500);
  });
}

scrollToSect(topIndicate, topSection);
scrollToSect(aboutIndicate, aboutSection);
scrollToSect(workIndicate, workSection);
scrollToSect(skillsIndicate, skillsSection);
scrollToSect(contactIndicate, contactSection);
