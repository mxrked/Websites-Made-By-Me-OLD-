/*

    This script will be used to indicate what section of the page the user is on.

*/
const allSectIndicateAs = document.querySelectorAll(".sect-indicator");

const topSection = document.getElementById("topSect");
const topIndicate = document.querySelector("#topIndicator");

const aboutSection = document.getElementById("aboutSect");
const aboutIndicate = document.querySelector("#aboutIndicator");

const workSection = document.getElementById("workSect");
const workIndicate = document.querySelector("#workIndicator");

function scrollToSect(indicator, sect) {
  indicator.addEventListener("click", () => {
    sect.scrollIntoView();
  });
}

scrollToSect(topIndicate, topSection);
scrollToSect(aboutIndicate, aboutSection);
scrollToSect(workIndicate, workSection);
