/*

    This script is for the indexHero text

*/

indexHeroTextInit();
function indexHeroTextInit() {
  const indexHeroTextItems = document.querySelectorAll(".index-hero-text-item");
  var indexHeroTextI;

  // Hides all indexHeroText items
  hideIndexHeroTextItems();
  function hideIndexHeroTextItems() {
    for (
      indexHeroTextI = 0;
      indexHeroTextI < indexHeroTextItems.length;
      indexHeroTextI++
    ) {
      indexHeroTextItems[indexHeroTextI].style.marginLeft = "-500%";
    }
  }

  // Animate the indexHeroText items
  function animateIndexHeroTextItems() {
    // Add custom transitions to indexHeroText items
    for (
      indexHeroTextI = 0;
      indexHeroTextI < indexHeroTextItems.length;
      indexHeroTextI++
    ) {
      indexHeroTextItems[indexHeroTextI].style.transition = "2s ease-in-out";
    }

    setTimeout(() => {
      indexHeroTextItems[0].style.marginLeft = "0"; // indexHeroText h3
    }, 40);
    setTimeout(() => {
      indexHeroTextItems[1].style.marginLeft = "0"; // indexHeroText div
    }, 70);
  }

  // Triggers the indexHeroTextItems after the page loads
  window.addEventListener("load", () => {
    animateIndexHeroTextItems();
  });
}
