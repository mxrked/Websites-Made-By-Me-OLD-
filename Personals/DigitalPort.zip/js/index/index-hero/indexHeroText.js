/*

    This script is for the indexHero text

*/

indexHeroTextInit();
function indexHeroTextInit() {
  const indexHeroTextItems = document.querySelectorAll(".index-hero-text-item");
  const indexHeroBouncingDots = document.getElementById("indexHeroDots");
  var indexHeroTextI;

  // Hides all indexHeroText items
  hideIndexHeroTextItems();
  function hideIndexHeroTextItems() {
    for (
      indexHeroTextI = 0;
      indexHeroTextI < indexHeroTextItems.length;
      indexHeroTextI++
    ) {
      indexHeroTextItems[indexHeroTextI].style.marginLeft = "-300%";
    }
  } //* Leaving hideIndexHeroTextItems()

  //
  //
  //

  // Animate the indexHeroText items
  function animateIndexHeroTextItems() {
    // Add custom transitions to indexHeroText items
    for (
      indexHeroTextI = 0;
      indexHeroTextI < indexHeroTextItems.length;
      indexHeroTextI++
    ) {
      indexHeroTextItems[indexHeroTextI].style.transition = "2s ease-in-out";
    }

    setTimeout(() => {
      indexHeroBouncingDots.classList.toggle("deactive");
    }, 1125);

    setTimeout(() => {
      indexHeroTextItems[0].style.marginLeft = "0"; // indexHeroText h3
    }, 10);
    setTimeout(() => {
      indexHeroTextItems[1].style.marginLeft = "0"; // indexHeroText div
    }, 50);
  } //* Leaving animateIndexHeroTextItems()

  // Triggers the indexHeroTextItems after the page loads
  window.addEventListener("load", () => {
    animateIndexHeroTextItems();
  });
} //* Leaving indexHeroTextInit()
