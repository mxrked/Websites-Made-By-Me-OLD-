/*

    This script is for the indexHero

*/

mainIndexHeroInit();
function mainIndexHeroInit() {
  const darkGreyOverlay = document.getElementById("darkGreyOL");
  const toggleTransparent = document.getElementById("toggleTransparency");
  const removeTransparent = document.getElementById("removeTransparency");

  function removeTransparency() {
    toggleTransparent.style.display = "none";
    removeTransparent.style.display = "block";
    darkGreyOverlay.style.opacity = "1";

    // Adds appearance of indexHeroLink
    document.getElementById("indexHeroLink").style.width = "100%";
    document.getElementById("indexHeroLink").style.padding = "10px";
    document.getElementById("indexHeroLink").style.border = "2px solid white";

    setTimeout(() => {
      toggleTransparent.style.left = "0px";
    }, 500);
  }

  function toggleTransparency() {
    toggleTransparent.style.display = "block";
    removeTransparent.style.display = "none";
    darkGreyOverlay.style.opacity = "0.7";

    // Removes appearance of indexHeroLink
    document.getElementById("indexHeroLink").style.width = "0px";
    document.getElementById("indexHeroLink").style.padding = "0px";
    document.getElementById("indexHeroLink").style.border = "none";

    setTimeout(() => {
      toggleTransparent.style.left = "-220px";
    }, 500);
  }

  toggleTransparent.addEventListener("click", removeTransparency);
  removeTransparent.addEventListener("click", toggleTransparency);
}
