/*

    This script is for the indexHero

*/

// This will be called after the pageLoader fades
function mainIndexHeroInit() {
  const darkGreyOverlay = document.getElementById("darkGreyOL");
  const toggleTransparent = document.getElementById("toggleTransparency");
  const removeTransparent = document.getElementById("removeTransparency");
  const indexHeroBtns = document.getElementById("indexHeroBtns");

  function removeTransparency() {
    toggleTransparent.style.display = "none";
    removeTransparent.style.display = "block";
    darkGreyOverlay.style.opacity = "1";

    // Adds appearance of indexHeroLink
    document.getElementById("indexHeroLink").style.width = "100%";
    document.getElementById("indexHeroLink").style.padding = "10px";
    document.getElementById("indexHeroLink").style.border = "2px solid white";

    indexHeroBtns.style.right = "0px";
  } //* Leaving removeTransparency()

  //
  //
  //

  function toggleTransparency() {
    toggleTransparent.style.display = "block";
    removeTransparent.style.display = "none";
    darkGreyOverlay.style.opacity = "0.7";

    // Removes appearance of indexHeroLink
    document.getElementById("indexHeroLink").style.width = "0px";
    document.getElementById("indexHeroLink").style.padding = "0px";
    document.getElementById("indexHeroLink").style.border = "none";

    setTimeout(() => {
      indexHeroBtns.style.right = "220px";
    }, 200);
  } //* Leaving toggleTransparency()

  toggleTransparent.addEventListener("click", removeTransparency);
  removeTransparent.addEventListener("click", toggleTransparency);
} //* Leaving mainIndexHeroInit()
