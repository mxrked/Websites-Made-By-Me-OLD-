/*

    This will make fade ins for the indexTop text

    PAIRS with pageLoader.js

*/

var indexTopI;
const allIndexTopText = document.getElementsByClassName("index-top-item");
const allIndexTopItems = document.querySelectorAll(".index-top-item");

hideIndexTopCnt();
function hideIndexTopCnt() {
  for (indexTopI = 0; indexTopI < allIndexTopText.length; indexTopI++) {
    allIndexTopText[indexTopI].style.opacity = 0;
  }
}

indexTopCntFadeIns();
function indexTopCntFadeIns() {
  if ((pageLoader.style.height = "0")) {
    setTimeout(() => {
      allIndexTopItems[0].style.opacity = 0.4;
    }, 1300);
    setTimeout(() => {
      allIndexTopItems[0].style.top = "-50px";
    }, 1400);

    setTimeout(() => {
      allIndexTopItems[1].style.opacity = 1;
    }, 1500);
    setTimeout(() => {
      allIndexTopItems[1].style.left = "0px";
    }, 1600);

    setTimeout(() => {
      allIndexTopItems[2].style.opacity = 1;
    }, 1700);
    setTimeout(() => {
      allIndexTopItems[2].style.bottom = "0px";
    }, 1800);
  }
}
