/*

    This script is for the work sect

*/

const allWorkItems = document.querySelectorAll(".work-item");
const allWorkItems_Classes = document.getElementsByClassName("work-item");

var workI;

//
//
//

//* Main Functions

function hideAllWorkItems() {
  for (workI = 0; workI < allWorkItems_Classes.length; workI++) {
    allWorkItems_Classes[workI].style.display = "none";
  }
}

function resetWorkBtns() {
  const workBtns = document.getElementsByClassName("work-btn");
  for (workI = 0; workI < workBtns.length; workI++) {
    workBtns[workI].classList.remove("active");
    workBtns[workI].disabled = false;
  }
}

function showAllWorkItems() {
  document.getElementById("allBtn").classList.toggle("active");
  document.getElementById("allBtn").disabled = true;
  for (workI = 0; workI < allWorkItems_Classes.length; workI++) {
    allWorkItems_Classes[workI].style.display = "grid";
  }
}

//
//
//

//* Work Type Functions

const allWebsites = document.querySelectorAll(".website-item");
const allWebsites_Classes = document.getElementsByClassName("website-item");
function showAllWebsiteItems() {
  document.getElementById("websitesBtn").classList.toggle("active");
  document.getElementById("websitesBtn").disabled = true;
  for (workI = 0; workI < allWebsites_Classes.length; workI++) {
    allWebsites_Classes[workI].style.display = "grid";
  }
}

const allSnippets = document.querySelectorAll(".snippet-item");
const allSnippets_Classes = document.getElementsByClassName("snippet-item");
function showAllSnippetItems() {
  document.getElementById("snippetsBtn").classList.toggle("active");
  document.getElementById("snippetsBtn").disabled = true;
  for (workI = 0; workI < allSnippets_Classes.length; workI++) {
    allSnippets_Classes[workI].style.display = "grid";
  }
}

//
//
//

//* Event Listeners

const forEachWorkBtn = document.querySelectorAll(".work-btn");
forEachWorkBtn.forEach((btn) => {
  btn.addEventListener("click", hideAllWorkItems);
});
forEachWorkBtn.forEach((btn) => {
  // Hover
  btn.addEventListener("mouseenter", () => {
    btn.classList.toggle("active");
  });
});
forEachWorkBtn.forEach((btn) => {
  // Unhover
  btn.addEventListener("mouseleave", () => {
    btn.classList.remove("active");
  });
});

document.getElementById("allBtn").classList.toggle("active");
document.getElementById("allBtn").disabled = true;
document.getElementById("allBtn").addEventListener("click", () => {
  resetWorkBtns();
  setTimeout(() => {
    showAllWorkItems();
  }, 100);
});

document.getElementById("websitesBtn").addEventListener("click", () => {
  resetWorkBtns();
  setTimeout(() => {
    showAllWebsiteItems();
  }, 100);
});

document.getElementById("snippetsBtn").addEventListener("click", () => {
  resetWorkBtns();
  setTimeout(() => {
    showAllSnippetItems();
  }, 100);
});
