/*

    This script is for the skill bars 

*/

const allSkillBarSpans = document.querySelectorAll(".skill-bar span");
const allSkillBarSpans_Classes =
  document.getElementsByClassName("skill-bar-span");
const allSkillBarSpansP = document.querySelectorAll(".skill-bar span p");
const allSkillBarSpansP_Classes =
  document.getElementsByClassName("skill-bar-span-p");
const allSkillInfos = document.querySelectorAll(".skill-info");
const allSkillInfos_Classes = document.getElementsByClassName("skill-info");
var skillI;

hideSkillBarSpans();
function hideSkillBarSpans() {
  for (skillI = 0; skillI < allSkillBarSpans_Classes.length; skillI++) {
    allSkillBarSpans_Classes[skillI].classList.toggle("hide");
  }
  for (skillI = 0; skillI < allSkillBarSpansP_Classes.length; skillI++) {
    allSkillBarSpansP_Classes[skillI].classList.toggle("deactive");
  }
}

hideSkillInfos();
function hideSkillInfos() {
  for (skillI = 0; skillI < allSkillInfos_Classes.length; skillI++) {
    allSkillInfos_Classes[skillI].classList.toggle("deactive");
  }
}

function triggerSkillBarSpans() {
  const skillsTrigger = document.getElementById("skillsTriggerer");

  if (window.scrollY > skillsTrigger.offsetTop + skillsTrigger.offsetHeight) {
    animateSkillBarSpans();
  }
}

function animateSkillBarSpans() {
  // HTML5
  setTimeout(() => {
    allSkillBarSpans[0].classList.remove("hide");
  }, 500);
  setTimeout(() => {
    allSkillBarSpansP[0].classList.remove("deactive");
  }, 600);

  // CSS3
  setTimeout(() => {
    allSkillBarSpans[1].classList.remove("hide");
  }, 600);
  setTimeout(() => {
    allSkillBarSpansP[1].classList.remove("deactive");
  }, 700);

  // JavaScript
  setTimeout(() => {
    allSkillBarSpans[2].classList.remove("hide");
  }, 700);
  setTimeout(() => {
    allSkillBarSpansP[2].classList.remove("deactive");
  }, 800);

  // SaSS
  setTimeout(() => {
    allSkillBarSpans[3].classList.remove("hide");
  }, 800);
  setTimeout(() => {
    allSkillBarSpansP[3].classList.remove("deactive");
  }, 900);

  // BootStrap
  setTimeout(() => {
    allSkillBarSpans[4].classList.remove("hide");
  }, 900);
  setTimeout(() => {
    allSkillBarSpansP[4].classList.remove("deactive");
  }, 1000);
}

function triggerSkillInfo(hover, info) {
  hover.addEventListener("mouseenter", () => {
    info.classList.remove("deactive");
  });
  hover.addEventListener("mouseleave", () => {
    info.classList.toggle("deactive");
  });
}

window.addEventListener("scroll", triggerSkillBarSpans);
triggerSkillInfo(allSkillBarSpans[0], allSkillInfos[0]);
triggerSkillInfo(allSkillBarSpans[1], allSkillInfos[1]);
triggerSkillInfo(allSkillBarSpans[2], allSkillInfos[2]);
triggerSkillInfo(allSkillBarSpans[3], allSkillInfos[3]);
triggerSkillInfo(allSkillBarSpans[4], allSkillInfos[4]);
