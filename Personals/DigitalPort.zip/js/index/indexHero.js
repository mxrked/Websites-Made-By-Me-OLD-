/*

    This script is for toggling the overlay for the indexHero

*/

const INDEX_HERO = document.getElementById("indexHero");
const DARKEN_LAYER = document.getElementById("darkenLayer");
const INDEX_HERO_GREY_OVERLAY = document.getElementById("indexHeroGreyOL");
const INDEX_HERO_OVERLAY_TOGGLER = document.getElementById("applyOverlay");
const INDEX_HERO_OVERLAY_DISABLER = document.getElementById("removeOverlay");
const INDEX_HERO_CNT_ITEMS_QUERY = document.querySelectorAll(
  ".index-hero-cnt-item"
);
const INDEX_HERO_BTNS = document.getElementById("indexHeroBtns");
var overlayTrigger;

//
//
//

// This will trigger after the pageLoader has finished loading the page
function triggerIndexHeroFadeIns() {
  const INDEX_HERO_CTN_ITEMS = document.getElementsByClassName(
    "index-hero-cnt-item"
  );
  var indexHeroI;

  // Hides the indexHeroCnt classes
  hideIndexHeroCntItems();
  function hideIndexHeroCntItems() {
    for (
      indexHeroI = 0;
      indexHeroI < INDEX_HERO_CTN_ITEMS.length;
      indexHeroI++
    ) {
      INDEX_HERO_CTN_ITEMS[indexHeroI].classList.toggle("deactive");
    }
    INDEX_HERO_BTNS.classList.toggle("deactive");
  }

  // This will allow once the pageLoader loads the page, text from the indexHero will slide in

  applyIndexHeroCntSlides();

  function applyIndexHeroCntSlides() {
    INDEX_HERO_CNT_ITEMS_QUERY[0].style.marginLeft = "-50px";
    INDEX_HERO_CNT_ITEMS_QUERY[1].style.marginLeft = "-50px";
    INDEX_HERO_BTNS.style.marginLeft = "-50px";

    setTimeout(() => {
      INDEX_HERO_CNT_ITEMS_QUERY[0].classList.remove("deactive");
      INDEX_HERO_CNT_ITEMS_QUERY[0].style.marginLeft = "0";
    }, 1200);
    setTimeout(() => {
      INDEX_HERO_CNT_ITEMS_QUERY[1].classList.remove("deactive");
      INDEX_HERO_CNT_ITEMS_QUERY[1].style.marginLeft = "0";
    }, 1500);
    setTimeout(() => {
      INDEX_HERO_BTNS.classList.remove("deactive");
      INDEX_HERO_BTNS.style.marginLeft = "0";
    }, 1800);
  }
}

// Setting defaults
DARKEN_LAYER.style.opacity = 1;
INDEX_HERO_GREY_OVERLAY.style.opacity = 0;
INDEX_HERO_OVERLAY_DISABLER.style.display = "none";

// This will determine what happens when user clicks overlay toggler or disabler
function determineOverlay() {
  switch (overlayTrigger) {
    // Toggler clicked
    case 1:
      DARKEN_LAYER.style.opacity = 0;
      INDEX_HERO_OVERLAY_TOGGLER.style.display = "none";
      INDEX_HERO_OVERLAY_DISABLER.style.display = "block";
      INDEX_HERO_GREY_OVERLAY.style.opacity = 1;

      INDEX_HERO_CNT_ITEMS_QUERY[0].style.textShadow = "none";
      INDEX_HERO_CNT_ITEMS_QUERY[1].style.textShadow = "none";

      break;

    // Disabler clicked
    case 0:
      DARKEN_LAYER.style.opacity = 1;
      INDEX_HERO_OVERLAY_TOGGLER.style.display = "block";
      INDEX_HERO_OVERLAY_DISABLER.style.display = "none";
      INDEX_HERO_GREY_OVERLAY.style.opacity = 0;

      INDEX_HERO_CNT_ITEMS_QUERY[0].style.textShadow =
        "0 0 37px rgba(0, 0, 0, 0.411)";
      INDEX_HERO_CNT_ITEMS_QUERY[1].style.textShadow =
        "0 0 37px rgba(0, 0, 0, 0.411)";

      break;
  }
}

//
//
//

// Events
INDEX_HERO_OVERLAY_TOGGLER.addEventListener("click", () => {
  overlayTrigger = 1;
  determineOverlay();
});

INDEX_HERO_OVERLAY_DISABLER.addEventListener("click", () => {
  overlayTrigger = 0;
  determineOverlay();
});

INDEX_HERO.addEventListener("mouseenter", () => {
  INDEX_HERO_CNT_ITEMS_QUERY[0].style.transform = "skew(-10deg)";
  INDEX_HERO_CNT_ITEMS_QUERY[1].style.transform = "skew(-10deg)";
});

INDEX_HERO.addEventListener("mouseleave", () => {
  INDEX_HERO_CNT_ITEMS_QUERY[0].style.transform = "skew(0deg)";
  INDEX_HERO_CNT_ITEMS_QUERY[1].style.transform = "skew(0deg)";
});
