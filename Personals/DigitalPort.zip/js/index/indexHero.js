/*

    This script is for the index hero dots

*/

const indexHeroDot1 = document.getElementById("indexHeroDot1");
const indexHeroDot2 = document.getElementById("indexHeroDot2");
const indexHeroDot3 = document.getElementById("indexHeroDot3");

const allIndexHeroDotPs = document.querySelectorAll(".index-hero-dot-p");
const indexHeroDotP1 = document.getElementById("indexHeroDotP1");
const indexHeroDotP2 = document.getElementById("indexHeroDotP2");
const indexHeroDotP3 = document.getElementById("indexHeroDotP3");

indexHeroDot1.addEventListener("mouseenter", () => {
  indexHeroDotP1.style.height = "120px";
});

indexHeroDot1.addEventListener("mouseleave", indexHeroDotLeave);

indexHeroDot2.addEventListener("mouseenter", () => {
  indexHeroDotP2.style.height = "100px";
});

indexHeroDot2.addEventListener("mouseleave", indexHeroDotLeave);

indexHeroDot3.addEventListener("mouseenter", () => {
  indexHeroDotP3.style.height = "50px";
});

indexHeroDot3.addEventListener("mouseleave", indexHeroDotLeave);

function indexHeroDotLeave() {
  allIndexHeroDotPs.forEach((p) => {
    p.style.height = "0";
  });
}
