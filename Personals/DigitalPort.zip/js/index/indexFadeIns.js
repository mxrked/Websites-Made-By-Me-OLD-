/*

    This script is for the index page fade ins

*/

// Hiding in index page contents
const allIndexItems = document.getElementsByClassName("index-page-item");
var indexPageI;

hideIndexPageItems();
function hideIndexPageItems() {
  for (indexPageI = 0; indexPageI < allIndexItems.length; indexPageI++) {
    allIndexItems[indexPageI].classList.toggle("deactive");
  }
}

// Index Hero Fade Ins
const indexHero = document.getElementById("indexHero");
const indexHeroCnt = document.getElementById("indexHeroCnt");

indexHeroCnt.style.left = "-50px";

function showIndexHeroItems() {
  setTimeout(() => {
    indexHero.classList.remove("deactive");
  }, 500);

  setTimeout(() => {
    indexHeroCnt.classList.remove("deactive");
  }, 1500);

  setTimeout(() => {
    indexHeroCnt.style.left = "0";
  }, 1700);
}

window.addEventListener("load", () => {
  setTimeout(() => {
    showIndexHeroItems();
  }, 500);
});
