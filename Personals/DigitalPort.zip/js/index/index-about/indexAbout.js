/*

    This script is for the indexAbout sect

*/

mainIndexAboutInit();
function mainIndexAboutInit() {
  const indexAboutItems = document.querySelectorAll(".index-about-item");
  var indexAboutI;

  hideIndexAboutItems();
  function hideIndexAboutItems() {
    for (indexAboutI = 0; indexAboutI < indexAboutItems.length; indexAboutI++) {
      indexAboutItems[indexAboutI].classList.toggle("deactive");
      indexAboutItems[indexAboutI].style.left = "-60px";
    }
  } //* Leaving hideIndexAboutItems()

  //
  //
  //

  function checkIndexAboutScroll(indexHeroCnt) {
    indexHeroCnt = document.getElementById("indexHeroCnt");

    if (window.scrollY > indexHeroCnt.offsetTop + indexHeroCnt.offsetHeight) {
      indexAboutItems[0].classList.remove("deactive");
      indexAboutItems[0].style.left = 0;
    }
  } //* Leaving checkIndexAboutScroll()

  window.addEventListener("scroll", checkIndexAboutScroll);
} //* Leaving mainIndexAboutInit()
