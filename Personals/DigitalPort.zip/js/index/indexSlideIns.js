/*

    This script is for the index page slide ins

*/

function indexSlideInsInit() {
  const indexIntroVideo = document.getElementById("indexIntroVid");
  const indexIntroTxt = document.getElementById("indexIntroText");

  hideIndexSlideIns();

  function hideIndexSlideIns() {
    // Index Intro
    indexIntroVideo.classList.toggle("hideSlideIns");
    indexIntroTxt.style.display = "none";
    indexIntroTxt.classList.toggle("deactive");
  }

  function toggleIndexSlideIns() {
    // This will make the slide in animations for indexPage be triggered
    indexIntroSIS();
  }

  function indexIntroSIS() {
    indexIntroVideo.classList.remove("hideSlideIns");
    indexIntroVideo.style.maxHeight = "100vh";

    setTimeout(() => {
      indexIntroTxt.style.display = "block";
    }, 1200);

    setTimeout(() => {
      indexIntroTxt.classList.remove("deactive");
    }, 1400);
  }

  setTimeout(() => {
    toggleIndexSlideIns();
  }, 600);
}

window.addEventListener("load", indexSlideInsInit); // Loads the main indexSlideIns function
