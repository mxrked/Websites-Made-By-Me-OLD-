/*

    This script is for the index page jumpers

*/

mainIndexPageJumperInit();
function mainIndexPageJumperInit() {
  const allIndexPageJumpers = document.querySelectorAll(".index-page-jumper");

  allIndexPageJumpers[0].addEventListener("click", () => {
    document.getElementById("indexAbout").scrollIntoView();
  });
}
