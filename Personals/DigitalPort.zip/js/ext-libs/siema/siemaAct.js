/*

    This script will activate the siema sliders

*/
