/*

    This script is for the topContent only!

*/

// this file is used with the pageLoader script to run after page has loaded

document.getElementById("mainBodyInner").style.overflowY = "hidden";
function triggerTopContent() {
  const mainTopCnt = document.getElementById("mainTop");
  mainTopCnt.classList.toggle("deactive");

  setTimeout(() => {
    console.log("Conditions have been met. (| MAIN TOP |)");
    mainTopCnt.classList.remove("deactive");
  }, 340);
}

const mainTopHoverOne = document.getElementById("mainTopHov1");
const mainTopHoverTwo = document.getElementById("mainTopHov2");
const mainTopHoverThree = document.getElementById("mainTopHov3");

mainTopHoverOne.addEventListener("mouseenter", () => {
  document.querySelector("#mainTopHov1 span").style.width = "0%";
});
mainTopHoverTwo.addEventListener("mouseenter", () => {
  document.querySelector("#mainTopHov2 span").style.width = "0%";
});
mainTopHoverThree.addEventListener("mouseenter", () => {
  document.querySelector("#mainTopHov3 span").style.width = "0%";
});

const allMainTopHovMains = document.querySelectorAll(".main-top-hov-main");
const allMainTopHoverSpans_Classes =
  document.getElementsByClassName("main-top-hov-span");

for (mTopi = 0; mTopi < allMainTopHoverSpans_Classes.length; mTopi++) {
  allMainTopHoverSpans_Classes[mTopi].style.pointerEvents = "none";
}

var mTopi;
allMainTopHovMains.forEach((main) => {
  main.addEventListener("mouseleave", () => {
    for (mTopi = 0; mTopi < allMainTopHoverSpans_Classes.length; mTopi++) {
      allMainTopHoverSpans_Classes[mTopi].style.width = "65%";
    }
  });
  main.addEventListener("mouseenter", () => {
    const hoverHintBox = document.getElementById("hoverHintHolder");
    setTimeout(() => {
      hoverHintBox.classList.toggle("deactive");
    }, 550);

    setTimeout(() => {
      hoverHintBox.style.display = "none";
    }, 700);
  });
});

const mainTopImageOne = document.getElementById("mainTopImg1");
const mainTopImageTwo = document.getElementById("mainTopImg2");
const mainTopImageThree = document.getElementById("mainTopImg3");

function hideMainTopImgs() {
  for (
    mTopi = 0;
    mTopi < document.getElementsByClassName("main-top-img").length;
    mTopi++
  ) {
    document.getElementsByClassName("main-top-img")[mTopi].style.opacity = 0;
  }
}

// fixes fade in for background-images
hideMainTopImgs();
setTimeout(() => {
  mainTopImageThree.style.opacity = 1;
}, 450);

mainTopHoverOne.addEventListener("mouseover", () => {
  hideMainTopImgs();
  setTimeout(() => {
    mainTopImageOne.style.opacity = 1;
  }, 100);
});
mainTopHoverTwo.addEventListener("mouseover", () => {
  hideMainTopImgs();
  setTimeout(() => {
    mainTopImageTwo.style.opacity = 1;
  }, 100);
});
mainTopHoverThree.addEventListener("mouseover", () => {
  hideMainTopImgs();
  setTimeout(() => {
    mainTopImageThree.style.opacity = 1;
  }, 100);
});
