<!--

    This will send an email to the me 
    when a user uses the contact form.

 -->


 <?php 

    if(isset($_POST['submit'])) {

        $firstName = $_POST['fName'];
        $lastName = $_POST['lName'];
        $emailAddress = $_POST['eMail'];
        $phoneNumber = $_POST['pNumber'];
        $actualMessage = $_POST['uMsg'];




        $siteMakerName = 'Parker Phelps';
        $siteMakerJob = 'Front End Developer\Designer.';
        $siteMakerPN = '3368313432';



        $to = 'contact@basicallyeasy.com'; // This is the my email
        $subject = 'Contact Form Submission - Digital Portfolio';
        $subject2 = 'Contact Form Submission - Successfully sent!';
        $message = "First Name : ".$firstName."\n"."Last Name : ".$lastName."\n"."Email Address : ".$emailAddress."\n"."Phone Number : ".$phoneNumber."\n"."Users Message : "."\n\n".$actualMessage;
        $message2 = "Your contact form was sent successfully. You will be contacted back shortly!"."\n"."\n".$siteMakerName."\n".$siteMakerJob."\n".$siteMakerPN;
        $headers = "From: ".$emailAddress;
        $headers2 = "From: ".$to;

       

        if (mail($to, $subject, $message, $headers)) {
            header("Location: http://basicallyeasy.com"); // Change maybe when upgrading to HTTPS
        } else {
            echo "Something went wrong!";
        }

        // This will send a email to the user stating that their contact form was sent successfully.
        mail($emailAddress, $subject2, $message2, $headers2);
        
        
    }

?>

