If there is no files under this parent branch,
then this website more than likely uses a Server CDN 

IF U WANT YOU CAN DELETE THIS BRANCH IF U DEEM NECCESARY