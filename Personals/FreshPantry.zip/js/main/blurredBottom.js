/*

    This script is for the blurred bottom

*/

const blurredBottom = document.getElementById("blurredBottom");

determineBlurredBottom();
function determineBlurredBottom() {
  if (
    window.innerHeight + Math.ceil(window.pageYOffset) >=
    document.body.offsetHeight
  ) {
    blurredBottom.style.opacity = 0;
  } else {
    blurredBottom.style.opacity = 0.5;
  }
}

window.addEventListener("scroll", determineBlurredBottom);
