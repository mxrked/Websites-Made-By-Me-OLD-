/*

    This script is for the nav

*/

const openedFilter = document.getElementById("openedFilter");
const navToggler = document.getElementById("mobileNavToggler");
const navCloser = document.getElementById("mobileNavCloser");
const navLinks = document.getElementById("mobileNavLinks");
const navLinksCnt = document.getElementById("mobileNavLinksCnt");

openedFilter.classList.toggle("deactive");
openedFilter.style.display = "none";
navLinksCnt.classList.toggle("deactive");

function openNav() {
  openedFilter.style.display = "block";

  navToggler.classList.toggle("deactive");

  navLinks.style.width = "100%";

  setTimeout(() => {
    navLinksCnt.classList.remove("deactive");
  }, 900);
}

function closeNav() {
  navLinksCnt.classList.toggle("deactive");

  setTimeout(() => {
    navLinks.style.width = "0";
  }, 400);

  setTimeout(() => {
    openedFilter.style.display = "none";
  }, 1300);

  setTimeout(() => {
    navToggler.classList.remove("deactive");
  }, 1400);
}

navToggler.addEventListener("click", () => {
  openNav();
});
navCloser.addEventListener("click", () => {
  closeNav();
});
