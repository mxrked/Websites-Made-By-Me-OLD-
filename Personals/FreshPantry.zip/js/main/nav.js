/*

    This script is for the nav

*/

const navToggler = document.getElementById("navToggle");
const navCloser = document.getElementById("navCloser");
const navLinks = document.getElementById("mobileNavLinks");
const navLinksCnt = document.getElementById("mobileNavLinksCnt");
const darkenOverlay = document.getElementById("darkenOL");
const mobileNavLinksCntItems_Classes = document.getElementsByClassName(
  "mobile-nav-links-cnt-item"
);
const mobileNavLinksCntItems = document.querySelectorAll(
  ".mobile-nav-links-cnt-item"
);

var navI;

hideMobileNavLinksCntItems();
function hideMobileNavLinksCntItems() {
  for (navI = 0; navI < mobileNavLinksCntItems_Classes.length; navI++) {
    mobileNavLinksCntItems_Classes[navI].classList.toggle("deactive");
  }
}

navLinksCnt.style.overflowY = "hidden";
darkenOverlay.classList.toggle("deactive");
darkenOverlay.style.pointerEvents = "none";

function openNav() {
  darkenOverlay.classList.remove("deactive");

  setTimeout(() => {
    navLinksCnt.style.maxWidth = "100%";
  }, 1000);

  setTimeout(() => {
    for (navI = 0; navI < mobileNavLinksCntItems_Classes.length; navI++) {
      mobileNavLinksCntItems_Classes[navI].classList.remove("deactive");
    }
  }, 2500);

  setTimeout(() => {
    navLinksCnt.style.overflowY = "auto";
  }, 2650);

  setTimeout(() => {
    darkenOverlay.style.pointerEvents = "auto";
  }, 2800);
}

function closeNav() {
  hideMobileNavLinksCntItems();
  navLinksCnt.style.overflowY = "hidden";
  navLinksCnt.style.maxWidth = "0";

  closeNavSubSet();

  darkenOverlay.style.pointerEvents = "none";

  setTimeout(() => {
    darkenOverlay.classList.toggle("deactive");
  }, 1000);
}

const navSubToggler = document.getElementById("navSubToggle");
const navSubCloser = document.getElementById("navSubClose");
const navSubSet = document.getElementById("navSubLinks");

function openNavSubSet() {
  navSubToggler.style.display = "none";
  navSubCloser.style.display = "flex";

  navSubSet.style.maxHeight = "100%";
}

function closeNavSubSet() {
  navSubToggler.style.display = "flex";
  navSubCloser.style.display = "none";

  navSubSet.style.maxHeight = "0";
}

navToggler.addEventListener("click", openNav);
navCloser.addEventListener("click", closeNav);
navSubToggler.addEventListener("click", openNavSubSet);
navSubCloser.addEventListener("click", closeNavSubSet);
window.onclick = function (event) {
  if (event.target == darkenOverlay) {
    closeNav();
  }
};
