/*

    This script is for the nav

*/

const respNav = document.getElementById("respNav");
respNav.style.overflowY = "hidden";
respNav.classList.toggle("respNavSlope");

const navToggler = document.getElementById("toggleNav");
const navCloser = document.getElementById("closeNav");
const navContent = document.getElementById("respNavCnt");
navContent.classList.toggle("deactive");

function openNav() {
  document.body.style.overflowY = "hidden";
  document.getElementById("mainBodyInner").style.opacity = ".5";

  respNav.style.maxHeight = "100%";
  setTimeout(() => {
    respNav.classList.remove("respNavSlope");
  }, 100);
  setTimeout(() => {
    respNav.style.overflowY = "auto";
  }, 700);

  setTimeout(() => {
    navContent.classList.remove("deactive");
  }, 1000);
}

function closeNav() {
  respNav.style.overflowY = "hidden";
  navContent.classList.toggle("deactive");

  setTimeout(() => {
    respNav.style.maxHeight = "0";
    respNav.classList.toggle("respNavSlope");
  }, 500);

  setTimeout(() => {
    document.body.style.overflowY = "auto";
    document.getElementById("mainBodyInner").style.opacity = "1";
  }, 1200);
}

navToggler.addEventListener("click", openNav);
navCloser.addEventListener("click", closeNav);
