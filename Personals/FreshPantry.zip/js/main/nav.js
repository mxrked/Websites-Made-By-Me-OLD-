/*

    This script is for the nav

*/

const darkOverlay = document.getElementById("darkenOL");
darkOverlay.classList.toggle("deactive");
darkOverlay.style.display = "none";
darkOverlay.style.pointerEvents = "none";

const navToggler = document.getElementById("navToggler");
const allNavTogglerSpans = document.querySelectorAll("#navToggler span");
const navCloser = document.getElementById("navCloser");
const navLinks = document.getElementById("mobileNavLinks");
const navLinksCnt = document.getElementById("mobileNavLinksCnt");
navLinksCnt.classList.toggle("deactive");

function lockNavTogglerSpans() {
  allNavTogglerSpans[0].style.width = "10px";
  allNavTogglerSpans[2].style.width = "10px";
}

function resetNavTogglerSpans() {
  allNavTogglerSpans[0].style.width = "20px";
  allNavTogglerSpans[2].style.width = "20px";
}

function openNav() {
  lockNavTogglerSpans();
  navToggler.style.opacity = ".5";
  navToggler.disabled = true;

  darkOverlay.style.display = "block";

  setTimeout(() => {
    darkOverlay.classList.remove("deactive");
  }, 150);

  setTimeout(() => {
    navLinks.style.maxWidth = "100%";
  }, 300);

  setTimeout(() => {
    navLinksCnt.classList.remove("deactive");
  }, 600);

  setTimeout(() => {
    darkOverlay.style.pointerEvents = "auto";
  }, 1000);
}

const subToggler = document.getElementById("toggleSub");
const subCloser = document.getElementById("closeSub");
const subLinks = document.getElementById("subLinks");

function openSub() {
  subToggler.style.display = "none";
  subCloser.style.display = "flex";
  subLinks.style.maxHeight = "100%";
}
function closeSub() {
  subToggler.style.display = "flex";
  subCloser.style.display = "none";
  subLinks.style.maxHeight = "0px";
}

function closeNav() {
  closeSub();

  darkOverlay.style.pointerEvents = "none";
  navLinksCnt.classList.toggle("deactive");

  setTimeout(() => {
    navLinks.style.maxWidth = "0";
  }, 220);

  setTimeout(() => {
    darkOverlay.classList.toggle("deactive");
  }, 500);

  setTimeout(() => {
    navToggler.style.opacity = "1";
    navToggler.disabled = false;
    resetNavTogglerSpans();
  }, 850);
}

navToggler.addEventListener("click", openNav);
navToggler.addEventListener("mouseenter", lockNavTogglerSpans);
navToggler.addEventListener("mouseleave", resetNavTogglerSpans);
navCloser.addEventListener("click", closeNav);

subToggler.addEventListener("click", openSub);
subCloser.addEventListener("click", closeSub);

window.onclick = function (dol) {
  if (dol.target == darkOverlay) {
    closeNav();
  }
};
