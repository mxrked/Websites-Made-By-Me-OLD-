/*

    This script is for the shopping cart

*/

//! UNCOMMENT ALL OF THIS TO SHOW A DEMONSTRATION OF FAKE ITEMS

// showing shopping cart when page has loaded

const shoppingCartToggle = document.getElementById("toggleCart");
shoppingCartToggle.style.bottom = "-50px";
function showSCAfterLoad() {
  shoppingCartToggle.style.bottom = "20px";
}

const shoppingCart = document.getElementById("shoppingCartSlide");
const shoppingCartContent = document.querySelector(".shopping-cart-cnt");
shoppingCartContent.classList.toggle("deactive");

function openShoppingCart() {
  document.body.style.overflowY = "hidden";

  shoppingCart.style.overflowY = "auto";
  shoppingCartToggle.disabled = true;
  shoppingCartToggle.style.opacity = ".3";
  shoppingCart.style.maxWidth = "320px";

  setTimeout(() => {
    shoppingCartContent.classList.remove("deactive");
  }, 850);
}

const shoppingCartCloser = document.getElementById("closeCart");
function closeShoppingCart() {
  shoppingCartContent.classList.toggle("deactive");
  shoppingCart.style.overflowY = "hidden";

  setTimeout(() => {
    shoppingCart.style.maxWidth = "0px";
  }, 300);

  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 1000);

  setTimeout(() => {
    shoppingCartToggle.disabled = false;
    shoppingCartToggle.style.opacity = "1";
  }, 1500);
}

shoppingCartToggle.addEventListener("click", () => {
  openShoppingCart();
});
shoppingCartCloser.addEventListener("click", () => {
  closeShoppingCart();
});

// removing the cart items (currently only using fake items for demostration)
const allFakeSCItemsRemovers = document.querySelectorAll(".remove-fake-item");
const allFakeSCItems = document.querySelectorAll(".fake-sc-item");
const allFakeSCItems_Classes = document.getElementsByClassName("fake-sc-item");
var fSCI;

function removeFakeSCItem(btn, item) {
  btn.addEventListener("click", () => {
    item.style.display = "none";
  });
}

// each individual item remover
removeFakeSCItem(allFakeSCItemsRemovers[0], allFakeSCItems[0]);
removeFakeSCItem(allFakeSCItemsRemovers[1], allFakeSCItems[1]);
removeFakeSCItem(allFakeSCItemsRemovers[2], allFakeSCItems[2]);
removeFakeSCItem(allFakeSCItemsRemovers[3], allFakeSCItems[3]);
removeFakeSCItem(allFakeSCItemsRemovers[4], allFakeSCItems[4]);

const removeAllFakeSCItemsBtn = document.getElementById("removeAllFCItems");
function removeFakeSCItems() {
  for (fSCI = 0; fSCI < allFakeSCItems_Classes.length; fSCI++) {
    allFakeSCItems_Classes[fSCI].style.display = "none";
  }
}

var containingItems = true;

removeAllFakeSCItemsBtn.addEventListener("click", () => {
  containingItems = false;
  checkingCartItems();
  removeFakeSCItems();

  setTimeout(() => {
    closeShoppingCart();
  }, 400);
});

checkingCartItems(); // checks if the shopping cart is holding any fake items
function checkingCartItems() {
  if (containingItems === true) {
    removeAllFakeSCItemsBtn.style.opacity = "1";
    removeAllFakeSCItemsBtn.disabled = false;
  } else if (containingItems === false) {
    removeAllFakeSCItemsBtn.style.opacity = "0.3";
    removeAllFakeSCItemsBtn.disabled = true;
  }

  checkFakeSCManualRemovals(); // this will check if all of the items were removed by the user one at a time
}

function checkFakeSCManualRemovals() {
  if (
    allFakeSCItems[0].style.display == "none" &&
    allFakeSCItems[1].style.display == "none" &&
    allFakeSCItems[2].style.display == "none" &&
    allFakeSCItems[3].style.display == "none" &&
    allFakeSCItems[4].style.display == "none"
  ) {
    removeAllFakeSCItemsBtn.style.opacity = "0.3";
    removeAllFakeSCItemsBtn.disabled = true;
  }
}

allFakeSCItemsRemovers.forEach((remover) => {
  remover.addEventListener("click", () => {
    checkingCartItems();
  });
});
