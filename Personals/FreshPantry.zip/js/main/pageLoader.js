/*

    This script is for the pageLoader

*/

const pageLoader = document.getElementById("pageLoaderHolder");
const pageLoaderSkipper = document.getElementById("pageLoaderSkip");
const pageLoaderSkipperBtn = document.getElementById("skipPL");

pageLoaderSkipper.style.opacity = 0;
pageLoaderSkipper.style.display = "none";

determinePageLoaderSkipper();
function determinePageLoaderSkipper() {
  setTimeout(() => {
    pageLoaderSkipper.style.display = "flex";
    pageLoaderSkipperBtn.disabled = false;
  }, 5000);
  setTimeout(() => {
    pageLoaderSkipper.style.opacity = 1;
  }, 6000);
}

function preventPageLoaderSkipper() {
  pageLoaderSkipper.style.opacity = 0;
  pageLoaderSkipper.style.display = "none";
}

function closePageLoader() {
  setTimeout(() => {
    pageLoader.classList.toggle("deactive");
    pageLoaderSkipperBtn.disabled = true;
  }, 400);
}

window.addEventListener("load", closePageLoader);
pageLoaderSkipperBtn.addEventListener("click", () => {
  pageLoader.classList.toggle("deactive");
  pageLoaderSkipperBtn.disabled = true;
});
