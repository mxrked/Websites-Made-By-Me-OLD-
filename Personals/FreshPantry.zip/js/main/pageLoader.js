/*

    This script is for the pageLoader

*/

function hidePageLoader() {
  const pageLoader = document.getElementById("pageLoader");
  setTimeout(() => {
    pageLoader.classList.toggle("deactive");
  }, 400);
}

window.addEventListener("load", hidePageLoader);
