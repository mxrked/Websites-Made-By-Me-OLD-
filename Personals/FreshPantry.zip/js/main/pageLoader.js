/*

    This script is for the pageLoader

*/

function hidePageLoader() {
  const pageLoader = document.getElementById("pageLoader");
  setTimeout(() => {
    pageLoader.classList.toggle("deactive");
  }, 1500);
}

window.addEventListener("load", hidePageLoader);
