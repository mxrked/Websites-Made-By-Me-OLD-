/*

    This script is for the index products

*/

const allIndexProductsBtns = document.querySelectorAll(".index-products-btn");
const allIndexProductsBtns_Classes =
  document.getElementsByClassName("index-products-btn");
const nonIndexAllBtns = document.querySelectorAll(".non-index-all");
var indexProductsI;

function resetIndexProductsBtns() {
  for (
    indexProductsI = 0;
    indexProductsI < allIndexProductsBtns_Classes.length;
    indexProductsI++
  ) {
    allIndexProductsBtns_Classes[indexProductsI].disabled = false;
    allIndexProductsBtns_Classes[indexProductsI].style.opacity = "1";
    allIndexProductsBtns_Classes[indexProductsI].style.backgroundColor =
      "#ef233c";
  }
}

allIndexProductsBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    resetIndexProductsBtns();
    btn.disabled = true;
    btn.style.opacity = ".5";
  });
  btn.addEventListener("mouseenter", () => {
    btn.style.backgroundColor = "#d90429";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.backgroundColor = "#ef233c";
  });
});

nonIndexAllBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    hideAllIndexProducts();
  });
});

const allIndexProductsItems = document.getElementsByClassName(
  "index-products-item"
);
function hideAllIndexProducts() {
  for (
    indexProductsI = 0;
    indexProductsI < allIndexProductsItems.length;
    indexProductsI++
  ) {
    allIndexProductsItems[indexProductsI].style.display = "none";
  }
}

const allIndexBtn = document.getElementById("indexAll");
// Default for allBtn
allIndexBtn.disabled = true;
allIndexBtn.style.opacity = ".5";
allIndexBtn.addEventListener("click", indexAllMain);
function indexAllMain() {
  for (
    indexProductsI = 0;
    indexProductsI < allIndexProductsItems.length;
    indexProductsI++
  ) {
    allIndexProductsItems[indexProductsI].style.display = "grid";
  }
}

const meatsIndexBtn = document.getElementById("indexMeats");
meatsIndexBtn.addEventListener("click", indexMeatsMain);
function indexMeatsMain() {
  const allIndexMeatsItems = document.getElementsByClassName("index-meat");
  for (
    indexProductsI = 0;
    indexProductsI < allIndexMeatsItems.length;
    indexProductsI++
  ) {
    allIndexMeatsItems[indexProductsI].style.display = "grid";
  }
}

const fruitsIndexBtn = document.getElementById("indexFruits");
fruitsIndexBtn.addEventListener("click", indexFruitsMain);
function indexFruitsMain() {
  const allIndexFruitsItems = document.getElementsByClassName("index-fruit");
  for (
    indexProductsI = 0;
    indexProductsI < allIndexFruitsItems.length;
    indexProductsI++
  ) {
    allIndexFruitsItems[indexProductsI].style.display = "grid";
  }
}

const dessertsIndexBtn = document.getElementById("indexDesserts");
dessertsIndexBtn.addEventListener("click", () => {
  const allIndexDessertsItems =
    document.getElementsByClassName("index-dessert");
  for (
    indexProductsI = 0;
    indexProductsI < allIndexDessertsItems.length;
    indexProductsI++
  ) {
    allIndexDessertsItems[indexProductsI].style.display = "grid";
  }
});
