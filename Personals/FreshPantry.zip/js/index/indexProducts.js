/*

    This script is for the indexProducts

*/

const indexProductsBtns = document.getElementsByClassName("index-products-btn");
const allIndexProductsBtns = document.querySelectorAll(".index-products-btn");
const indexAllBtn = document.getElementById("indexAll");
const indexMeatsBtn = document.getElementById("indexMeats");
const indexVeggiesBtn = document.getElementById("indexVeggies");
const indexFruitsBtn = document.getElementById("indexFruits");
const indexFishBtn = document.getElementById("indexFish");
const indexDessertsBtn = document.getElementById("indexDesserts");
var indexProductsI;

const allIndexProducts = document.getElementsByClassName("index-products-item");
function hideAllIndexProducts() {
  for (
    indexProductsI = 0;
    indexProductsI < allIndexProducts.length;
    indexProductsI++
  ) {
    allIndexProducts[indexProductsI].style.display = "none";
  }
}

function enableIPBtns() {
  for (
    indexProductsI = 0;
    indexProductsI < indexProductsBtns.length;
    indexProductsI++
  ) {
    indexProductsBtns[indexProductsI].classList.remove("disabling");
    indexProductsBtns[indexProductsI].disabled = false;
  }
}

allIndexProductsBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    enableIPBtns();
    hideAllIndexProducts();
  });
});

function showAllIndexProducts() {
  for (
    indexProductsI = 0;
    indexProductsI < allIndexProducts.length;
    indexProductsI++
  ) {
    allIndexProducts[indexProductsI].style.display = "block";
  }
}

// Styling the show all products
showAllIndexProducts();
indexAllBtn.classList.toggle("disabling");
indexAllBtn.disabled = true;

indexAllBtn.addEventListener("click", () => {
  indexAllBtn.classList.toggle("disabling");
  indexAllBtn.disabled = true;
  showAllIndexProducts();
  // show all products
});

const allIndexMeats = document.getElementsByClassName("index-meats");
indexMeatsBtn.addEventListener("click", () => {
  indexMeatsBtn.classList.toggle("disabling");
  indexMeatsBtn.disabled = true;

  for (
    indexProductsI = 0;
    indexProductsI < allIndexMeats.length;
    indexProductsI++
  ) {
    allIndexMeats[indexProductsI].style.display = "block";
  }
});

const allIndexVeggies = document.getElementsByClassName("index-veggies");
indexVeggiesBtn.addEventListener("click", () => {
  indexVeggiesBtn.classList.toggle("disabling");
  indexVeggiesBtn.disabled = true;

  for (
    indexProductsI = 0;
    indexProductsI < allIndexVeggies.length;
    indexProductsI++
  ) {
    allIndexVeggies[indexProductsI].style.display = "block";
  }
});

const allIndexFruits = document.getElementsByClassName("index-fruits");
indexFruitsBtn.addEventListener("click", () => {
  indexFruitsBtn.classList.toggle("disabling");
  indexFruitsBtn.disabled = true;

  for (
    indexProductsI = 0;
    indexProductsI < allIndexFruits.length;
    indexProductsI++
  ) {
    allIndexFruits[indexProductsI].style.display = "block";
  }
});

const allIndexFish = document.getElementsByClassName("index-fish");
indexFishBtn.addEventListener("click", () => {
  indexFishBtn.classList.toggle("disabling");
  indexFishBtn.disabled = true;

  for (
    indexProductsI = 0;
    indexProductsI < allIndexFish.length;
    indexProductsI++
  ) {
    allIndexFish[indexProductsI].style.display = "block";
  }
});

const allIndexDesserts = document.getElementsByClassName("index-desserts");
indexDessertsBtn.addEventListener("click", () => {
  indexDessertsBtn.classList.toggle("disabling");
  indexDessertsBtn.disabled = true;

  for (
    indexProductsI = 0;
    indexProductsI < allIndexDesserts.length;
    indexProductsI++
  ) {
    allIndexDesserts[indexProductsI].style.display = "block";
  }
});
