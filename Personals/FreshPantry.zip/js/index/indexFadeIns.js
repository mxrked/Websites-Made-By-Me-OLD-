/*

    This script is for the index page fade ins (Mostly for the indexHero)

*/

document.querySelectorAll(".index-fade-in").forEach((fi) => {
  fi.style.position = "relative";
});

var iFII;

hideIndexFadeIns();
function hideIndexFadeIns() {
  for (
    iFII = 0;
    iFII < document.getElementsByClassName("index-fade-in").length;
    iFII++
  ) {
    document.getElementsByClassName("index-fade-in")[iFII].style.display =
      "none";
    document
      .getElementsByClassName("index-fade-in")
      [iFII].classList.toggle("deactive");
  }
}

function loadIndexFadeIns() {
  loadIndexHeroFIS();
}

function loadIndexHeroFIS() {
  const iHeroH5 = document.getElementById("indexHeroH5");
  const iHeroH2 = document.getElementById("indexHeroH2");
  const iHeroLink = document.getElementById("indexHeroLink");

  for (
    iFII = 0;
    iFII < document.getElementsByClassName("index-fade-in").length;
    iFII++
  ) {
    document.getElementsByClassName("index-fade-in")[iFII].style.display =
      "block";
  }

  setTimeout(() => {
    iHeroH5.style.top = "0";
    iHeroH5.classList.remove("deactive");
  }, 500);
  setTimeout(() => {
    iHeroH2.style.left = "0";
    iHeroH2.classList.remove("deactive");
  }, 800);
  setTimeout(() => {
    iHeroLink.style.bottom = "0";
    iHeroLink.classList.remove("deactive");
  }, 1050);
}
