/*

    This script is for the pageSectJumper

*/

const PAGE_SECT_JUMPER = document.getElementById("pageSectJumper");
const ALL_PAGE_SECTS = [document.getElementById("indexHero")];
const ALL_PAGE_SECT_JUMPER_STICKS = document.querySelectorAll(
  ".page-sect-jumper-stick"
);
const ALL_SECT_JUMPER_BTNS = document.querySelectorAll(".page-sect-jumper-btn");
var stickTrigger;

// Main Jump function
function pageSectJumper(jump) {
  var jumpTop = document.getElementById(jump).offsetTop;
  window.scrollTo(0, jumpTop);
}

function resetSticks() {
  for (
    stickTrigger = 0;
    stickTrigger < ALL_PAGE_SECT_JUMPER_STICKS.length;
    stickTrigger++
  ) {
    ALL_PAGE_SECT_JUMPER_STICKS[stickTrigger].style.borderRadius = "0";
    ALL_PAGE_SECT_JUMPER_STICKS[stickTrigger].style.height = "3px";
  }
}

function checkSectStateScrollY() {
  // When User Scrolls
  if (window.scrollY == ALL_PAGE_SECTS[0].offsetTop) {
    // alert("True Aswell");
    ALL_PAGE_SECT_JUMPER_STICKS[0].style.borderRadius = "100%";
    ALL_PAGE_SECT_JUMPER_STICKS[0].style.height = "10px";
  } else {
    resetSticks();
  }
}

function checkSectStateScreenY() {
  if (window.screenY == ALL_PAGE_SECTS[0].offsetTop) {
    ALL_PAGE_SECT_JUMPER_STICKS[0].style.borderRadius = "100%";
    ALL_PAGE_SECT_JUMPER_STICKS[0].style.height = "10px";
  } else {
    resetSticks();
  }
}

window.addEventListener("load", () => {
  checkSectStateScreenY();
});
window.addEventListener("scroll", checkSectStateScrollY);
