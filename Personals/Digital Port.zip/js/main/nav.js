/* 

    This script is for the nav

*/

const NAV_FLASH_FIX = document.getElementById("navFlashFix");
const NAV_TOGGLER = document.getElementById("navToggler");
const NAV_CLOSER = document.getElementById("navCloser");
const NAV_LINKS = document.getElementById("navLinks");
const NAV_LINKS_CNT = document.getElementById("navLinksContent");
const NAV_LINKS_CNT_UL = document.querySelector("#navLinksContent ul");

NAV_TOGGLER.style.top = "-70px"; // Slides navToggler out

closeNav(); // Main close nav function
function closeNav() {
  NAV_LINKS.classList.toggle("deactive");
  NAV_LINKS.style.top = "-100%";

  setTimeout(() => {
    NAV_LINKS_CNT.classList.toggle("deactive");
  }, 100);
  setTimeout(() => {
    // Slides navLinks links out
    NAV_LINKS_CNT_UL.style.left = "-90px";
  }, 300);
  // Show Page Fade Ins
  setTimeout(() => {
    showIndexPageFIS();
  }, 1000);
}

// Opening the Nav
NAV_TOGGLER.addEventListener("click", () => {
  setTimeout(() => {
    NAV_LINKS.classList.remove("deactive");
  }, 10);
  setTimeout(() => {
    NAV_LINKS.style.top = "0";
  }, 100);
  setTimeout(() => {
    NAV_LINKS_CNT.classList.remove("deactive");
    NAV_LINKS_CNT_UL.style.left = "0"; // Slides navLinks links in
  }, 1100);

  // Hide Page Fade Ins
  hideIndexPageFIS();
});

// Closing the Nav
NAV_CLOSER.addEventListener("click", closeNav);

window.addEventListener("load", () => {
  NAV_FLASH_FIX.classList.toggle("deactive"); // This will remove the fix for the navLinks flash after the page has fully loaded

  setTimeout(() => {
    // Slides navToggler back in
    NAV_TOGGLER.style.top = "0";
  }, 900);
});
