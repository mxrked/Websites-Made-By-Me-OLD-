/*

    This script is for the advanced hovers that can be down better in js

*/

//* Index Advanced Hovers

const ALL_INDEX_AHS = [(heroImg = document.getElementById("indexHeroImg"))];

// Index Hero
document.querySelector("#indexHeroBox").addEventListener("mouseenter", () => {
  ALL_INDEX_AHS[0].style.transform = "rotate(30deg)";
  setTimeout(() => {
    ALL_INDEX_AHS[0].style.transform = "rotate(-30deg)";
  }, 300);
  setTimeout(() => {
    ALL_INDEX_AHS[0].style.transform = "rotate(0deg)";
  }, 500);
});
document.querySelector("#indexHeroBox").addEventListener("mouseleave", () => {
  ALL_INDEX_AHS[0].style.transform = "rotate(0deg)";
});
