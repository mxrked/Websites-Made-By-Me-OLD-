/*

    This script is for the indexHero

*/

mainIndexHeroInit();
function mainIndexHeroInit() {
  const allIndexHeroBgs = document.querySelectorAll(".index-hero-bg");
  const indexHeroBgChangerOne = document.getElementById("bgChanger1");
  const indexHeroBgChangerTwo = document.getElementById("bgChanger2");
  const indexHeroBgChangerThree = document.getElementById("bgChanger3");
  const allIndexHeroBgChangers = document.getElementsByClassName("bg-changer");
  var indexHeroI;
  var indexHeroBGNum;

  //
  //
  //

  // This will make it easier to reset each bg changer button
  unDisableBgChangers();
  function unDisableBgChangers() {
    for (
      indexHeroI = 0;
      indexHeroI < allIndexHeroBgChangers.length;
      indexHeroI++
    ) {
      allIndexHeroBgChangers[indexHeroI].disabled = false;
      allIndexHeroBgChangers[indexHeroI].style.opacity = 1;
    }
  }

  // This will be used to hide each bg when toggling a different bg
  hideAllIndexBgs();
  function hideAllIndexBgs() {
    allIndexHeroBgs.forEach((bg) => {
      bg.style.opacity = 0;
    });
  }

  // Preventing repetitive code
  function bgResets() {
    unDisableBgChangers();
    hideAllIndexBgs();
  }

  // This will show the first bg by default
  showFirstIndexHeroBG();
  function showFirstIndexHeroBG() {
    unDisableBgChangers();
    indexHeroBgChangerOne.disabled = true;
    indexHeroBgChangerOne.style.opacity = 0.4;
    allIndexHeroBgs[0].style.opacity = 1;
    indexHeroBGNum = 1;
  }

  function showSecondIndexHeroBG() {
    bgResets();
    indexHeroBgChangerTwo.disabled = true;
    indexHeroBgChangerTwo.style.opacity = 0.4;
    allIndexHeroBgs[1].style.opacity = 1;
    indexHeroBGNum = 2;
  }

  function showThirdIndexHeroBG() {
    bgResets();
    indexHeroBgChangerThree.disabled = true;
    indexHeroBgChangerThree.style.opacity = 0.4;
    allIndexHeroBgs[2].style.opacity = 1;
    indexHeroBGNum = 3;
  }

  //
  //
  //

  //? Events
  indexHeroBgChangerOne.addEventListener("click", () => {
    hideAllIndexBgs();
    showFirstIndexHeroBG();
  });
  indexHeroBgChangerTwo.addEventListener("click", () => {
    bgResets();
    showSecondIndexHeroBG();
  });
  indexHeroBgChangerThree.addEventListener("click", () => {
    bgResets();
    showThirdIndexHeroBG();
  });
}

//* Possibly add code for after pageLoader loads?
