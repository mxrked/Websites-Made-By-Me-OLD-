/*

    This script is for changing the index hero bgs

*/

mainIndexHeroInit();
function mainIndexHeroInit() {
  const allIndexHeroBgs = document.querySelectorAll(".index-hero-bg");
  const indexHeroBgChanger1 = document.getElementById("bgChange1");
  const indexHeroBgChanger2 = document.getElementById("bgChange2");
  const indexHeroBgChanger3 = document.getElementById("bgChange3");
  const allIndexHeroBgChangers = document.getElementsByClassName("bg-changer");
  var indexHeroI;

  // Sets each btn to disabled false for faster way of being able to click btns
  unDisableBgChangers();
  function unDisableBgChangers() {
    for (
      indexHeroI = 0;
      indexHeroI < allIndexHeroBgChangers.length;
      indexHeroI++
    ) {
      allIndexHeroBgChangers[indexHeroI].disabled = false;
      allIndexHeroBgChangers[indexHeroI].style.opacity = 1;
    }
  } //* Leaving unDisableBgChangers();

  hideAllIndexHeroBgs();
  function hideAllIndexHeroBgs() {
    allIndexHeroBgs.forEach((bg) => {
      bg.style.opacity = 0;
    });
  } //* Leaving hideAllIndexHeroBgs();

  // This is to avoid repetition for bgs 2 and 3
  function bgResets() {
    unDisableBgChangers();
    hideAllIndexHeroBgs();
  } //* Leaving bgResets();

  // This will show the first bg by default
  showFirstIndexHeroBg();
  function showFirstIndexHeroBg() {
    unDisableBgChangers();
    indexHeroBgChanger1.disabled = true;
    indexHeroBgChanger1.style.opacity = 0.4;
    allIndexHeroBgs[0].style.opacity = 1;
  } //* Leaving showFirstIndexHeroBg();

  //? Events
  indexHeroBgChanger1.addEventListener("click", () => {
    hideAllIndexHeroBgs();
    showFirstIndexHeroBg();
  });
  indexHeroBgChanger2.addEventListener("click", () => {
    bgResets();
    indexHeroBgChanger2.disabled = true;
    indexHeroBgChanger2.style.opacity = 0.4;
    allIndexHeroBgs[1].style.opacity = 1;
  });
  indexHeroBgChanger3.addEventListener("click", () => {
    bgResets();
    indexHeroBgChanger3.disabled = true;
    indexHeroBgChanger3.style.opacity = 0.4;
    allIndexHeroBgs[2].style.opacity = 1;
  });
} //* Leaving mainIndexHeroInit();

// For Page loader

const indexHeroCnt = document.getElementById("indexHeroCnt");
indexHeroCnt.style.position = "relative";
indexHeroCnt.style.left = "-40px";
indexHeroCnt.classList.toggle("deactive");
indexHeroCnt.style.display = "none";

function loadIndexHeroCnt() {
  indexHeroCnt.style.display = "block";

  setTimeout(() => {
    indexHeroCnt.style.left = "0px";
    indexHeroCnt.classList.remove("deactive");
  }, 600);
}
