/*

    This script is for the index hero

*/

const INDEX_HERO_BG = document.getElementById("indexHeroBGS");
const ALL_INDEX_HERO_BGS = document.querySelectorAll(".index-hero-bg");

const INDEX_HERO_BGS_CLASSES = document.getElementsByClassName("index-hero-bg");

const INDEX_HERO_BG_CHANGERS = [
  (changer1 = document.getElementById("bg1Change")),
  (changer2 = document.getElementById("bg2Change")),
  (changer3 = document.getElementById("bg3Change")),
];

const INDEX_HERO_BG_CHANGER_CLASSES = document.getElementsByClassName(
  "index-hero-bg-changer"
);

var iHBG;

//
//
//

//* Functions

// Hiding all the bgs faster
function hideAllBGS() {
  for (iHBG = 0; iHBG < INDEX_HERO_BGS_CLASSES.length; iHBG++) {
    INDEX_HERO_BGS_CLASSES[iHBG].style.opacity = 0;
  }
}

// Makes the bg changer not clickable and disables interference of other bgs
function disableBGChangers() {
  for (iHBG = 0; iHBG < INDEX_HERO_BG_CHANGERS.length; iHBG++) {
    INDEX_HERO_BG_CHANGERS[iHBG].disabled = false;
  }
}

// This will fix the postion of bgs, showing the first bg first
showStartingBG();
function showStartingBG() {
  hideAllBGS();
  disableBGChangers();
  ALL_INDEX_HERO_BGS[0].style.opacity = "1";
  INDEX_HERO_BG_CHANGERS[0].disabled = true;
}

//
//
//

//* Events

// Bg changer 1
INDEX_HERO_BG_CHANGERS[0].addEventListener("click", showStartingBG);

// Bg changer 2
INDEX_HERO_BG_CHANGERS[1].addEventListener("click", () => {
  hideAllBGS();
  disableBGChangers();
  ALL_INDEX_HERO_BGS[1].style.opacity = "1";
  INDEX_HERO_BG_CHANGERS[1].disabled = true;
});

// Bg changer 3
INDEX_HERO_BG_CHANGERS[2].addEventListener("click", () => {
  hideAllBGS();
  disableBGChangers();
  ALL_INDEX_HERO_BGS[2].style.opacity = "1";
  INDEX_HERO_BG_CHANGERS[2].disabled = true;
});
