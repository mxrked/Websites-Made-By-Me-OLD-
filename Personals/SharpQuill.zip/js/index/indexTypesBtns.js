/*

    This script will seperate the indexTypes btns (This is to prevent performance issues AKA FORCED OVERFLOW)

*/

const allTypesBtn = document.getElementById("allIndexTypes");
const atelerixTypesBtn = document.getElementById("indexType1");
const erinaceusTypesBtn = document.getElementById("indexType2");
const hemiechinusTypesBtn = document.getElementById("indexType3");
const mesechinusTypesBtn = document.getElementById("indexType4");
const paraechinusTypesBtn = document.getElementById("indexType5");

allTypesBtn.addEventListener("click", () => {
  showAllTypes();
  allTypesBtn.disabled = true;
  allTypesBtn.style.opacity = 0.2;
});
atelerixTypesBtn.addEventListener("click", () => {
  hideAllTypes();
  unDisableIndexTypeBtns();
  showIndexAtelerixTypes();
  atelerixTypesBtn.disabled = true;
  atelerixTypesBtn.style.opacity = 0.2;
});
erinaceusTypesBtn.addEventListener("click", () => {
  hideAllTypes();
  unDisableIndexTypeBtns();
  showIndexErinaceusTypes();
  erinaceusTypesBtn.disabled = true;
  erinaceusTypesBtn.style.opacity = 0.2;
});
hemiechinusTypesBtn.addEventListener("click", () => {
  hideAllTypes();
  unDisableIndexTypeBtns();
  showIndexHemiechinusTypes();
  hemiechinusTypesBtn.disabled = true;
  hemiechinusTypesBtn.style.opacity = 0.2;
});
mesechinusTypesBtn.addEventListener("click", () => {
  hideAllTypes();
  unDisableIndexTypeBtns();
  showIndexMesechinusTypes();
  mesechinusTypesBtn.disabled = true;
  mesechinusTypesBtn.style.opacity = 0.2;
});
paraechinusTypesBtn.addEventListener("click", () => {
  hideAllTypes();
  unDisableIndexTypeBtns();
  showIndexParaechinusTypes();
  paraechinusTypesBtn.disabled = true;
  paraechinusTypesBtn.style.opacity = 0.2;
});
