/*

    This script is for the indexTypes

*/

const allIndexTypes_Classes = document.getElementsByClassName("index-type");
const allAtelerixTypes_Classes = document.getElementsByClassName(
  "atelerix-type"
);
const allErinaceusTypes_Classes = document.getElementsByClassName(
  "erinaceus-type"
);
const allHemiechinusTypes_Classes = document.getElementsByClassName(
  "hemiechinus-type"
);
const allMesechinusTypes_Classes = document.getElementsByClassName(
  "mesechinus-type"
);
const allParaechinusTypes_Classes = document.getElementsByClassName(
  "paraechinus-type"
);

const allTypesBtns = document.querySelectorAll(".index-types-btn");
var indexTypesI;

// Hiding all the types for each type toggled
//hideAllTypes();
function hideAllTypes() {
  for (
    indexTypesI = 0;
    indexTypesI < allIndexTypes_Classes.length;
    indexTypesI++
  ) {
    allIndexTypes_Classes[indexTypesI].style.display = "none";
  }
}

// This will show all the types by default also this is for the allTypesBtn
showAllTypes();
function showAllTypes() {
  unDisableIndexTypeBtns();
  for (
    indexTypesI = 0;
    indexTypesI < allIndexTypes_Classes.length;
    indexTypesI++
  ) {
    allIndexTypes_Classes[indexTypesI].style.display = "block";
  }
}

// Faster way of re enabling the type btns
function unDisableIndexTypeBtns() {
  allTypesBtns.forEach((btn) => {
    btn.disabled = false;
    btn.style.opacity = 1;
  });
}

// Specific function for specific index type
function showIndexAtelerixTypes() {
  for (
    indexTypesI = 0;
    indexTypesI < allAtelerixTypes_Classes.length;
    indexTypesI++
  ) {
    allAtelerixTypes_Classes[indexTypesI].style.display = "block";
  }
}
function showIndexErinaceusTypes() {
  for (
    indexTypesI = 0;
    indexTypesI < allErinaceusTypes_Classes.length;
    indexTypesI++
  ) {
    allErinaceusTypes_Classes[indexTypesI].style.display = "block";
  }
}
function showIndexHemiechinusTypes() {
  for (
    indexTypesI = 0;
    indexTypesI < allHemiechinusTypes_Classes.length;
    indexTypesI++
  ) {
    allHemiechinusTypes_Classes[indexTypesI].style.display = "block";
  }
}
function showIndexMesechinusTypes() {
  for (
    indexTypesI = 0;
    indexTypesI < allMesechinusTypes_Classes.length;
    indexTypesI++
  ) {
    allMesechinusTypes_Classes[indexTypesI].style.display = "block";
  }
}
function showIndexParaechinusTypes() {
  for (
    indexTypesI = 0;
    indexTypesI < allParaechinusTypes_Classes.length;
    indexTypesI++
  ) {
    allParaechinusTypes_Classes[indexTypesI].style.display = "block";
  }
}
