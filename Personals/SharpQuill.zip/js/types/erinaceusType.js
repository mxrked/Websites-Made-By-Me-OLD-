/*

    This script will be for the erinaceus imgs and modals on the types page

*/

const allErinaceusImgs = document.querySelectorAll(".type-erinaceus-img");
const allErinaceusModals_Classes = document.getElementsByClassName(
  "type-erinaceus-modal"
);
const allErinaceusModals = document.querySelectorAll(".type-erinaceus-modal");
var typeErinaceusI;

// Hide the atelerix modals
hideErinaceusModals();
function hideErinaceusModals() {
  for (
    typeErinaceusI = 0;
    typeErinaceusI < allErinaceusModals_Classes.length;
    typeErinaceusI++
  ) {
    allErinaceusModals_Classes[typeErinaceusI].style.display = "none";
    allErinaceusModals_Classes[typeErinaceusI].classList.toggle("deactive");
  }
}

//* Events

// Img/Modal 1
allErinaceusImgs[0].addEventListener("click", () => {
  allErinaceusModals[0].style.display = "grid";

  setTimeout(() => {
    allErinaceusModals[0].classList.remove("deactive");
  }, 400);
});

// Img/Modal 2
allErinaceusImgs[1].addEventListener("click", () => {
  allErinaceusModals[1].style.display = "grid";

  setTimeout(() => {
    allErinaceusModals[1].classList.remove("deactive");
  }, 400);
});

// Img/Modal 3
allErinaceusImgs[2].addEventListener("click", () => {
  allErinaceusModals[2].style.display = "grid";

  setTimeout(() => {
    allErinaceusModals[2].classList.remove("deactive");
  }, 400);
});

// Img/Modal 4
allErinaceusImgs[3].addEventListener("click", () => {
  allErinaceusModals[3].style.display = "grid";

  setTimeout(() => {
    allErinaceusModals[3].classList.remove("deactive");
  }, 400);
});
