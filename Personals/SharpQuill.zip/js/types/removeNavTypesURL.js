/*

    This script will be used to remove the # from the url when the user clicks on a type img

*/

document.querySelectorAll(".type-atelerix-img").forEach((img) => {
  img.addEventListener("click", removeNavTypeURL);
});

document.querySelectorAll(".type-erinaceus-img").forEach((img) => {
  img.addEventListener("click", removeNavTypeURL);
});

document.querySelectorAll(".type-hemiechinus-img").forEach((img) => {
  img.addEventListener("click", removeNavTypeURL);
});

document.querySelectorAll(".type-mesechinus-img").forEach((img) => {
  img.addEventListener("click", removeNavTypeURL);
});

document.querySelectorAll(".type-paraechinus-img").forEach((img) => {
  img.addEventListener("click", removeNavTypeURL);
});
