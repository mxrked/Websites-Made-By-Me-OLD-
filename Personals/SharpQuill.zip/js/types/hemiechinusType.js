/*

    This script will be for the hemiechinus imgs and modals on the types page

*/

const allHemiechinusImgs = document.querySelectorAll(".type-hemiechinus-img");
const allHemiechinusModals_Classes = document.getElementsByClassName(
  "type-hemiechinus-modal"
);
const allHemiechinusModals = document.querySelectorAll(
  ".type-hemiechinus-modal"
);
var typeHemiechinusI;

// Hide the hemiechinus modals
hideHemiechinusModals();
function hideHemiechinusModals() {
  for (
    typeHemiechinusI = 0;
    typeHemiechinusI < allHemiechinusModals_Classes.length;
    typeHemiechinusI++
  ) {
    allHemiechinusModals_Classes[typeHemiechinusI].style.display = "none";
    allHemiechinusModals_Classes[typeHemiechinusI].classList.toggle("deactive");
  }
}

//* Events

// Img/Modal 1
allHemiechinusImgs[0].addEventListener("click", () => {
  allHemiechinusModals[0].style.display = "grid";

  setTimeout(() => {
    allHemiechinusModals[0].classList.remove("deactive");
  }, 400);
});

// Img/Modal 2
allHemiechinusImgs[1].addEventListener("click", () => {
  allHemiechinusModals[1].style.display = "grid";

  setTimeout(() => {
    allHemiechinusModals[1].classList.remove("deactive");
  }, 400);
});
