/*

    This script will be for the paraechinus imgs and modals on the types page

*/

const allParaechinusImgs = document.querySelectorAll(".type-paraechinus-img");
const allParaechinusIModals_Classes = document.getElementsByClassName(
  "type-paraechinus-modal"
);
const allParaechinusIModals = document.querySelectorAll(
  ".type-paraechinus-modal"
);
var typeParaechinusI;

// Hide the hemiechinus modals
hideParaechinusModals();
function hideParaechinusModals() {
  for (
    typeParaechinusI = 0;
    typeParaechinusI < allParaechinusIModals_Classes.length;
    typeParaechinusI++
  ) {
    allParaechinusIModals_Classes[typeParaechinusI].style.display = "none";
    allParaechinusIModals_Classes[typeParaechinusI].classList.toggle(
      "deactive"
    );
  }
}

//* Events

// Img/Modal 1
allParaechinusImgs[0].addEventListener("click", () => {
  allParaechinusIModals[0].style.display = "grid";

  setTimeout(() => {
    allParaechinusIModals[0].classList.remove("deactive");
  }, 400);
});

// Img/Modal 2
allParaechinusImgs[1].addEventListener("click", () => {
  allParaechinusIModals[1].style.display = "grid";

  setTimeout(() => {
    allParaechinusIModals[1].classList.remove("deactive");
  }, 400);
});

// Img/Modal 3
allParaechinusImgs[2].addEventListener("click", () => {
  allParaechinusIModals[2].style.display = "grid";

  setTimeout(() => {
    allParaechinusIModals[2].classList.remove("deactive");
  }, 400);
});
