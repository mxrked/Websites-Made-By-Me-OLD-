/*

    This script will be for the atelerix imgs and modals on the types page

*/

const allAtelerixImgs = document.querySelectorAll(".type-atelerix-img");
const allAtelerixModals_Classes = document.getElementsByClassName(
  "type-atelerix-modal"
);
const allAtelerixModals = document.querySelectorAll(".type-atelerix-modal");
var typeAterelixI;

// Hide the atelerix modals
hideAtelerixModals();
function hideAtelerixModals() {
  for (
    typeAterelixI = 0;
    typeAterelixI < allAtelerixModals_Classes.length;
    typeAterelixI++
  ) {
    allAtelerixModals_Classes[typeAterelixI].style.display = "none";
    allAtelerixModals_Classes[typeAterelixI].classList.toggle("deactive");
  }
}

// Events
allAtelerixImgs[0].addEventListener("click", () => {
  allAtelerixModals[0].style.display = "grid";

  setTimeout(() => {
    allAtelerixModals[0].classList.remove("deactive");
  }, 400);
});
allAtelerixImgs[1].addEventListener("click", () => {
  allAtelerixModals[1].style.display = "grid";

  setTimeout(() => {
    allAtelerixModals[1].classList.remove("deactive");
  }, 400);
});
