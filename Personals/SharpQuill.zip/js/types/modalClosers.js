/*

    This will be the main script for all the modal closers

*/

const allModalClosers_Classes = document.getElementsByClassName(
  "type-modal-closer"
);
var modalClosersI;
const allModalClosers = document.querySelectorAll(".type-modal-closer");

// Works with all closers
allModalClosers.forEach((closer) => {
  closer.addEventListener("click", () => {
    hideAtelerixModals();
    hideErinaceusModals();
    hideHemiechinusModals();
    hideMesechinusModals();
    hideParaechinusModals();
  });
});

function atelerixDetermine(e) {
  if (
    e.target == document.getElementById("atelerixM1") ||
    e.target == document.getElementById("atelerixM2") ||
    e.target == document.getElementById("atelerixM3") ||
    e.target == document.getElementById("atelerixM4")
  ) {
    hideAtelerixModals();
  }
}

function erinaceusDetermine(e) {
  if (
    e.target == document.getElementById("erinaceusM1") ||
    e.target == document.getElementById("erinaceusM2") ||
    e.target == document.getElementById("erinaceusM3") ||
    e.target == document.getElementById("erinaceusM4")
  ) {
    hideErinaceusModals();
  }
}

function hemiechinusDetermine(e) {
  if (
    e.target == document.getElementById("hemiechinusM1") ||
    e.target == document.getElementById("hemiechinusM2") ||
    e.target == document.getElementById("hemiechinusM3") ||
    e.target == document.getElementById("hemiechinusM4")
  ) {
    hideHemiechinusModals();
  }
}

function mesechinusDetermine(e) {
  if (
    e.target == document.getElementById("mesechinusM1") ||
    e.target == document.getElementById("mesechinusM2") ||
    e.target == document.getElementById("mesechinusM3")
  ) {
    hideMesechinusModals();
  }
}

function paraechinusDetermine(e) {
  if (
    e.target == document.getElementById("paraechinusM1") ||
    e.target == document.getElementById("paraechinusM2") ||
    e.target == document.getElementById("paraechinusM3")
  ) {
    hideParaechinusModals();
  }
}

window.onclick = function (e) {
  atelerixDetermine(e);
  erinaceusDetermine(e);
  hemiechinusDetermine(e);
  mesechinusDetermine(e);
  paraechinusDetermine(e);
};
