/*

    This will be the main script for all the modal closers

*/

const allModalClosers_Classes = document.getElementsByClassName(
  "type-modal-closer"
);
var modalClosersI;
const allModalClosers = document.querySelectorAll(".type-modal-closer");

// Works with all closers
allModalClosers.forEach((closer) => {
  closer.addEventListener("click", () => {
    hideAtelerixModals();
    hideErinaceusModals();
    hideHemiechinusModals();
  });
});

function atelerixDetermine(e) {
  if (
    e.target == document.getElementById("atelerixM1") ||
    e.target == document.getElementById("atelerixM2") ||
    e.target == document.getElementById("atelerixM3") ||
    e.target == document.getElementById("atelerixM4")
  ) {
    hideAtelerixModals();
  }
}

function erinaceusDetermine(e) {
  if (
    e.target == document.getElementById("erinaceusM1") ||
    e.target == document.getElementById("erinaceusM2") ||
    e.target == document.getElementById("erinaceusM3") ||
    e.target == document.getElementById("erinaceusM4")
  ) {
    hideErinaceusModals();
  }
}

function hemiechinusDetermine(e) {
  if (
    e.target == document.getElementById("hemiechinusM1") ||
    e.target == document.getElementById("hemiechinusM2") ||
    e.target == document.getElementById("hemiechinusM3") ||
    e.target == document.getElementById("hemiechinusM4")
  ) {
    hideHemiechinusModals();
  }
}

window.onclick = function (e) {
  atelerixDetermine(e);
  erinaceusDetermine(e);
  hemiechinusDetermine(e);
};
