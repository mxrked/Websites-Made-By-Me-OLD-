/*

    This will be the main script for all the modal closers

*/

const allModalClosers_Classes = document.getElementsByClassName(
  "type-modal-closer"
);
var modalClosersI;
const allModalClosers = document.querySelectorAll(".type-modal-closer");

// Works with all closers
allModalClosers.forEach((closer) => {
  closer.addEventListener("click", () => {
    hideAtelerixModals();
  });
});
