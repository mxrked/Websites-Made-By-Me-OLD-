/*

    This will be the main script for all the modal closers

*/

const allModalClosers_Classes = document.getElementsByClassName(
  "type-modal-closer"
);
var modalClosersI;
const allModalClosers = document.querySelectorAll(".type-modal-closer");

// Works with all closers
allModalClosers.forEach((closer) => {
  closer.addEventListener("click", () => {
    hideAtelerixModals();
  });
});

function atelerixDetermine(e) {
  if (
    e.target == document.getElementById("atelerixM1") ||
    e.target == document.getElementById("atelerixM2") ||
    e.target == document.getElementById("atelerixM3") ||
    e.target == document.getElementById("atelerixM4")
  ) {
    hideAtelerixModals();
  }
}

window.onclick = function (e) {
  atelerixDetermine(e);
};
