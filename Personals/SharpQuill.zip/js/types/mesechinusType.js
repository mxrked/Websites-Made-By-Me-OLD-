/*

    This script will be for the mesechinus imgs and modals on the types page

*/

const allMesechinusImgs = document.querySelectorAll(".type-mesechinus-img");
const allMesechinusModals_Classes = document.getElementsByClassName(
  "type-mesechinus-modal"
);
const allMesechinusModals = document.querySelectorAll(".type-mesechinus-modal");
var typeMesechinusI;

// Hide the hemiechinus modals
hideMesechinusModals();
function hideMesechinusModals() {
  for (
    typeMesechinusI = 0;
    typeMesechinusI < allMesechinusModals_Classes.length;
    typeMesechinusI++
  ) {
    allMesechinusModals_Classes[typeMesechinusI].style.display = "none";
    allMesechinusModals_Classes[typeMesechinusI].classList.toggle("deactive");
  }
}

//* Events

// Img/Modal 1
allMesechinusImgs[0].addEventListener("click", () => {
  allMesechinusModals[0].style.display = "grid";

  setTimeout(() => {
    allMesechinusModals[0].classList.remove("deactive");
  }, 400);
});

// Img/Modal 2
allMesechinusImgs[1].addEventListener("click", () => {
  allMesechinusModals[1].style.display = "grid";

  setTimeout(() => {
    allMesechinusModals[1].classList.remove("deactive");
  }, 400);
});

// Img/Modal 3
allMesechinusImgs[2].addEventListener("click", () => {
  allMesechinusModals[2].style.display = "grid";

  setTimeout(() => {
    allMesechinusModals[2].classList.remove("deactive");
  }, 400);
});
