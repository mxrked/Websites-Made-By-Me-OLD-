/*

    This script will check the nav types 

*/

mainNavTypesCheckerInit();
function mainNavTypesCheckerInit() {
  if (window.location.href.indexOf("atelerix") > -1) {
    const atelerixHolder = document.getElementById("atelerixTypeHolder");
    atelerixHolder.scrollIntoView();

    // Triggers this later so the desktop verison does not get confused
    setTimeout(() => {
      const atelerixMH = document.getElementById("atelerixMobile");
      atelerixMH.scrollIntoView();
    }, 600);
  } else if (window.location.href.indexOf("erinaceus") > -1) {
    const erinaceusHolder = document.getElementById("erinaceusTypeHolder");
    erinaceusHolder.scrollIntoView();

    // Triggers this later so the desktop verison does not get confused
    setTimeout(() => {
      const erinaceusMH = document.getElementById("erinaceusMobile");
      erinaceusMH.scrollIntoView();
    }, 600);
  } else if (window.location.href.indexOf("hemiechinus") > -1) {
    const hemiechinusHolder = document.getElementById("hemiechinusTypeHolder");
    hemiechinusHolder.scrollIntoView();

    // Triggers this later so the desktop verison does not get confused
    setTimeout(() => {
      const hemiechinusMH = document.getElementById("hemiechinusMobile");
      hemiechinusMH.scrollIntoView();
    }, 600);
  } else if (window.location.href.indexOf("mesechinus") > -1) {
    const mesechinusHolder = document.getElementById("mesechinusTypeHolder");
    mesechinusHolder.scrollIntoView();

    // Triggers this later so the desktop verison does not get confused
    setTimeout(() => {
      const mesechinusMH = document.getElementById("mesechinusMobile");
      mesechinusMH.scrollIntoView();
    }, 600);
  } else if (window.location.href.indexOf("paraechinus") > -1) {
    const paraechinusHolder = document.getElementById("paraechinusTypeHolder");
    paraechinusHolder.scrollIntoView();

    // Triggers this later so the desktop verison does not get confused
    setTimeout(() => {
      const paraechinusMH = document.getElementById("paraechinusMobile");
      paraechinusMH.scrollIntoView();
    }, 600);
  }
}

// This will be called on in the different hedgehog type scripts
function removeNavTypeURL() {
  history.pushState("", document.title, window.location.pathname);
}
