/*

    This script is for the backToTopBtn

*/

mainBackToTopInit();
function mainBackToTopInit() {
  const backToTopBtn = document.getElementById("backToTop");
  backToTopBtn.style.display = "none";

  function determineBTTBtn() {
    if (window.scrollY >= 1200) {
      backToTopBtn.style.display = "grid";
    } else {
      backToTopBtn.style.display = "none";
    }
  }

  window.addEventListener("scroll", determineBTTBtn);
  backToTopBtn.addEventListener("click", () => {
    window.scrollTo(0, 0);
  });
}
