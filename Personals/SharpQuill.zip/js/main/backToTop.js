/*

    This script is for the backToTopBtn

*/
