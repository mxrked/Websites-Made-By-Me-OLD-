/*

    This script is for the pageLoader;

*/

mainPageLoaderInit();
function mainPageLoaderInit() {
  const pageLoader = document.getElementById("pageLoader");

  window.addEventListener("load", () => {
    pageLoader.classList.toggle("deactive");
  });
}
