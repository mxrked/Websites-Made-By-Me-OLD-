/*

    This script is for the nav

*/

mainNavInit();
function mainNavInit() {
  const navToggler = document.getElementById("navToggler");
  const navCloser = document.getElementById("navCloser");
  const navLinks = document.getElementById("respNavLinks");
  const navLinksCnt = document.getElementById("navLinksContent");
  const darkenLayer = document.getElementById("darkenLayer");

  darkenLayer.classList.toggle("deactive");
  darkenLayer.style.display = "none";
  navCloser.classList.toggle("deactive");
  navLinksCnt.classList.toggle("deactive");

  function openNav() {
    document.body.style.overflowY = "hidden";

    darkenLayer.style.display = "block";
    setTimeout(() => {
      darkenLayer.classList.remove("deactive");
    }, 600);

    navToggler.classList.toggle("deactive");
    navLinks.style.width = "100%";

    setTimeout(() => {
      navCloser.classList.remove("deactive");
      navLinksCnt.classList.remove("deactive");
    }, 800);
  } //* Leaving openNav();

  function closeNav() {
    navCloser.classList.toggle("deactive");
    navLinksCnt.classList.toggle("deactive");

    navLinks.style.width = "0";

    darkenLayer.classList.toggle("deactive");
    setTimeout(() => {
      darkenLayer.style.display = "none";
    }, 300);

    setTimeout(() => {
      navToggler.classList.remove("deactive");
      document.body.style.overflowY = "auto";
    }, 800);
  }

  navToggler.addEventListener("click", openNav);
  navCloser.addEventListener("click", closeNav);
  window.addEventListener("click", (e) => {
    if (e.target == navLinks) {
      closeNav();
    }
  });
} //* Leaving mainNavInit();
