/*

    This script is for the nav

*/

mainNavInit();
function mainNavInit() {
  const navToggler = document.getElementById("navToggler");
  const navCloser = document.getElementById("navCloser");
  const respNavLinks = document.getElementById("respNavLinks");
  const respNavLinksTop = document.getElementById("respNavLinksTop");
  const respNavLinksBody = document.getElementById("respNavLinksBody");
  const typesToggler = document.getElementById("navTypesToggler");
  const typesCloser = document.getElementById("navTypesCloser");
  const typesLinks = document.getElementById("navTypesLinks");

  closeNav();
  function closeNav() {
    respNavLinks.style.overflowY = "hidden";
    respNavLinksTop.classList.toggle("deactive");
    respNavLinksBody.classList.toggle("deactive");
    setTimeout(() => {
      respNavLinks.style.maxHeight = 0;
    }, 700);

    closeNavTypes();
  } //* Leaving closeNav();

  function openNav() {
    setTimeout(() => {
      respNavLinks.style.overflowY = "auto";
    }, 400);

    setTimeout(() => {
      respNavLinksTop.classList.remove("deactive");
      respNavLinksBody.classList.remove("deactive");
    }, 900);

    respNavLinks.style.maxHeight = "100vh";
  } //* Leaving openNav();

  function openNavTypes() {
    typesToggler.style.display = "none";
    typesCloser.style.display = "block";
    typesLinks.style.height = "100%";
  } //* Leaving openNavTypes();

  function closeNavTypes() {
    typesToggler.style.display = "block";
    typesCloser.style.display = "none";
    typesLinks.style.height = "0";
  } //* Leaving closeNavTypes();

  navToggler.addEventListener("click", openNav);
  navCloser.addEventListener("click", () => {
    closeNav();
  });
  typesToggler.addEventListener("click", openNavTypes);
  typesCloser.addEventListener("click", closeNavTypes);
} //* Leaving mainNavInit();
