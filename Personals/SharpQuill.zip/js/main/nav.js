/*

    This script is for the nav

*/

//
//
//
//

//* Functions

//? Nav
const NAV_TOGGLER = document.getElementById("navToggler");
const NAV_CLOSER = document.getElementById("navCloser");
const NAV_LINKS = document.getElementById("navLinks");
const NAV_LINKS_CNT = document.getElementById("navLinksContent");
const DARKEN_LAYER = document.getElementById("darkenLayer");

DARKEN_LAYER.classList.toggle("deactive");
DARKEN_LAYER.style.display = "none";
NAV_LINKS_CNT.style.display = "none";

// Toggling the nav
function toggleNav() {
  DARKEN_LAYER.style.display = "block";
  document.body.style.overflowY = "hidden";

  setTimeout(() => {
    DARKEN_LAYER.classList.remove("deactive");
  }, 50);

  setTimeout(() => {
    NAV_LINKS_CNT.style.display = "block";
  }, 220);

  NAV_LINKS.style.width = "100%";
}

// Closing the nav
function closeNav() {
  closeNavTypes();

  setTimeout(() => {
    NAV_LINKS_CNT.style.display = "none";
  }, 120);

  setTimeout(() => {
    DARKEN_LAYER.classList.toggle("deactive");
  }, 175);

  NAV_LINKS.style.width = "0";

  setTimeout(() => {
    document.body.style.overflowY = "auto";
  }, 800);
}

//
//
//
//

//? Nav Types
const NAV_TYPES = document.getElementById("navTypes");
const NAV_TYPES_TOGGLER = document.getElementById("toggleTypes");
const NAV_TYPES_CLOSER = document.getElementById("closeTypes");

// Toggling the navTypes
function toggleNavTypes() {
  NAV_TYPES_TOGGLER.style.display = "none";
  NAV_TYPES_CLOSER.style.display = "flex";

  NAV_TYPES_TOGGLER.style.background = "rgb(41, 41, 41)";
  NAV_TYPES_CLOSER.style.background = "black";

  NAV_TYPES.style.maxHeight = "100%";
}

// Closing the navTypes
closeNavTypes();
function closeNavTypes() {
  NAV_TYPES_TOGGLER.style.display = "flex";
  NAV_TYPES_CLOSER.style.display = "none";

  NAV_TYPES_TOGGLER.style.background = "rgb(41, 41, 41)";
  NAV_TYPES_CLOSER.style.background = "rgb(41, 41, 41)";

  NAV_TYPES.style.maxHeight = "0";
}

//
//
//
//

//* Events and Flash fix

NAV_TOGGLER.addEventListener("click", toggleNav);
NAV_CLOSER.addEventListener("click", () => {
  window.scrollTo(0, 0);

  closeNav();
});

NAV_TYPES_TOGGLER.addEventListener("click", toggleNavTypes);
NAV_TYPES_CLOSER.addEventListener("click", closeNavTypes);

const NAV_LINKS_FLASH = document.getElementById("navLinksFlashFix");
window.addEventListener("load", () => {
  NAV_LINKS_FLASH.classList.toggle("deactive");
});

window.onclick = function (e) {
  if (e.target == NAV_LINKS) {
    closeNav();
  }
};
