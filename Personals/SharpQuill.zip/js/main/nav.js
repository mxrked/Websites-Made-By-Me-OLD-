/*

    This script is for the nav

*/

mainNavInit();
function mainNavInit() {
  const navToggler = document.getElementById("respNavToggler");
  const navCloser = document.getElementById("respNavCloser");
  const navLinks = document.getElementById("respTypeLinks");
  const navLinksContent = document.getElementById("respTypeLinksCnt");
  const darkenOL = document.getElementById("darkenOverlay");

  darkenOL.classList.toggle("deactive");
  darkenOL.style.display = "none";
  navLinksContent.classList.toggle("deactive");

  function openNav() {
    darkenOL.style.display = "block";
    setTimeout(() => {
      darkenOL.classList.remove("deactive");
    }, 250);

    setTimeout(() => {
      navLinks.style.width = "100%";
    }, 420);

    setTimeout(() => {
      navLinksContent.classList.remove("deactive");
    }, 860);
  }

  function closeNav() {
    navLinks.style.width = "0";
    navLinksContent.classList.toggle("deactive");
    setTimeout(() => {
      darkenOL.classList.toggle("deactive");
    }, 400);
  }

  navToggler.addEventListener("click", openNav);
  navCloser.addEventListener("click", closeNav);
}
