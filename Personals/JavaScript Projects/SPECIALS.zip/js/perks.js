/* This will store all of the different perks the user can gain */
