//! Strength
//* Descs
const strengthDescs = [
  {
    stat: "Wet Noodle",
  },
  {
    stat: "Beached Jellyfish",
  },
  {
    stat: "Doughy Baby",
  },
  {
    stat: "Lightweight",
  },
  {
    stat: "Average Joe",
  },
  {
    stat: "Barrel Chested",
  },
  {
    stat: "Beach Bully",
  },
  {
    stat: "Circus Strongman",
  },
  {
    stat: "Doomsday Pecs",
  },
  {
    stat: 'Hercule"s Bigger Cousin',
  },
];

//* Perks
const strengthPerks = [
  {
    pName: "Iron Fist",
  },
  {
    pName: "Big Leagues",
  },
  {
    pName: "Armorer",
  },
  {
    pName: "Blacksmith",
  },
  {
    pName: "Heavy Gunner",
  },
  {
    pName: "Strong Back",
  },
  {
    pName: "Steady Aim",
  },
  {
    pName: "Basher",
  },
  {
    pName: "Rooted",
  },
  {
    pName: "Pain Train",
  },
];

//! Perception
//* Desc
const perceptionDescs = [
  {
    stat: "Deaf Bat",
  },
  {
    stat: "Senile Mole",
  },
  {
    stat: "Squinting Newt",
  },
  {
    stat: "Unsuspecting Trout",
  },
  {
    stat: "Wary Trout",
  },
  {
    stat: "Alert Coyote",
  },
  {
    stat: "Big-eyed Tiger",
  },
  {
    stat: "Monocled Falcon",
  },
  {
    stat: "Sniper Hawk",
  },
  {
    stat: "Eagle with Telescope",
  },
];

//* Perks
const perceptionPerks = [
  {
    pName: "Pickpocket",
  },
  {
    pName: "Rifleman",
  },
  {
    pName: "Awareness",
  },
  {
    pName: "Locksmith",
  },
  {
    pName: "Demolition Expert",
  },
  {
    pName: "Night Person",
  },
  {
    pName: "Refractor",
  },
  {
    pName: "Sniper",
  },
  {
    pName: "Penetrator",
  },
  {
    pName: "Concentrated Fire",
  },
];

//! Endurance
//* Desc
const enduranceDescs = [
  {
    stat: "Bascially Dead",
  },
  {
    stat: "Crumbly",
  },
  {
    stat: "Do Not Bend",
  },
  {
    stat: "Handle with Care",
  },
  {
    stat: "Stain-resistant",
  },
  {
    stat: "Hardy",
  },
  {
    stat: "Tough-as-nails",
  },
  {
    stat: "Flame Retardant",
  },
  {
    stat: "Bulletproof",
  },
  {
    stat: "Unstoppable",
  },
];

//* Perks
const endurancePerks = [
  {
    pName: "Toughness",
  },
  {
    pName: "Lead Belly",
  },
  {
    pName: "Lifegiver",
  },
  {
    pName: "Chem Resistant",
  },
  {
    pName: "Aquaboy/Aquagirl",
  },
  {
    pName: "Rad Resistant",
  },
  {
    pName: "Adamantium Skeleton",
  },
  {
    pName: "Cannibal",
  },
  {
    pName: "Ghoulish",
  },
  {
    pName: "Solar Powered",
  },
];
