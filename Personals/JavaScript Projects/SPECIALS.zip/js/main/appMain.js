/*

    This script is for the app itself

*/

var startingPoints = 28; //* This is the REAL starting points
const currentPoints = document.getElementById("currentPoints");
var increaseBtnsI;
const allIncreaseBtns = document.getElementsByClassName("inc-btn");

// This will be used to re enable the buttons
function enableIncreaseBtns() {
  for (
    increaseBtnsI = 0;
    increaseBtnsI < allIncreaseBtns.length;
    increaseBtnsI++
  ) {
    allIncreaseBtns[increaseBtnsI].disabled = false;
    allIncreaseBtns[increaseBtnsI].style.opacity = "1";
  }
}

//
//
//

//? Strength Type
const strengthPoints = document.getElementById("sTotal");
strengthPoints.value = 1;

document.getElementById("sInc").addEventListener("click", () => {
  currentPoints.value--;
  strengthPoints.value++;
});
document.getElementById("sDec").addEventListener("click", () => {
  currentPoints.value++;
  strengthPoints.value--;
});

//? Perception Type
const perceptionPoints = document.getElementById("pTotal");
perceptionPoints.value = 1;

document.getElementById("pInc").addEventListener("click", () => {
  currentPoints.value--;
  perceptionPoints.value++;
});
document.getElementById("pDec").addEventListener("click", () => {
  currentPoints.value++;
  perceptionPoints.value--;
});

//? Endurance Type
const endurancePoints = document.getElementById("eTotal");
endurancePoints.value = 1;

document.getElementById("eInc").addEventListener("click", () => {
  currentPoints.value--;
  endurancePoints.value++;
});
document.getElementById("eDec").addEventListener("click", () => {
  currentPoints.value++;
  endurancePoints.value--;
});

//
//
//

// For all increase btns
document.querySelectorAll(".inc-btn").forEach((incbtn) => {
  incbtn.addEventListener("click", () => {
    preventStatBelowOrOver();
    determineAllStatDescs();
    determineAllStatPerks();
  });
});

// For all decrease btns
document.querySelectorAll(".dec-btn").forEach((decbtn) => {
  decbtn.addEventListener("click", () => {
    preventStatBelowOrOver();
    determineAllStatDescs();
    determineAllStatPerks();
  });
});

//
//
//

// Update the currentPoints
updateCurrentPoints();
function updateCurrentPoints() {
  currentPoints.value =
    startingPoints -
    strengthPoints.value -
    perceptionPoints.value -
    endurancePoints.value;
}

//
//
//

// This will prevent the user from going into negative currentPoints
function preventZeroPoints() {
  if (currentPoints.value == 0) {
    currentPoints.style.borderColor = "red";
    for (
      increaseBtnsI = 0;
      increaseBtnsI < allIncreaseBtns.length;
      increaseBtnsI++
    ) {
      allIncreaseBtns[increaseBtnsI].disabled = true;
      allIncreaseBtns[increaseBtnsI].style.opacity = ".6";
    }
  } else {
    currentPoints.style.borderColor = "rgb(228, 228, 230)";
    enableIncreaseBtns();
  }
}

//
//
//

// Prevent the stat points going over 10 or below 1
function preventStatBelowOrOver() {
  //* Strength Points
  if (strengthPoints.value >= 10) {
    strengthPoints.value = 10;
    updateCurrentPoints();
  } else if (strengthPoints.value <= 1) {
    strengthPoints.value = 1;
    updateCurrentPoints();
  }

  //* Perception Points
  if (perceptionPoints.value >= 10) {
    perceptionPoints.value = 10;
    updateCurrentPoints();
  } else if (perceptionPoints.value <= 1) {
    perceptionPoints.value = 1;
    updateCurrentPoints();
  }

  //* Endurance Points
  if (endurancePoints.value >= 10) {
    endurancePoints.value = 10;
    updateCurrentPoints();
  } else if (endurancePoints.value <= 1) {
    endurancePoints.value = 1;
    updateCurrentPoints();
  }

  preventZeroPoints();
}

//
//
//

// Displaying stat descriptions based on stat points
determineAllStatDescs();
function determineAllStatDescs() {
  determineStrengthDesc();
  determinePerceptionDesc();
  determineEnduranceDesc();
}

function determineStrengthDesc() {
  const strengthDesc = document.getElementById("sStatDesc");
  if (strengthPoints.value == 1) {
    strengthDesc.innerHTML = strengthDescs[0].stat;
  } else if (strengthPoints.value == 2) {
    strengthDesc.innerHTML = strengthDescs[1].stat;
  } else if (strengthPoints.value == 3) {
    strengthDesc.innerHTML = strengthDescs[2].stat;
  } else if (strengthPoints.value == 4) {
    strengthDesc.innerHTML = strengthDescs[3].stat;
  } else if (strengthPoints.value == 5) {
    strengthDesc.innerHTML = strengthDescs[4].stat;
  } else if (strengthPoints.value == 6) {
    strengthDesc.innerHTML = strengthDescs[5].stat;
  } else if (strengthPoints.value == 7) {
    strengthDesc.innerHTML = strengthDescs[6].stat;
  } else if (strengthPoints.value == 8) {
    strengthDesc.innerHTML = strengthDescs[7].stat;
  } else if (strengthPoints.value == 9) {
    strengthDesc.innerHTML = strengthDescs[8].stat;
  } else if (strengthPoints.value == 10) {
    strengthDesc.innerHTML = strengthDescs[9].stat;
  }
}
function determinePerceptionDesc() {
  const perceptionDesc = document.getElementById("pStatDesc");
  if (perceptionPoints.value == 1) {
    perceptionDesc.innerHTML = perceptionDescs[0].stat;
  } else if (perceptionPoints.value == 2) {
    perceptionDesc.innerHTML = perceptionDescs[1].stat;
  } else if (perceptionPoints.value == 3) {
    perceptionDesc.innerHTML = perceptionDescs[2].stat;
  } else if (perceptionPoints.value == 4) {
    perceptionDesc.innerHTML = perceptionDescs[3].stat;
  } else if (perceptionPoints.value == 5) {
    perceptionDesc.innerHTML = perceptionDescs[4].stat;
  } else if (perceptionPoints.value == 6) {
    perceptionDesc.innerHTML = perceptionDescs[5].stat;
  } else if (perceptionPoints.value == 7) {
    perceptionDesc.innerHTML = perceptionDescs[6].stat;
  } else if (perceptionPoints.value == 8) {
    perceptionDesc.innerHTML = perceptionDescs[7].stat;
  } else if (perceptionPoints.value == 9) {
    perceptionDesc.innerHTML = perceptionDescs[8].stat;
  } else if (perceptionPoints.value == 10) {
    perceptionDesc.innerHTML = perceptionDescs[9].stat;
  }
}
function determineEnduranceDesc() {
  const enduranceDesc = document.getElementById("eStatDesc");
  if (endurancePoints.value == 1) {
    enduranceDesc.innerHTML = enduranceDescs[0].stat;
  } else if (endurancePoints.value == 2) {
    enduranceDesc.innerHTML = enduranceDescs[1].stat;
  } else if (endurancePoints.value == 3) {
    enduranceDesc.innerHTML = enduranceDescs[2].stat;
  } else if (endurancePoints.value == 4) {
    enduranceDesc.innerHTML = enduranceDescs[3].stat;
  } else if (endurancePoints.value == 5) {
    enduranceDesc.innerHTML = enduranceDescs[4].stat;
  } else if (endurancePoints.value == 6) {
    enduranceDesc.innerHTML = enduranceDescs[5].stat;
  } else if (endurancePoints.value == 7) {
    enduranceDesc.innerHTML = enduranceDescs[6].stat;
  } else if (endurancePoints.value == 8) {
    enduranceDesc.innerHTML = enduranceDescs[7].stat;
  } else if (endurancePoints.value == 9) {
    enduranceDesc.innerHTML = enduranceDescs[8].stat;
  } else if (endurancePoints.value == 10) {
    enduranceDesc.innerHTML = enduranceDescs[9].stat;
  }
}

//
//
//

const allStrengthPerks = document.querySelectorAll(".strength-perk");
const allPerceptionPerks = document.querySelectorAll(".perception-perk");
const allEndurancePerks = document.querySelectorAll(".endurance-perk");
var statPerksI;

// This will hold the innerHTML for each statPerk
storeStatPerks();
function storeStatPerks() {
  //* Strength Perks
  allStrengthPerks[0].innerHTML = strengthPerks[0].pName;
  allStrengthPerks[1].innerHTML = strengthPerks[1].pName;
  allStrengthPerks[2].innerHTML = strengthPerks[2].pName;
  allStrengthPerks[3].innerHTML = strengthPerks[3].pName;
  allStrengthPerks[4].innerHTML = strengthPerks[4].pName;
  allStrengthPerks[5].innerHTML = strengthPerks[5].pName;
  allStrengthPerks[6].innerHTML = strengthPerks[6].pName;
  allStrengthPerks[7].innerHTML = strengthPerks[7].pName;
  allStrengthPerks[8].innerHTML = strengthPerks[8].pName;
  allStrengthPerks[9].innerHTML = strengthPerks[9].pName;

  //* Perception Perks
  allPerceptionPerks[0].innerHTML = perceptionPerks[0].pName;
  allPerceptionPerks[1].innerHTML = perceptionPerks[1].pName;
  allPerceptionPerks[2].innerHTML = perceptionPerks[2].pName;
  allPerceptionPerks[3].innerHTML = perceptionPerks[3].pName;
  allPerceptionPerks[4].innerHTML = perceptionPerks[4].pName;
  allPerceptionPerks[5].innerHTML = perceptionPerks[5].pName;
  allPerceptionPerks[6].innerHTML = perceptionPerks[6].pName;
  allPerceptionPerks[7].innerHTML = perceptionPerks[7].pName;
  allPerceptionPerks[8].innerHTML = perceptionPerks[8].pName;
  allPerceptionPerks[9].innerHTML = perceptionPerks[9].pName;

  //* Endurance Perks
  allEndurancePerks[0].innerHTML = endurancePerks[0].pName;
  allEndurancePerks[1].innerHTML = endurancePerks[1].pName;
  allEndurancePerks[2].innerHTML = endurancePerks[2].pName;
  allEndurancePerks[3].innerHTML = endurancePerks[3].pName;
  allEndurancePerks[4].innerHTML = endurancePerks[4].pName;
  allEndurancePerks[5].innerHTML = endurancePerks[5].pName;
  allEndurancePerks[6].innerHTML = endurancePerks[6].pName;
  allEndurancePerks[7].innerHTML = endurancePerks[7].pName;
  allEndurancePerks[8].innerHTML = endurancePerks[8].pName;
  allEndurancePerks[9].innerHTML = endurancePerks[9].pName;
}

hideStrengthPerks();
function hideStrengthPerks() {
  for (statPerksI = 0; statPerksI < allStrengthPerks.length; statPerksI++) {
    allStrengthPerks[statPerksI].style.display = "none";
  }
}
hidePerceptionPerks();
function hidePerceptionPerks() {
  for (statPerksI = 0; statPerksI < allPerceptionPerks.length; statPerksI++) {
    allPerceptionPerks[statPerksI].style.display = "none";
  }
}
hideEndurancePerks();
function hideEndurancePerks() {
  for (statPerksI = 0; statPerksI < allEndurancePerks.length; statPerksI++) {
    allEndurancePerks[statPerksI].style.display = "none";
  }
}

// Displays the perks based on the stat points
determineAllStatPerks();
function determineAllStatPerks() {
  determineStrengthPerks();
  determinePerceptionPerks();
  determineEndurancePerks();
}

function determineStrengthPerks() {
  switch (true) {
    case strengthPoints.value == 1:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      break;
    case strengthPoints.value == 2:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      break;
    case strengthPoints.value == 3:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      break;
    case strengthPoints.value == 4:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      allStrengthPerks[3].style.display = "block";
      break;
    case strengthPoints.value == 5:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      allStrengthPerks[3].style.display = "block";
      allStrengthPerks[4].style.display = "block";
      break;
    case strengthPoints.value == 6:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      allStrengthPerks[3].style.display = "block";
      allStrengthPerks[4].style.display = "block";
      allStrengthPerks[5].style.display = "block";
      break;
    case strengthPoints.value == 7:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      allStrengthPerks[3].style.display = "block";
      allStrengthPerks[4].style.display = "block";
      allStrengthPerks[5].style.display = "block";
      allStrengthPerks[6].style.display = "block";
      break;
    case strengthPoints.value == 8:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      allStrengthPerks[3].style.display = "block";
      allStrengthPerks[4].style.display = "block";
      allStrengthPerks[5].style.display = "block";
      allStrengthPerks[6].style.display = "block";
      allStrengthPerks[7].style.display = "block";
      break;
    case strengthPoints.value == 9:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      allStrengthPerks[3].style.display = "block";
      allStrengthPerks[4].style.display = "block";
      allStrengthPerks[5].style.display = "block";
      allStrengthPerks[6].style.display = "block";
      allStrengthPerks[7].style.display = "block";
      allStrengthPerks[8].style.display = "block";
      break;
    case strengthPoints.value == 10:
      hideStrengthPerks();
      allStrengthPerks[0].style.display = "block";
      allStrengthPerks[1].style.display = "block";
      allStrengthPerks[2].style.display = "block";
      allStrengthPerks[3].style.display = "block";
      allStrengthPerks[4].style.display = "block";
      allStrengthPerks[5].style.display = "block";
      allStrengthPerks[6].style.display = "block";
      allStrengthPerks[7].style.display = "block";
      allStrengthPerks[8].style.display = "block";
      allStrengthPerks[9].style.display = "block";
      break;
  }
}
function determinePerceptionPerks() {
  switch (true) {
    case perceptionPoints.value == 1:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      break;
    case perceptionPoints.value == 2:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      break;
    case perceptionPoints.value == 3:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      break;
    case perceptionPoints.value == 4:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      allPerceptionPerks[3].style.display = "block";
      break;
    case perceptionPoints.value == 5:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      allPerceptionPerks[3].style.display = "block";
      allPerceptionPerks[4].style.display = "block";
      break;
    case perceptionPoints.value == 6:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      allPerceptionPerks[3].style.display = "block";
      allPerceptionPerks[4].style.display = "block";
      allPerceptionPerks[5].style.display = "block";
      break;
    case perceptionPoints.value == 7:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      allPerceptionPerks[3].style.display = "block";
      allPerceptionPerks[4].style.display = "block";
      allPerceptionPerks[5].style.display = "block";
      allPerceptionPerks[6].style.display = "block";
      break;
    case perceptionPoints.value == 8:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      allPerceptionPerks[3].style.display = "block";
      allPerceptionPerks[4].style.display = "block";
      allPerceptionPerks[5].style.display = "block";
      allPerceptionPerks[6].style.display = "block";
      allPerceptionPerks[7].style.display = "block";
      break;
    case perceptionPoints.value == 9:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      allPerceptionPerks[3].style.display = "block";
      allPerceptionPerks[4].style.display = "block";
      allPerceptionPerks[5].style.display = "block";
      allPerceptionPerks[6].style.display = "block";
      allPerceptionPerks[7].style.display = "block";
      allPerceptionPerks[8].style.display = "block";
      break;
    case perceptionPoints.value == 10:
      hidePerceptionPerks();
      allPerceptionPerks[0].style.display = "block";
      allPerceptionPerks[1].style.display = "block";
      allPerceptionPerks[2].style.display = "block";
      allPerceptionPerks[3].style.display = "block";
      allPerceptionPerks[4].style.display = "block";
      allPerceptionPerks[5].style.display = "block";
      allPerceptionPerks[6].style.display = "block";
      allPerceptionPerks[7].style.display = "block";
      allPerceptionPerks[8].style.display = "block";
      allPerceptionPerks[9].style.display = "block";
      break;
  }
}
function determineEndurancePerks() {
  switch (true) {
    case endurancePoints.value == 1:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      break;
    case endurancePoints.value == 2:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      break;
    case endurancePoints.value == 3:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      break;
    case endurancePoints.value == 4:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      allEndurancePerks[3].style.display = "block";
      break;
    case endurancePoints.value == 5:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      allEndurancePerks[3].style.display = "block";
      allEndurancePerks[4].style.display = "block";
      break;
    case endurancePoints.value == 6:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      allEndurancePerks[3].style.display = "block";
      allEndurancePerks[4].style.display = "block";
      allEndurancePerks[5].style.display = "block";
      break;
    case endurancePoints.value == 7:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      allEndurancePerks[3].style.display = "block";
      allEndurancePerks[4].style.display = "block";
      allEndurancePerks[5].style.display = "block";
      allEndurancePerks[6].style.display = "block";
      break;
    case endurancePoints.value == 8:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      allEndurancePerks[3].style.display = "block";
      allEndurancePerks[4].style.display = "block";
      allEndurancePerks[5].style.display = "block";
      allEndurancePerks[6].style.display = "block";
      allEndurancePerks[7].style.display = "block";
      break;
    case endurancePoints.value == 9:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      allEndurancePerks[3].style.display = "block";
      allEndurancePerks[4].style.display = "block";
      allEndurancePerks[5].style.display = "block";
      allEndurancePerks[6].style.display = "block";
      allEndurancePerks[7].style.display = "block";
      allEndurancePerks[8].style.display = "block";
      break;
    case endurancePoints.value == 10:
      hideEndurancePerks();
      allEndurancePerks[0].style.display = "block";
      allEndurancePerks[1].style.display = "block";
      allEndurancePerks[2].style.display = "block";
      allEndurancePerks[3].style.display = "block";
      allEndurancePerks[4].style.display = "block";
      allEndurancePerks[5].style.display = "block";
      allEndurancePerks[6].style.display = "block";
      allEndurancePerks[7].style.display = "block";
      allEndurancePerks[8].style.display = "block";
      allEndurancePerks[9].style.display = "block";
      break;
  }
}
