/* This script is the main script for this project */

var startingPoints = 28; //* The starting points given (based on Fallout 4)
const currentStatPoints = document.getElementById("currentStatPoints");
var incBtnI;
const allIncBtns = document.getElementsByClassName("inc-btn");
const strengthInc = document.getElementById("sInc");
const perceptionInc = document.getElementById("pInc");
const enduranceInc = document.getElementById("eInc");
const charismaInc = document.getElementById("cInc");
const intelligenceInc = document.getElementById("iInc");
const agilityInc = document.getElementById("aInc");
const luckInc = document.getElementById("lInc");

function unDisableIncrements() {
  for (incBtnI = 0; incBtnI < allIncBtns.length; incBtnI++) {
    allIncBtns[incBtnI].disabled = false;
  }
}

//
//
//

//? Strength
const strengthPoints = document.getElementById("strengthTotal");
strengthPoints.value = 1;

document.getElementById("sInc").addEventListener("click", () => {
  currentStatPoints.value--;
  strengthPoints.value++;
  preventStrength();
});
document.getElementById("sDec").addEventListener("click", () => {
  currentStatPoints.value++;
  strengthPoints.value--;
  preventStrength();
});

// Prevents going above 10 and below 1
function preventStrength() {
  if (strengthPoints.value >= 10) {
    strengthPoints.value = 10;
    updateCurrentStatPoints();
    strengthInc.disabled = true;
  } else if (strengthPoints.value <= 1) {
    strengthPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Perception
const perceptionPoints = document.getElementById("perceptionTotal");
perceptionPoints.value = 1;

document.getElementById("pInc").addEventListener("click", () => {
  currentStatPoints.value--;
  perceptionPoints.value++;
  preventPerception();
});
document.getElementById("pDec").addEventListener("click", () => {
  currentStatPoints.value++;
  perceptionPoints.value--;
  preventPerception();
});

// Prevents going above 10 and below 1
function preventPerception() {
  if (perceptionPoints.value >= 10) {
    perceptionPoints.value = 10;
    updateCurrentStatPoints();
  } else if (perceptionPoints.value <= 1) {
    perceptionPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Endurance
const endurancePoints = document.getElementById("enduranceTotal");
endurancePoints.value = 1;

document.getElementById("eInc").addEventListener("click", () => {
  currentStatPoints.value--;
  endurancePoints.value++;
  preventEndurance();
});
document.getElementById("eDec").addEventListener("click", () => {
  currentStatPoints.value++;
  endurancePoints.value--;
  preventEndurance();
});

// Prevents going above 10 and below 1
function preventEndurance() {
  if (endurancePoints.value >= 10) {
    endurancePoints.value = 10;
    updateCurrentStatPoints();
  } else if (endurancePoints.value <= 1) {
    endurancePoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Charisma
const charismaPoints = document.getElementById("charismaTotal");
charismaPoints.value = 1;

document.getElementById("cInc").addEventListener("click", () => {
  currentStatPoints.value--;
  charismaPoints.value++;
  preventCharisma();
});
document.getElementById("cDec").addEventListener("click", () => {
  currentStatPoints.value++;
  charismaPoints.value--;
  preventCharisma();
});

// Prevents going above 10 and below 1
function preventCharisma() {
  if (charismaPoints.value >= 10) {
    charismaPoints.value = 10;
    updateCurrentStatPoints();
  } else if (charismaPoints.value <= 1) {
    charismaPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Intelligence
const intelligencePoints = document.getElementById("intelligenceTotal");
intelligencePoints.value = 1;

document.getElementById("iInc").addEventListener("click", () => {
  currentStatPoints.value--;
  intelligencePoints.value++;
  preventIntelligence();
});
document.getElementById("iDec").addEventListener("click", () => {
  currentStatPoints.value++;
  intelligencePoints.value--;
  preventIntelligence();
});

function preventIntelligence() {
  if (intelligencePoints.value >= 10) {
    intelligencePoints.value = 10;
    updateCurrentStatPoints();
  } else if (intelligencePoints.value <= 1) {
    intelligencePoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Agility
const agilityPoints = document.getElementById("agilityTotal");
agilityPoints.value = 1;

document.getElementById("aInc").addEventListener("click", () => {
  currentStatPoints.value--;
  agilityPoints.value++;
  preventAgility();
});
document.getElementById("aDec").addEventListener("click", () => {
  currentStatPoints.value++;
  agilityPoints.value--;
  preventAgility();
});

function preventAgility() {
  if (agilityPoints.value >= 10) {
    agilityPoints.value = 10;
    updateCurrentStatPoints();
  } else if (agilityPoints.value <= 1) {
    agilityPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Luck
const luckPoints = document.getElementById("luckTotal");
luckPoints.value = 1;

document.getElementById("lInc").addEventListener("click", () => {
  currentStatPoints.value--;
  luckPoints.value++;
  preventLuck();
});
document.getElementById("lDec").addEventListener("click", () => {
  currentStatPoints.value++;
  luckPoints.value--;
  preventLuck();
});

function preventLuck() {
  if (luckPoints.value >= 10) {
    luckPoints.value = 10;
    updateCurrentStatPoints();
  } else if (luckPoints.value <= 1) {
    luckPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

// This will update the pointsLeft to match how many points the user inputted with each stat type
updateCurrentStatPoints();
function updateCurrentStatPoints() {
  currentStatPoints.value =
    startingPoints -
    strengthPoints.value -
    perceptionPoints.value -
    endurancePoints.value -
    charismaPoints.value -
    intelligencePoints.value -
    agilityPoints.value -
    luckPoints.value;
}

// This will prevent the pointsLeft from going past 0
function preventZeroPointsLeft() {
  if (currentStatPoints.value == 0) {
    strengthInc.disabled = true;
    perceptionInc.disabled = true;
    enduranceInc.disabled = true;
    charismaInc.disabled = true;
    intelligenceInc.disabled = true;
    agilityInc.disabled = true;
    luckInc.disabled = true;
  } else {
    unDisableIncrements();
  }
}

console.log(`Current Points Left: ` + currentStatPoints.value);

//
//
//
//
//
//

// Display Current stat point description

//
//
//

// Display Perks that go along with current stat type points

//
//
//
