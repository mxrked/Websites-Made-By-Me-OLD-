/* This will store all of the different perks the user can gain */

//* Strength Desc
const strengthDescText = [
  {
    stat: "Wet Noodle",
  },
  {
    stat: "Beached Jellyfish",
  },
  {
    stat: "Doughy Baby",
  },
  {
    stat: "Lightweight",
  },
  {
    stat: "Average Joe",
  },
  {
    stat: "Barrel Chested",
  },
  {
    stat: "Beach Bully",
  },
  {
    stat: "Circus Strongman",
  },
  {
    stat: "Doomsday Pecs",
  },
  {
    stat: "Hercule's Bigger Cousin",
  },
];

//* Strength Perks
const strengthPerks = [
  {
    perkName: "Iron Fist",
  },
  {
    perkName: "Big Leagues",
  },
  {
    perkName: "Armorer",
  },
  {
    perkName: "Blacksmith",
  },
  {
    perkName: "Heavy Gunner",
  },
  {
    perkName: "Strong Back",
  },
  {
    perkName: "Steady Aim",
  },
  {
    perkName: "Basher",
  },
  {
    perkName: "Rooted",
  },
  {
    perkName: "Pain Train",
  },
];
