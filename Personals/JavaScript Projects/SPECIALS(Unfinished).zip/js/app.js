/* This script is the main script for this project */

var startingPoints = 28; //* The starting points given (based on Fallout 4)
const currentStatPoints = document.getElementById("currentStatPoints");
var incBtnI;
const allIncBtns = document.getElementsByClassName("inc-btn");

function unDisableIncrements() {
  for (incBtnI = 0; incBtnI < allIncBtns.length; incBtnI++) {
    allIncBtns[incBtnI].disabled = false;
  }
}

//
//
//

//? Strength
const strengthPoints = document.getElementById("strengthTotal");
strengthPoints.value = 1;

document.getElementById("sInc").addEventListener("click", () => {
  currentStatPoints.value--;
  strengthPoints.value++;
  preventStrength();
});
document.getElementById("sDec").addEventListener("click", () => {
  currentStatPoints.value++;
  strengthPoints.value--;
  preventStrength();
});

// Prevents going above 10 and below 1
function preventStrength() {
  if (strengthPoints.value >= 10) {
    strengthPoints.value = 10;
    updateCurrentStatPoints();
    strengthInc.disabled = true;
  } else if (strengthPoints.value <= 1) {
    strengthPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Perception
const perceptionPoints = document.getElementById("perceptionTotal");
perceptionPoints.value = 1;

document.getElementById("pInc").addEventListener("click", () => {
  currentStatPoints.value--;
  perceptionPoints.value++;
  preventPerception();
});
document.getElementById("pDec").addEventListener("click", () => {
  currentStatPoints.value++;
  perceptionPoints.value--;
  preventPerception();
});

// Prevents going above 10 and below 1
function preventPerception() {
  if (perceptionPoints.value >= 10) {
    perceptionPoints.value = 10;
    updateCurrentStatPoints();
  } else if (perceptionPoints.value <= 1) {
    perceptionPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Endurance
const endurancePoints = document.getElementById("enduranceTotal");
endurancePoints.value = 1;

document.getElementById("eInc").addEventListener("click", () => {
  currentStatPoints.value--;
  endurancePoints.value++;
  preventEndurance();
});
document.getElementById("eDec").addEventListener("click", () => {
  currentStatPoints.value++;
  endurancePoints.value--;
  preventEndurance();
});

// Prevents going above 10 and below 1
function preventEndurance() {
  if (endurancePoints.value >= 10) {
    endurancePoints.value = 10;
    updateCurrentStatPoints();
  } else if (endurancePoints.value <= 1) {
    endurancePoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Charisma
const charismaPoints = document.getElementById("charismaTotal");
charismaPoints.value = 1;

document.getElementById("cInc").addEventListener("click", () => {
  currentStatPoints.value--;
  charismaPoints.value++;
  preventCharisma();
});
document.getElementById("cDec").addEventListener("click", () => {
  currentStatPoints.value++;
  charismaPoints.value--;
  preventCharisma();
});

// Prevents going above 10 and below 1
function preventCharisma() {
  if (charismaPoints.value >= 10) {
    charismaPoints.value = 10;
    updateCurrentStatPoints();
  } else if (charismaPoints.value <= 1) {
    charismaPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Intelligence
const intelligencePoints = document.getElementById("intelligenceTotal");
intelligencePoints.value = 1;

document.getElementById("iInc").addEventListener("click", () => {
  currentStatPoints.value--;
  intelligencePoints.value++;
  preventIntelligence();
});
document.getElementById("iDec").addEventListener("click", () => {
  currentStatPoints.value++;
  intelligencePoints.value--;
  preventIntelligence();
});

function preventIntelligence() {
  if (intelligencePoints.value >= 10) {
    intelligencePoints.value = 10;
    updateCurrentStatPoints();
  } else if (intelligencePoints.value <= 1) {
    intelligencePoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Agility
const agilityPoints = document.getElementById("agilityTotal");
agilityPoints.value = 1;

document.getElementById("aInc").addEventListener("click", () => {
  currentStatPoints.value--;
  agilityPoints.value++;
  preventAgility();
});
document.getElementById("aDec").addEventListener("click", () => {
  currentStatPoints.value++;
  agilityPoints.value--;
  preventAgility();
});

function preventAgility() {
  if (agilityPoints.value >= 10) {
    agilityPoints.value = 10;
    updateCurrentStatPoints();
  } else if (agilityPoints.value <= 1) {
    agilityPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

//
//
//

//? Luck
const luckPoints = document.getElementById("luckTotal");
luckPoints.value = 1;

document.getElementById("lInc").addEventListener("click", () => {
  currentStatPoints.value--;
  luckPoints.value++;
  preventLuck();
});
document.getElementById("lDec").addEventListener("click", () => {
  currentStatPoints.value++;
  luckPoints.value--;
  preventLuck();
});

function preventLuck() {
  if (luckPoints.value >= 10) {
    luckPoints.value = 10;
    updateCurrentStatPoints();
  } else if (luckPoints.value <= 1) {
    luckPoints.value = 1;
    updateCurrentStatPoints();
  }

  preventZeroPointsLeft();
  console.log(`Current Points Left: ` + currentStatPoints.value);
}

// This will update the pointsLeft to match how many points the user inputted with each stat type
updateCurrentStatPoints();
function updateCurrentStatPoints() {
  currentStatPoints.value =
    startingPoints -
    strengthPoints.value -
    perceptionPoints.value -
    endurancePoints.value -
    charismaPoints.value -
    intelligencePoints.value -
    agilityPoints.value -
    luckPoints.value;
}

// This will prevent the pointsLeft from going past 0
const strengthInc = document.getElementById("sInc");
const perceptionInc = document.getElementById("pInc");
const enduranceInc = document.getElementById("eInc");
const charismaInc = document.getElementById("cInc");
const intelligenceInc = document.getElementById("iInc");
const agilityInc = document.getElementById("aInc");
const luckInc = document.getElementById("lInc");
function preventZeroPointsLeft() {
  if (currentStatPoints.value == 0) {
    strengthInc.disabled = true;
    perceptionInc.disabled = true;
    enduranceInc.disabled = true;
    charismaInc.disabled = true;
    intelligenceInc.disabled = true;
    agilityInc.disabled = true;
    luckInc.disabled = true;
  } else {
    unDisableIncrements();
  }
}

console.log(`Current Points Left: ` + currentStatPoints.value);

//
//
//
//
//
//

// Display Current stat point description
function determineStrengthDesc() {
  const strengthDesc = document.getElementById("sD");
  if (strengthPoints.value == 1) {
    strengthDesc.innerHTML = strengthDescText[0].stat;
  } else if (strengthPoints.value == 2) {
    strengthDesc.innerHTML = strengthDescText[1].stat;
  } else if (strengthPoints.value == 3) {
    strengthDesc.innerHTML = strengthDescText[2].stat;
  } else if (strengthPoints.value == 4) {
    strengthDesc.innerHTML = strengthDescText[3].stat;
  } else if (strengthPoints.value == 5) {
    strengthDesc.innerHTML = strengthDescText[4].stat;
  } else if (strengthPoints.value == 6) {
    strengthDesc.innerHTML = strengthDescText[5].stat;
  } else if (strengthPoints.value == 7) {
    strengthDesc.innerHTML = strengthDescText[6].stat;
  } else if (strengthPoints.value == 8) {
    strengthDesc.innerHTML = strengthDescText[7].stat;
  } else if (strengthPoints.value == 9) {
    strengthDesc.innerHTML = strengthDescText[8].stat;
  } else if (strengthPoints.value == 10) {
    strengthDesc.innerHTML = strengthDescText[9].stat;
  }
}

//
//
//

// Display Perks that go along with current stat type points

//* This will hide all the perks text
function hideStrengthPerks() {
  const strengthPerksHolder_Classes = document.getElementsByClassName("sP");
  var sPI;

  for (sPI = 0; sPI < strengthPerksHolder_Classes.length; sPI++) {
    strengthPerksHolder_Classes[sPI].innerHTML = "";
  }
}

//* This will determine what perk text to display based on a stats value
function determineStrengthPerks() {
  const strengthPerksHolder = document.querySelectorAll(
    "#strengthPerksHolder li"
  );
  if (strengthPoints.value == 1) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
  } else if (strengthPoints.value == 2) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
  } else if (strengthPoints.value == 3) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
  } else if (strengthPoints.value == 4) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
    strengthPerksHolder[3].innerHTML = strengthPerks[3].perkName;
  } else if (strengthPoints.value == 5) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
    strengthPerksHolder[3].innerHTML = strengthPerks[3].perkName;
    strengthPerksHolder[4].innerHTML = strengthPerks[4].perkName;
  } else if (strengthPoints.value == 6) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
    strengthPerksHolder[3].innerHTML = strengthPerks[3].perkName;
    strengthPerksHolder[4].innerHTML = strengthPerks[4].perkName;
    strengthPerksHolder[5].innerHTML = strengthPerks[5].perkName;
  } else if (strengthPoints.value == 7) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
    strengthPerksHolder[3].innerHTML = strengthPerks[3].perkName;
    strengthPerksHolder[4].innerHTML = strengthPerks[4].perkName;
    strengthPerksHolder[5].innerHTML = strengthPerks[5].perkName;
    strengthPerksHolder[6].innerHTML = strengthPerks[6].perkName;
  } else if (strengthPoints.value == 8) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
    strengthPerksHolder[3].innerHTML = strengthPerks[3].perkName;
    strengthPerksHolder[4].innerHTML = strengthPerks[4].perkName;
    strengthPerksHolder[5].innerHTML = strengthPerks[5].perkName;
    strengthPerksHolder[6].innerHTML = strengthPerks[6].perkName;
    strengthPerksHolder[7].innerHTML = strengthPerks[7].perkName;
  } else if (strengthPoints.value == 9) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
    strengthPerksHolder[3].innerHTML = strengthPerks[3].perkName;
    strengthPerksHolder[4].innerHTML = strengthPerks[4].perkName;
    strengthPerksHolder[5].innerHTML = strengthPerks[5].perkName;
    strengthPerksHolder[6].innerHTML = strengthPerks[6].perkName;
    strengthPerksHolder[7].innerHTML = strengthPerks[7].perkName;
    strengthPerksHolder[8].innerHTML = strengthPerks[8].perkName;
  } else if (strengthPoints.value == 10) {
    hideStrengthPerks();
    strengthPerksHolder[0].innerHTML = strengthPerks[0].perkName;
    strengthPerksHolder[1].innerHTML = strengthPerks[1].perkName;
    strengthPerksHolder[2].innerHTML = strengthPerks[2].perkName;
    strengthPerksHolder[3].innerHTML = strengthPerks[3].perkName;
    strengthPerksHolder[4].innerHTML = strengthPerks[4].perkName;
    strengthPerksHolder[5].innerHTML = strengthPerks[5].perkName;
    strengthPerksHolder[6].innerHTML = strengthPerks[6].perkName;
    strengthPerksHolder[7].innerHTML = strengthPerks[7].perkName;
    strengthPerksHolder[8].innerHTML = strengthPerks[8].perkName;
    strengthPerksHolder[9].innerHTML = strengthPerks[9].perkName;
  }
}

//
//
//

// Display Full Results when user presses Go Btn

const resultsBtn = document.getElementById("displayResults");
resultsBtn.addEventListener("click", () => {
  determineStrengthDesc();
  determineStrengthPerks();
});

//
//
//
