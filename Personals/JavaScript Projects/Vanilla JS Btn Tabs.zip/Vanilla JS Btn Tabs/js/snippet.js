/*

    This script is for the Vanilla Js Btn Tabs

*/

const ALL_TAB_TOGGLERS = document.querySelectorAll(".tab-toggler");
const ALL_TAB_CONTENTS = document.querySelectorAll(".tab-content");
var tab1Clicked = 1; // Set by default (To show tab 1)
var tab2Clicked = 0;
var tab3Clicked = 0;

deactivateTabs(); // Toggles the deactive class to each of the tab contents

function deactivateTabs() {
  ALL_TAB_CONTENTS.forEach((tab) => {
    tab.classList.toggle("deactive");
  });
}

checkTogglerState();

function checkTogglerState() {
  //? Tab 1
  switch (tab1Clicked) {
    case 1:
      showTC1();

      ALL_TAB_TOGGLERS[0].style.background = "blue";

      setTimeout(() => {
        ALL_TAB_CONTENTS[0].classList.remove("deactive");
      }, 500);

      break;

    case 0:
      hideTC1();

      ALL_TAB_TOGGLERS[0].style.background = "black";
      break;
  }

  //! Tab 2
  switch (tab2Clicked) {
    case 1:
      showTC2();

      ALL_TAB_TOGGLERS[1].style.background = "red";

      setTimeout(() => {
        ALL_TAB_CONTENTS[1].classList.remove("deactive");
      }, 500);

      break;

    case 0:
      hideTC2();

      ALL_TAB_TOGGLERS[1].style.background = "black";
      break;
  }

  //* Tab 3
  switch (tab3Clicked) {
    case 1:
      showTC3();

      ALL_TAB_TOGGLERS[2].style.background = "green";

      setTimeout(() => {
        ALL_TAB_CONTENTS[2].classList.remove("deactive");
      }, 500);

      break;

    case 0:
      hideTC3();

      ALL_TAB_TOGGLERS[2].style.background = "black";
      break;
  }
}

// Shows

function showTC1() {
  ALL_TAB_CONTENTS[0].style.display = "block";
}

function showTC2() {
  ALL_TAB_CONTENTS[1].style.display = "block";
}

function showTC3() {
  ALL_TAB_CONTENTS[2].style.display = "block";
}

// Hides

function hideTC1() {
  ALL_TAB_CONTENTS[0].style.display = "none";
}

function hideTC2() {
  ALL_TAB_CONTENTS[1].style.display = "none";
}

function hideTC3() {
  ALL_TAB_CONTENTS[2].style.display = "none";
}

// Toggler Events

// Toggler 1
ALL_TAB_TOGGLERS[0].addEventListener("click", () => {
  tab1Clicked = 1;
  tab2Clicked = 0;
  tab3Clicked = 0;

  checkTogglerState();
});

ALL_TAB_TOGGLERS[0].addEventListener("mouseover", () => {
  ALL_TAB_TOGGLERS[0].style.background = "blue";
});

// Toggler 2
ALL_TAB_TOGGLERS[1].addEventListener("click", () => {
  tab1Clicked = 0;
  tab2Clicked = 1;
  tab3Clicked = 0;

  checkTogglerState();
});

ALL_TAB_TOGGLERS[1].addEventListener("mouseover", () => {
  ALL_TAB_TOGGLERS[1].style.background = "red";
});

// Toggler 3
ALL_TAB_TOGGLERS[2].addEventListener("click", () => {
  tab1Clicked = 0;
  tab2Clicked = 0;
  tab3Clicked = 1;

  checkTogglerState();
});

ALL_TAB_TOGGLERS[2].addEventListener("mouseover", () => {
  ALL_TAB_TOGGLERS[2].style.background = "green";
});

// FIXES hover issues
ALL_TAB_TOGGLERS.forEach((toggler) => {
  checkTogglerState();

  toggler.addEventListener("mouseleave", () => {
    toggler.style.background = "black";

    if (tab1Clicked == 1) {
      ALL_TAB_TOGGLERS[0].style.background = "blue";
    } else if (tab2Clicked == 1) {
      ALL_TAB_TOGGLERS[1].style.background = "red";
    } else if (tab3Clicked == 1) {
      ALL_TAB_TOGGLERS[2].style.background = "green";
    }
  });
});
