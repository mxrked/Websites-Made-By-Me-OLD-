/*

    This script is for mainly the mainItems and when the user clicks on them.


        !USES: mainModals.js

*/



    const ALL_MAIN_ITEMS_SET = [

        item1 = document.getElementById('item1'),
        item2 = document.getElementById('item2')

    ]

    


    ALL_MAIN_ITEMS_SET[0].addEventListener('click', () => {

        eventNum = 0;

        hideMainModals();

        ALL_MAIN_MODALS_SET[0].style.display = 'flex';

        setTimeout(() => {

            ALL_MAIN_MODALS_SET[0].classList.remove('deactive');

        }, 100);
        
    });

    ALL_MAIN_ITEMS_SET[1].addEventListener('click', () => {

        eventNum = 1;

        hideMainModals();

        ALL_MAIN_MODALS_SET[1].style.display = 'flex';

        setTimeout(() => {

            ALL_MAIN_MODALS_SET[1].classList.remove('deactive');

        }, 100);
        
    });
   
    