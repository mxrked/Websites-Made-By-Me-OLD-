/*

    This script is for mainly the mainModals and how they function


        !USES: mainItems.js

*/


    var eventNum;
    const ALL_MAIN_MODALS = document.querySelectorAll('.main-modal');
    const ALL_MAIN_MODALS_SET = [

        modal1 = document.getElementById('modal1'),
        modal2 = document.getElementById('modal2')

    ]
    const ALL_MAIN_MODAL_CLOSERS = document.querySelectorAll('.main-modal-closer');



        function hideMainModals() {

            for (i = 0; i < ALL_MAIN_MODALS.length; i++) {
                
                ALL_MAIN_MODALS[i].style.display = 'none';
                ALL_MAIN_MODALS[i].classList.toggle('deactive');

            }

        }




        toggleModalTransitions();

            function toggleModalTransitions() {

                ALL_MAIN_MODALS.forEach((modal) => {

                    modal.classList.toggle('page-transition');

                });

            }




            for (const closer of ALL_MAIN_MODAL_CLOSERS) {

                closer.addEventListener('click', hideMainModals);

            }



        window.onclick = function(event) {

            
            if (event.target == ALL_MAIN_MODALS_SET[0]) {

                hideMainModals();

            } else if (event.target == ALL_MAIN_MODALS_SET[1]) {

                hideMainModals();

            }
           

    }
    

    

    