/*

    This script is for the main app

*/

// prevents user from using tab btn (this will mess up the search list)
function tabBtnManip(state) {
  document.onkeydown = function (e) {
    if (e.key == "Tab") {
      return state;
    }
  };
}
tabBtnManip(false);

var sFI;
const sFInput = document.getElementById("nukaInput");
const sFSearch = document.getElementById("nukaSubmit");
const sFResultsHolder = document.getElementById("nukaListHolder");
const sFResults = document.getElementById("nukaList");

sFResultsHolder.classList.toggle("deactive");
sFResults.classList.toggle("deactive");

// determines if the user clicks on the input or clicks off of it
var sFInputClicked;
function sFResultsManip(state) {
  if (state == "show") {
    sFInputClicked = true;
    sFResultsHolder.classList.remove("deactive");
    sFResults.classList.remove("deactive");
  } else if (state == "hide") {
    sFInputClicked = false;
    sFResultsHolder.classList.toggle("deactive");
    sFResults.classList.toggle("deactive");
  }
}

sFInput.addEventListener("click", () => {
  sFResultsManip("show");
});
sFInput.addEventListener("blur", () => {
  sFResultsManip("hide");
});

// checking what the user types in and determines what they may be searching for
sFInput.addEventListener("keyup", checkSFInput);
function checkSFInput() {
  let sFFilter;
  sFFilter = sFInput.value.toUpperCase();

  const sFResult = sFResults.getElementsByTagName("li");
  let sFResultLink;

  for (sFI = 0; sFI < sFResult.length; sFI++) {
    sFResultLink = sFResult[sFI].getElementsByTagName("a")[0];
    const sFResultTxt = sFResultLink.textContent || sFResultLink.innerText;

    if (sFResultTxt.toUpperCase().indexOf(sFFilter) > -1) {
      sFResult[sFI].style.display = "block";
    } else {
      sFResult[sFI].style.display = "none";
    }
  }
}

// this will be used to show what link the user clicked into the console

// this will be used to hide all of the other cola flavors and display one specific flavor
const colaTypes = document.querySelectorAll(".cola-type");
function displayColaType(type) {
  const allColaTypes = document.getElementsByClassName("cola-type");
  for (sFI = 0; sFI < allColaTypes.length; sFI++) {
    allColaTypes[sFI].style.display = "none";
  }

  setTimeout(() => {
    type.style.display = "block";
  }, 100);

  /*console.log(type);*/
}

const allSR = document.querySelectorAll(".search-result");
allSR.forEach((sr) => {
  sr.addEventListener("click", () => {
    console.clear();
  });
});

allSR[0].addEventListener("click", () => {
  displayColaType(colaTypes[0]);
});
allSR[1].addEventListener("click", () => {
  displayColaType(colaTypes[1]);
});
allSR[2].addEventListener("click", () => {
  displayColaType(colaTypes[2]);
});
allSR[3].addEventListener("click", () => {
  displayColaType(colaTypes[3]);
});
allSR[4].addEventListener("click", () => {
  displayColaType(colaTypes[4]);
});
allSR[5].addEventListener("click", () => {
  displayColaType(colaTypes[5]);
});
allSR[6].addEventListener("click", () => {
  displayColaType(colaTypes[6]);
});
allSR[7].addEventListener("click", () => {
  displayColaType(colaTypes[7]);
});
allSR[8].addEventListener("click", () => {
  displayColaType(colaTypes[8]);
});
allSR[9].addEventListener("click", () => {
  displayColaType(colaTypes[9]);
});
allSR[10].addEventListener("click", () => {
  displayColaType(colaTypes[10]);
});
allSR[11].addEventListener("click", () => {
  displayColaType(colaTypes[11]);
});
allSR[12].addEventListener("click", () => {
  displayColaType(colaTypes[12]);
});
allSR[13].addEventListener("click", () => {
  displayColaType(colaTypes[13]);
});
allSR[14].addEventListener("click", () => {
  displayColaType(colaTypes[14]);
});
allSR[15].addEventListener("click", () => {
  displayColaType(colaTypes[15]);
});
allSR[16].addEventListener("click", () => {
  displayColaType(colaTypes[16]);
});
allSR[17].addEventListener("click", () => {
  displayColaType(colaTypes[17]);
});
allSR[18].addEventListener("click", () => {
  displayColaType(colaTypes[18]);
});
allSR[19].addEventListener("click", () => {
  displayColaType(colaTypes[19]);
});
allSR[20].addEventListener("click", () => {
  displayColaType(colaTypes[20]);
});
allSR[21].addEventListener("click", () => {
  displayColaType(colaTypes[21]);
});
allSR[22].addEventListener("click", () => {
  displayColaType(colaTypes[22]);
});
allSR[23].addEventListener("click", () => {
  displayColaType(colaTypes[23]);
});
allSR[24].addEventListener("click", () => {
  displayColaType(colaTypes[24]);
});
allSR[25].addEventListener("click", () => {
  displayColaType(colaTypes[25]);
});
allSR[26].addEventListener("click", () => {
  displayColaType(colaTypes[26]);
});
allSR[27].addEventListener("click", () => {
  displayColaType(colaTypes[27]);
});
allSR[28].addEventListener("click", () => {
  displayColaType(colaTypes[28]);
});

// this will be used to tell what the user types in and it will display the specific cola type
//! WARNING
// This may look ugly but it was the first thing that came to mind that would work.
// I tried to reduce the amount of code as much as possible with different variable and function shorteners.

function loggingResult(txt) {
  console.log(`${txt} was entered.`);
}

var sFValue;
var sFValueLowered;

// seperating the colas to 2 different functions to not make the grabSFInput do EVERYTHING
function brandFlavors() {
  sFValue = sFInput.value;
  sFValueLowered = sFValue.toLowerCase();

  if (sFValueLowered.indexOf("nuka cola") > -1) {
    loggingResult("Nuka Cola");
    displayColaType(colaTypes[0]);
  }

  if (sFValueLowered.indexOf("nuka cherry") > -1) {
    loggingResult("Nuka Cherry");
    displayColaType(colaTypes[1]);
  } else if (sFValueLowered.indexOf("cherry") > -1) {
    loggingResult("Nuka Cherry");
    displayColaType(colaTypes[1]);
  }

  if (sFValueLowered.indexOf("nuka dark") > -1) {
    loggingResult("Nuka Dark (Ignore above)");
    displayColaType(colaTypes[2]);
  } else if (sFValueLowered.indexOf("dark") > -1) {
    loggingResult("Nuka Dark");
    displayColaType(colaTypes[2]);
  }

  if (sFValueLowered.indexOf("nuka grape") > -1) {
    loggingResult("Nuka Grape");
    displayColaType(colaTypes[3]);
  } else if (sFValueLowered.indexOf("grape") > -1) {
    loggingResult("Nuka Grape");
    displayColaType(colaTypes[3]);
  }

  if (sFValueLowered.indexOf("nuka orange") > -1) {
    loggingResult("Nuka Orange");
    displayColaType(colaTypes[4]);
  } else if (sFValueLowered.indexOf("orange") > -1) {
    loggingResult("Nuka Orange");
    displayColaType(colaTypes[4]);
  }

  if (sFValueLowered.indexOf("nuka quantum") > -1) {
    loggingResult("Nuka Quantum");
    displayColaType(colaTypes[5]);
  } else if (sFValueLowered.indexOf("quantum") > -1) {
    loggingResult("Nuka Quantum");
    displayColaType(colaTypes[5]);
  }

  if (sFValueLowered.indexOf("nuka  quartz") > -1) {
    loggingResult("Nuka Quartz");
    displayColaType(colaTypes[6]);
  } else if (sFValueLowered.indexOf("quartz") > -1) {
    loggingResult("Nuka Quartz");
    displayColaType(colaTypes[6]);
  }

  if (sFValueLowered.indexOf("nuka victory") > -1) {
    loggingResult("Nuka Victory");
    displayColaType(colaTypes[7]);
  } else if (sFValueLowered.indexOf("victory") > -1) {
    loggingResult("Nuka Victory");
    displayColaType(colaTypes[7]);
  }

  if (sFValueLowered.indexOf("nuka wild") > -1) {
    loggingResult("Nuka Wild");
    displayColaType(colaTypes[8]);
  } else if (sFValueLowered.indexOf("wild") > -1) {
    loggingResult("Nuka Wild");
    displayColaType(colaTypes[8]);
  }
}
function mixerFlavors() {
  sFValue = sFInput.value;
  sFValueLowered = sFValue.toLowerCase();

  if (sFValueLowered.indexOf("newka cola") > -1) {
    loggingResult("Newka Cola");
    displayColaType(colaTypes[9]);
  } else if (sFValueLowered.indexOf("newka") > -1) {
    loggingResult("Newka Cola");
    displayColaType(colaTypes[9]);
  }

  if (sFValueLowered.indexOf("nuka berry") > -1) {
    loggingResult("Nuka Berry");
    displayColaType(colaTypes[10]);
  } else if (sFValueLowered.indexOf("berry") > -1) {
    loggingResult("Nuka Berry");
    displayColaType(colaTypes[10]);
  }

  if (sFValueLowered.indexOf("nuka bombdrop") > -1) {
    loggingResult("Nuka Bombdrop");
    displayColaType(colaTypes[11]);
  } else if (sFValueLowered.indexOf("bombdrop") > -1) {
    loggingResult("Nuka Bombdrop");
    displayColaType(colaTypes[11]);
  }

  if (sFValueLowered.indexOf("nuka buzz") > -1) {
    loggingResult("Nuka Buzz");
    displayColaType(colaTypes[12]);
  } else if (sFValueLowered.indexOf("buzz") > -1) {
    loggingResult("Nuka Buzz");
    displayColaType(colaTypes[12]);
  }

  if (sFValueLowered.indexOf("nuka cide") > -1) {
    loggingResult("Nuka Cide");
    displayColaType(colaTypes[13]);
  } else if (sFValueLowered.indexOf("cide") > -1) {
    loggingResult("Nuka Cide");
    displayColaType(colaTypes[13]);
  }

  if (sFValueLowered.indexOf("nuka cooler") > -1) {
    loggingResult("Nuka Cooler");
    displayColaType(colaTypes[14]);
  } else if (sFValueLowered.indexOf("cooler") > -1) {
    loggingResult("Nuka Cooler");
    displayColaType(colaTypes[14]);
  }

  if (sFValueLowered.indexOf("nuka fancy") > -1) {
    loggingResult("Nuka Fancy");
    displayColaType(colaTypes[15]);
  } else if (sFValueLowered.indexOf("fancy") > -1) {
    loggingResult("Nuka Fancy");
    displayColaType(colaTypes[15]);
  }

  if (sFValueLowered.indexOf("nuka free") > -1) {
    loggingResult("Nuka Free");
    displayColaType(colaTypes[16]);
  } else if (sFValueLowered.indexOf("free") > -1) {
    loggingResult("Nuka Free");
    displayColaType(colaTypes[16]);
  }

  if (sFValueLowered.indexOf("nuka frutti") > -1) {
    loggingResult("Nuka Frutti");
    displayColaType(colaTypes[17]);
  } else if (sFValueLowered.indexOf("frutti") > -1) {
    loggingResult("Nuka Frutti");
    displayColaType(colaTypes[17]);
  }

  if (sFValueLowered.indexOf("nuka hearty") > -1) {
    loggingResult("Nuka Hearty");
    displayColaType(colaTypes[18]);
  } else if (sFValueLowered.indexOf("hearty") > -1) {
    loggingResult("Nuka Hearty");
    displayColaType(colaTypes[18]);
  }

  if (sFValueLowered.indexOf("nuka lixir") > -1) {
    loggingResult("Nuka Lixir");
    displayColaType(colaTypes[19]);
  } else if (sFValueLowered.indexOf("lixir") > -1) {
    loggingResult("Nuka Lixir");
    displayColaType(colaTypes[19]);
  }

  if (sFValueLowered.indexOf("nuka love") > -1) {
    loggingResult("Nuka Love");
    displayColaType(colaTypes[20]);
  } else if (sFValueLowered.indexOf("love") > -1) {
    loggingResult("Nuka Love");
    displayColaType(colaTypes[20]);
  }

  if (sFValueLowered.indexOf("nuka power") > -1) {
    loggingResult("Nuka Power");
    displayColaType(colaTypes[21]);
  } else if (sFValueLowered.indexOf("power") > -1) {
    loggingResult("Nuka Power");
    displayColaType(colaTypes[21]);
  }

  if (sFValueLowered.indexOf("nuka punch") > -1) {
    loggingResult("Nuka Punch");
    displayColaType(colaTypes[22]);
  } else if (sFValueLowered.indexOf("punch") > -1) {
    loggingResult("Nuka Punch");
    displayColaType(colaTypes[22]);
  }

  if (sFValueLowered.indexOf("nuka ray") > -1) {
    loggingResult("Nuka Ray");
    displayColaType(colaTypes[23]);
  } else if (sFValueLowered.indexOf("ray") > -1) {
    loggingResult("Nuka Ray");
    displayColaType(colaTypes[23]);
  }

  if (sFValueLowered.indexOf("nuka rush") > -1) {
    loggingResult("Nuka Rush");
    displayColaType(colaTypes[24]);
  } else if (sFValueLowered.indexOf("rush") > -1) {
    loggingResult("Nuka Rush");
    displayColaType(colaTypes[24]);
  }

  if (sFValueLowered.indexOf("nuka sunrise") > -1) {
    loggingResult("Nuka Sunrise");
    displayColaType(colaTypes[25]);
  } else if (sFValueLowered.indexOf("sunrise") > -1) {
    loggingResult("Nuka Sunrise");
    displayColaType(colaTypes[25]);
  }

  if (sFValueLowered.indexOf("nuka twin") > -1) {
    loggingResult("Nuka Twin");
    displayColaType(colaTypes[26]);
  } else if (sFValueLowered.indexOf("twin") > -1) {
    loggingResult("Nuka Twin");
    displayColaType(colaTypes[26]);
  }

  if (sFValueLowered.indexOf("nuka void") > -1) {
    loggingResult("Nuka Void");
    displayColaType(colaTypes[27]);
  } else if (sFValueLowered.indexOf("void") > -1) {
    loggingResult("Nuka Void");
    displayColaType(colaTypes[27]);
  }

  if (sFValueLowered.indexOf("nuka xtreme") > -1) {
    loggingResult("Nuka Xtreme");
    displayColaType(colaTypes[28]);
  } else if (sFValueLowered.indexOf("xtreme") > -1) {
    loggingResult("Nuka Xtreme");
    displayColaType(colaTypes[28]);
  }
}

function grabSFInput() {
  brandFlavors();
  mixerFlavors();
  /**/
}

sFInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    console.clear();
    colaTotal();
    grabSFInput();
  }
});

function colaTotal() {
  console.log(
    `There are a total of ${
      document.querySelectorAll(".search-result").length
    } different Nuka Cola flavors to choose from!`
  );
}
