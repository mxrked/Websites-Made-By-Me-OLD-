/*

    This script is for the indexPageFadeIns

*/


    indexPageFadeInsINIT();


        function indexPageFadeInsINIT() {

                function toggleIndexFIS() {

                    document.querySelectorAll('.page-fade-in').forEach((fi) => {

                        fi.style.display = 'block';
                        fi.classList.remove('deactive');

                    });

                }

                window.addEventListener('load', () => {

                    toggleIndexFIS();

                });


        }