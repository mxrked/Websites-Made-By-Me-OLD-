/*

    This script is for hiding each page fade ins

*/


    hidePageFadeIns();

        function hidePageFadeIns() {

            const ALL_PAGE_FADE_INS = document.querySelectorAll('.page-fade-in');


                ALL_PAGE_FADE_INS.forEach((fi) => {

                    fi.style.display = 'none';
                    fi.classList.toggle('deactive');

                });

        }