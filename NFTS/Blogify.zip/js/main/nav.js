/*

    This script is for the navigation and nav overlay

*/

    var navState;
    const nav = document.getElementById('navigation');
    const navToggler = document.getElementById('openNav');
    const navCloser = document.getElementById('closeNav');
    const navOverlay = document.getElementById('navOverlay');

    

    // hidePageContent();

    function hidePageContent() {

        document.querySelector('#navigation').classList.toggle('deactive');
        document.querySelector('#mainBodyInner').classList.toggle('deactive');

    }

    

        function openNav() {

            hidePageContent();

            document.body.style.overflowY = 'hidden';
            
            navOverlay.style.width = '100%';

        }




        function closeNav() {

            navOverlay.style.width = '0';

            setTimeout(() => {

                document.body.style.overflowY = 'auto';
                document.querySelector('#navigation').classList.remove('deactive');
                document.querySelector('#mainBodyInner').classList.remove('deactive');

            }, 1100);

        }



    navToggler.addEventListener('click', () => {

        openNav();

    });

    navCloser.addEventListener('click', () => {

        closeNav();
        
    });



   
    function checkNavState() { // Checks the navState

        if (navState == 1) {

            nav.style.position = 'fixed';
            nav.style.width = '100%';
            nav.style.zIndex = '999';

        } else {

            nav.style.position = 'relative';

        }

    }



    

    window.addEventListener('scroll', () => { // Determines whether or not to make nav fixed
        
        checkNavState();
    
        navState = 1;

    });

    window.addEventListener('beforeunload', () => { // Makes the user scroll back to top of page and also marks navState = 1 for checkNavState()

        if ('scrollRestoration' in history) {

            navState = 1;

            history.scrollRestoration = 'manual';
        }

    });