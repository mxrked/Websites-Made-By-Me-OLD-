/*

    This script will make it so that most things will have a smooth transition

*/



    sSTInit();

        function sSTInit() {

            const ALL_PAGE_TRANSITIONS = document.querySelectorAll('.page-transition-item');

                toggleSST();

                    function toggleSST() {

                        ALL_PAGE_TRANSITIONS.forEach((sst) => {

                            sst.classList.toggle('page-transition');

                        });

                    }
            
        }