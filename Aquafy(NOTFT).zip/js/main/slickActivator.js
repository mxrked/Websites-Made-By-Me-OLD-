/*

    This script is for activating the slick.js slider

*/


    // Index Testimonials Slick

        $('.index-slick').slick({
            
            arrows: true,
            dots: true,
            centerMode: true,
            centerPadding: '60px',
            slidesToShow: 3,
            responsive: [
                {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        dots: true,
                        slidesToShow: 1
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        arrows: false,
                        dots: true,
                        slidesToShow: 1
                    }
                },
                {
                    breakpoint: 1024,
                    settings: {
                        arrows: false,
                        dots: true,
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 1366,
                    settings: {
                        arrows: false,
                        dots: true,
                        slidesToShow: 2
                    }
                }
            ]
            
        });