/*

    This script is for changing the url when the user opens a modal

*/

//!!!!! NOTE !!!!!!!!!!! This script will not work properly on the web-tech server, as it requires the full web-tech url to search up the page

//! THIS FILE GOES ALONG WITH/USES menuItems.js

changeURLModalClose();

function changeURLModalClose() {

    ALL_MENU_MODAL_CLOSERS.forEach((closer) => {

        // This will get rid of the hash when closing any of the modals //!(THIS PREVENTS THE SAME MODAL FROM REOPENING ON RELOAD)
      
        closer.addEventListener("click", () => {
          history.pushState({}, "", " ");
        });

      });

}



function loadItem1() {
  history.pushState({}, "", "/menu.html#01");
}

function loadItem2() {
  history.pushState({}, "", "/menu.html#02");
}

function loadItem3() {
  history.pushState({}, "", "/menu.html#03");
}

function loadItem4() {
  history.pushState({}, "", "/menu.html#04");
}

function loadItem5() {
  history.pushState({}, "", "/menu.html#05");
}

function loadItem6() {
  history.pushState({}, "", "/menu.html#06");
}

function loadItem7() {
  history.pushState({}, "", "/menu.html#07");
}

function loadItem8() {
  history.pushState({}, "", "/menu.html#08");
}

function loadItem9() {
  history.pushState({}, "", "/menu.html#09");
}

function loadItem10() {
    history.pushState({}, "", "/menu.html#10");
}

function loadItem11() {
    history.pushState({}, "", "/menu.html#11");
}