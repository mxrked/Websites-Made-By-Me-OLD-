/*

    This script is for the menu fade ins

*/






// ----------

    toggleMenuInit();

// ----------



        function toggleMenuInit() {

            const MENU_FADE_INS = document.querySelectorAll('.menu-fade-in');

            hideMenuFadeIns();

                function hideMenuFadeIns() { // Hides all menu-fade-in classes

                    MENU_FADE_INS.forEach((item) => {

                        item.style.display = 'none';
                        item.classList.toggle('deactive');

                    });
                    
                }

            // ----------
                
                toggleMenuFadeIns();

            // ----------



                function toggleMenuFadeIns() { // Toggles all of the fade ins

                    menuAppFadeIns();
                    menuAppMain();
                    menuRollsTop();
                    menuRollsMain();
                    menuDessertsTop();
                    menuDessertsMain();

                }




                function menuAppFadeIns() { // App Top

                    document.querySelector('.menu-apps-top').style.display = 'block';

                        setTimeout(() => {

                            document.querySelector('.menu-apps-top').classList.remove('deactive');

                        }, 1300);

                }


                function menuAppMain() { // App Menu

                    document.querySelector('.menu-apps-main').style.display = 'block';

                        setTimeout(() => {

                            document.querySelector('.menu-apps-main').classList.remove('deactive');

                        }, 1700);

                }


                function menuRollsTop() { // Rolls Top

                    document.querySelector('.menu-rolls-top').style.display = 'block';

                        setTimeout(() => {

                            document.querySelector('.menu-rolls-top').classList.remove('deactive');

                        }, 1900);

                }


                function menuRollsMain() { // Rolls Main 

                    document.querySelector('.menu-rolls-main').style.display = 'block';

                        setTimeout(() => {

                            document.querySelector('.menu-rolls-main').classList.remove('deactive');

                        }, 1900);

                }


                function menuDessertsTop() { // Desserts Top

                    document.querySelector('.menu-desserts-top').style.display = 'block';

                        setTimeout(() => {

                            document.querySelector('.menu-desserts-top').classList.remove('deactive');

                        }, 2100);

                }


                function menuDessertsMain() { // Desserts Main 

                    document.querySelector('.menu-desserts-main').style.display = 'block';

                        setTimeout(() => {

                            document.querySelector('.menu-desserts-main').classList.remove('deactive');

                        }, 2100);

                }

        }