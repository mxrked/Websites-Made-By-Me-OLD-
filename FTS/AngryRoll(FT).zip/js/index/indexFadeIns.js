/*

    This script is for the index page fadeins

*/


// ----------

    indexFIInit(); //* Main indexFadeIns function

// ----------



    function indexFIInit() { 

        document.body.style.overflowY = 'hidden';

        hideIndexFadeIns();

        function hideIndexFadeIns() { // Hides the indexFadeIn classes by default

            document.querySelectorAll('.index-fade-in').forEach((fi) => {
    
                fi.classList.toggle('deactive');
                fi.style.display = 'none';
                
            })
    
        }



        function blockIndexFadeIns() { // Display blocks all indexFadeIn classes

            document.querySelectorAll('.index-fade-in').forEach((fi) => {
    
                fi.style.display = 'block';
                
            });

        }


        function toggleIndexFadeIns() { // This will be the main function that will trigger the fade in transitions

            blockIndexFadeIns();
            indexHeroFadeIns();
            indexUnderHeroFadeIns();
            indexProductSlickFadeIns();
            indexReservationsFadeIns();

        }



        function indexHeroFadeIns() { // Index Hero

            const INDEX_HERO_HOLDER = document.getElementById('indexHero');
            const INDEX_HERO_L_DIV = document.querySelector('#indexHeroL div');
            const INDEX_HERO_R = document.getElementById('indexHeroR');

            setTimeout(() => {

                document.body.style.overflowY = 'auto';

                INDEX_HERO_HOLDER.classList.remove('deactive');

            }, 1300);

            setTimeout(() => {

                INDEX_HERO_L_DIV.classList.remove('deactive');
                INDEX_HERO_L_DIV.style.top = 0;

                INDEX_HERO_R.classList.remove('deactive');
                INDEX_HERO_R.style.top = 0;

            }, 1700);

        }


        function indexUnderHeroFadeIns() { // Index Under Hero 

            const INDEX_FF_ROW = document.getElementById('indexFFRow');
            const INDEX_SR_ROW = document.getElementById('indexSRRow');

            setTimeout(() => {

                INDEX_FF_ROW.style.display = 'flex';
                INDEX_FF_ROW.classList.remove('deactive');

                INDEX_SR_ROW.style.display = 'flex';
                INDEX_SR_ROW.classList.remove('deactive');

            }, 1700);

        }


        function indexProductSlickFadeIns() { // Index Product Slick

            const INDEX_PRODUCT_SLICK = document.getElementById('indexProductSlick');

            setTimeout(() => {

                INDEX_PRODUCT_SLICK.style.display = 'block';
                INDEX_PRODUCT_SLICK.classList.remove('deactive');

            }, 1700);

        }


        function indexReservationsFadeIns() { // Index Reservations 

            const INDEX_RESERVATIONS = document.getElementById('indexReservations');

            setTimeout(() => {

                INDEX_RESERVATIONS.style.display = 'block';
                INDEX_RESERVATIONS.classList.remove('deactive');

            }, 1700);

        }


        window.addEventListener('load', toggleIndexFadeIns);
        
    }

    


