/*

    This script is for the about fade ins

*/


// --------

    toggleAboutInit();

// --------


    function toggleAboutInit() {

        const ABOUT_FADE_INS = document.querySelectorAll('.about-fade-in');

        hideAboutFadeIns();

            function hideAboutFadeIns() {

                ABOUT_FADE_INS.forEach((item) => {

                    item.style.display = 'none';
                    item.classList.toggle('deactive');

                });

            }



        // ----------
                
            toggleAboutFadeIns();

        // ----------
        

            function toggleAboutFadeIns() {

                aboutHeroFadeIns();

            }


                function aboutHeroFadeIns() {

                    document.querySelector('#aboutHero').style.display = 'block';

                        setTimeout(() => {

                            document.querySelector('#aboutHero').classList.remove('deactive');

                        }, 1300);

                }

    }