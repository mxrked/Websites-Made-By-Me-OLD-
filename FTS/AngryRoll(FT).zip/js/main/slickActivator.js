/*

    This script will activate the slick.js 

*/


// ----------

    slickInit();

// ----------


        function slickInit() {


            $(document).ready(() => {

                $('.index-products-slick').slick({ // Index Products 
                    centerMode: true,
                    slidesToShow: 3,
                    dots: true,
                    infinite: false,
                    centerPadding: '30px',
                    responsive: [
                        {
                            breakpoint: 1200,
                            settings: {
                                centerMode: true,
                                slidesToShow: 1
                            }
                        },
                        {
                            breakpoint: 1024,
                            settings: {
                                centerMode: true,
                                slidesToShow: 1
                            }
                        }, {
                            breakpoint: 768,
                            settings: {
                                centerMode: true,
                                slidesToShow: 1
                            }
                        }
                    ]

                })

            })

            
        }