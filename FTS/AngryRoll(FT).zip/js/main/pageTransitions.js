/*

    This script is for the page transition classes

*/



// ----------

    ptInit();

// ----------

        function ptInit() {


            togglePageTransitions();

            function togglePageTransitions() {

                const ALL_PAGE_TRANSITIONS = document.querySelectorAll('.page-transition');

                ALL_PAGE_TRANSITIONS.forEach((pt) => {

                    pt.classList.toggle('pageTransition');

                })

            }

        }