/*

    This script is for the menu items.

*/



//! THIS FILE USES menuLinksDetermine.js




    var menuItemToggle;
    const ALL_MENU_ITEM_BTNS = document.querySelectorAll('.menu-item-btn');    
    const ALL_MENU_MODAL_CLOSERS = document.querySelectorAll('.menu-modal-closer');


















//! Functions




    // navMenuJumper(); //! UNCOMMENT IF NEEDED...(most likely not)
    




    function menuItemToggler() { // This is what will determine which modal will be opened

        switch(menuItemToggle) { //TODO: Add a new case statement for each menu item

            case 1: // App Item 1
                
                menuModalProps();

                ALL_MENU_MODALS[0].style.display = 'flex';
                ALL_MENU_MODALS[0].classList.remove('deactive');

                break;  

            case 2: // App Item 2
            
                menuModalProps();

                ALL_MENU_MODALS[1].style.display = 'flex';
                ALL_MENU_MODALS[1].classList.remove('deactive');
                    
                break;

            case 3: // App Item 3

                menuModalProps();

                ALL_MENU_MODALS[2].style.display = 'flex';
                ALL_MENU_MODALS[2].classList.remove('deactive');
                    
                break;

            case 4: // App Item 4

                menuModalProps();

                ALL_MENU_MODALS[3].style.display = 'flex';
                ALL_MENU_MODALS[3].classList.remove('deactive');
                    
                break;

            case 5: // Roll Item 1

                menuModalProps();

                ALL_MENU_MODALS[4].style.display = 'flex';
                ALL_MENU_MODALS[4].classList.remove('deactive');
                    
                break;

            case 6: // Roll Item 2

                menuModalProps();

                ALL_MENU_MODALS[5].style.display = 'flex';
                ALL_MENU_MODALS[5].classList.remove('deactive');
                    
                break;

            case 7: // Roll Item 3

                menuModalProps();

                ALL_MENU_MODALS[6].style.display = 'flex';
                ALL_MENU_MODALS[6].classList.remove('deactive');
                    
                break;

            case 8: // Roll Item 4

                menuModalProps();

                ALL_MENU_MODALS[7].style.display = 'flex';
                ALL_MENU_MODALS[7].classList.remove('deactive');
                    
                break;

            case 9: // Roll Item 5

                menuModalProps();

                ALL_MENU_MODALS[8].style.display = 'flex';
                ALL_MENU_MODALS[8].classList.remove('deactive');
                    
                break;

            case 10: // Dessert Item 1

                menuModalProps();

                ALL_MENU_MODALS[9].style.display = 'flex';
                ALL_MENU_MODALS[9].classList.remove('deactive');
                    
                break;

            case 11: // Dessert Item 2

                menuModalProps();

                ALL_MENU_MODALS[10].style.display = 'flex';
                ALL_MENU_MODALS[10].classList.remove('deactive');
                    
                break;



        }

    }










    


    







//! Event Listeners
    

        window.onclick = function closeModalOutside(modalTarget) { // This will allow the user to close the modal when they click outside of the modal
    
            ALL_MENU_MODALS.forEach((modal) => {

                if (modalTarget.target == modal) {

                    document.body.style.overflowY = 'auto';

                    hideMenuModals();
                    history.pushState({}, "", " ");

                }

            });

        }

        ALL_MENU_MODAL_CLOSERS.forEach((closer) => { // For all of the menu modal closers

            closer.addEventListener('click', () => {

                hideMenuModals();
                document.body.style.overflowY = 'auto';

            });

        });


        ALL_MENU_ITEM_BTNS[0].addEventListener('click', () => { // App Item 1 Btn

            menuItemToggle = 1;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[1].addEventListener('click', () => { // App Item 2 Btn

            menuItemToggle = 2;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[2].addEventListener('click', () => { // App Item 3 Btn

            menuItemToggle = 3;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[3].addEventListener('click', () => { // App Item 4 Btn

            menuItemToggle = 4;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[4].addEventListener('click', () => { // Roll Item 1 Btn

            menuItemToggle = 5;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[5].addEventListener('click', () => { // Roll Item 2 Btn

            menuItemToggle = 6;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[6].addEventListener('click', () => { // Roll Item 3 Btn

            menuItemToggle = 7;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[7].addEventListener('click', () => { // Roll Item 4 Btn

            menuItemToggle = 8;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[8].addEventListener('click', () => { // Roll Item 5 Btn

            menuItemToggle = 9;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[9].addEventListener('click', () => { // Dessert Item 1 Btn

            menuItemToggle = 10;

            menuItemToggler();

        });

        ALL_MENU_ITEM_BTNS[10].addEventListener('click', () => { // Dessert Item 2 Btn

            menuItemToggle = 11;

            menuItemToggler();

        });