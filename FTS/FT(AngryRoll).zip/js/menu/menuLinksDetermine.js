/*

    This script will be used to determine which item is toggled based on what link the user picks from the nav or other pages.

*/


//! THIS FILE GOES ALONG WITH/USES menuItems.js



            var navMenuItemClicked; // This will be the value that determines which item was clicked based on a number. EX: fItem1 = 1....
            
            const ALL_MENU_MODALS = document.querySelectorAll('.menu-modal');

            const ALL_NAV_MENU_ITEMS = [ // Storing the navMenuItems

                navMenuItem1 = document.getElementById('fItem1'),
                navMenuItem2 = document.getElementById('fItem2'),
                navMenuItem5 = document.getElementById('fItem5'),
                navMenuItem6 = document.getElementById('fItem6'),
                navMenuItem10 = document.getElementById('fItem10')

            ]

            const ALL_MOBILE_NAV_MENU_ITEMS = [

                mobileNavMenuItem1 = document.getElementById('mItem1'),
                mobileNavMenuItem2 = document.getElementById('mItem2'),
                mobileNavMenuItem5 = document.getElementById('mItem5'),
                mobileNavMenuItem6 = document.getElementById('mItem6'),
                mobileNavMenuItem10 = document.getElementById('mItem10')

            ]

















//! Functions


            // ----------

                hideMenuModals(); // This will hide all of the modals by default

            // ----------


            function hideMenuModals() {

                document.querySelector('#appModals').style.display = 'none';
                document.querySelector('#rollModals').style.display = 'none';
    
                ALL_MENU_MODALS.forEach((modal) => {
    
                    modal.style.display = 'none';
                    modal.classList.toggle('deactive');
    
                });
    
            }



            function menuModalProps() { // This is for making the navMenuJumper code a bit cleaner

                document.body.style.overflowY = 'hidden';
                document.querySelector('#appModals').style.display = 'block';
                document.querySelector('#rollModals').style.display = 'block';

            }






            // -------------

             navMenuJumper(); // This will be used to trigger an items modal to open on the menu page. //! VERY IMPORTANT FOR MENU PAGE (IF DELETED OR COMMENTED OUT - Each modal will have a really dark background) !//

            // -------------


            function navMenuJumper() {

                if (window.location.href.indexOf('01') > -1) {

                    hideMenuModals();
                    menuModalProps();

                    ALL_MENU_MODALS[0].style.display = 'flex';
                    ALL_MENU_MODALS[0].classList.remove('deactive');

                    // console.log('Nav Item 1 was clicked. Now program to open the items modal.');

                } else if (window.location.href.indexOf('02') > -1) {

                    hideMenuModals();
                    menuModalProps();

                    ALL_MENU_MODALS[1].style.display = 'flex';
                    ALL_MENU_MODALS[1].classList.remove('deactive');

                    // console.log('Nav Item 2 was clicked. Now program to open the items modal.');

                } else if (window.location.href.indexOf('05') > -1) {

                    hideMenuModals();
                    menuModalProps();

                    ALL_MENU_MODALS[4].style.display = 'flex';
                    ALL_MENU_MODALS[4].classList.remove('deactive');

                    // console.log('Nav Item 3 was clicked. Now program to open the items modal.');

                } else if (window.location.href.indexOf('06') > -1) {

                    hideMenuModals();
                    menuModalProps();

                    ALL_MENU_MODALS[5].style.display = 'flex';
                    ALL_MENU_MODALS[5].classList.remove('deactive');

                    // console.log('Nav Item 4 was clicked. Now program to open the items modal.');

                } else if (window.location.href.indexOf('10') > -1) {

                    hideMenuModals();
                    menuModalProps();

                    ALL_MENU_MODALS[9].style.display = 'flex';
                    ALL_MENU_MODALS[9].classList.remove('deactive');

                    // console.log('Nav Item 6 was clicked. Now program to open the items modal.');

                }

            }
















//! Event Listeners

                ALL_NAV_MENU_ITEMS[0].addEventListener('click', () => { // Nav Menu Item 1

                    hideMenuModals();

                    navMenuItemClicked = 1;
                    menuItemToggle = 1;
                    
                    menuItemToggler();

                });

                ALL_MOBILE_NAV_MENU_ITEMS[0].addEventListener('click', () => { // Mobile Nav Menu Item 1

                    hideMenuModals();

                    navMenuItemClicked = 1;
                    menuItemToggle = 1;
                    
                    menuItemToggler();

                });


                ALL_NAV_MENU_ITEMS[1].addEventListener('click', () => { // Nav Menu Item 2

                    hideMenuModals();

                    navMenuItemClicked = 2;
                    menuItemToggle = 2;
                    
                    menuItemToggler();

                });

                ALL_MOBILE_NAV_MENU_ITEMS[1].addEventListener('click', () => { // Mobile Nav Menu Item 2

                    hideMenuModals();

                    navMenuItemClicked = 2;
                    menuItemToggle = 2;
                    
                    menuItemToggler();

                });


                ALL_NAV_MENU_ITEMS[2].addEventListener('click', () => { // Nav Menu Item 2

                    hideMenuModals();

                    navMenuItemClicked = 5;
                    menuItemToggle = 5;
                    
                    menuItemToggler();

                });

                ALL_MOBILE_NAV_MENU_ITEMS[2].addEventListener('click', () => { // Mobile Nav Menu Item 2

                    hideMenuModals();

                    navMenuItemClicked = 5;
                    menuItemToggle = 5;
                    
                    menuItemToggler();

                });


                ALL_NAV_MENU_ITEMS[3].addEventListener('click', () => { // Nav Menu Item 2

                    hideMenuModals();

                    navMenuItemClicked = 6;
                    menuItemToggle = 6;
                    
                    menuItemToggler();

                });

                ALL_MOBILE_NAV_MENU_ITEMS[3].addEventListener('click', () => { // Mobile Nav Menu Item 2

                    hideMenuModals();

                    navMenuItemClicked = 6;
                    menuItemToggle = 6;
                    
                    menuItemToggler();

                });


                ALL_NAV_MENU_ITEMS[4].addEventListener('click', () => { // Nav Menu Item 3

                    hideMenuModals();

                    navMenuItemClicked = 10;
                    menuItemToggle = 10;
                    
                    menuItemToggler();

                });

                ALL_MOBILE_NAV_MENU_ITEMS[4].addEventListener('click', () => { // Mobile Nav Menu Item 3

                    hideMenuModals();

                    navMenuItemClicked = 10;
                    menuItemToggle = 10;
                    
                    menuItemToggler();

                });