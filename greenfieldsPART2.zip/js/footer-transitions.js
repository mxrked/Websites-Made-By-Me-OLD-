/*

    This script is for the footer transitions

*/


    toggleFooterTransitions();


        var footerI;


        function toggleFooterTransitions() {

            const ALL_FOOTER_TRANSITIONS = document.getElementsByClassName('footer-transition');

            for (footerI = 0; footerI < ALL_FOOTER_TRANSITIONS.length; footerI++) {

                ALL_FOOTER_TRANSITIONS[footerI].classList.toggle('window-transition');

            }

        }