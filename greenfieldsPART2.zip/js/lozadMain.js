/* 

    !Name:
    lozadMain.js

    !Files Used:
    all

    !Script Desc:
    this script is for the lazy loading imgs


*/




    //! Add the class "lozad" to each img or background div you would like to lazy load.
      
            //* data-src (imgs)
            //* data-background-image (background images)


const observer = lozad(); // lazy loads elements with default selector as ".lozad"

observer.observe();