/*

    This script is for the gallery page modals

*/



    const GALLERY_GALLERY = document.getElementById('galleryItems');
    const GALLERY_MODALS = document.getElementById('galleryModals');
    const ALL_GALLERY_GALLERY_ITEMS = document.querySelectorAll('.gallery-item');
    const ALL_GALLERY_MODALS = document.getElementsByClassName('gallery-item-modal');
    const ALL_GALLERY_MODAL_CLOSERS = document.querySelectorAll('.gallery-modal-closer');







        const galleryItemsArray = [ // Storing Variables

            galleryItem1 = document.getElementById('gI1'),
            galleryItem2 = document.getElementById('gI2'),
            galleryItem3 = document.getElementById('gI3'),
            galleryItem4 = document.getElementById('gI4')

        ];


        const galleryModalsArray = [ // Storing Variables

            galleryModal1 = document.getElementById('gIM1'),
            galleryModal2 = document.getElementById('gIM2'),
            galleryModal3 = document.getElementById('gIM3'),
            galleryModal4 = document.getElementById('gIM4')

        ];


        var galleryModalCloseTrigger; // Used to determine which modal goes with what item
        var galleryModalOpened;



        // Hides both the gallery and modals by default
        GALLERY_GALLERY.classList.toggle('deactive');
        GALLERY_MODALS.classList.toggle('deactive');




            hideAllGalleryModals(); // Hides all the gallery modals by default


                function hideAllGalleryModals() {

                    for (galleryI = 0; galleryI < ALL_GALLERY_MODALS.length; galleryI++) {

                        ALL_GALLERY_MODALS[galleryI].classList.toggle('deactive');

                    }

                }




            function preventGalleryModalScroll() { // This will prevent the user to scroll when a gallery modal is opened

                ALL_GALLERY_GALLERY_ITEMS.forEach((item) => {

                    item = document.querySelector('.gallery-item');

                    document.body.style.overflowY = 'hidden';

                });

            }







        galleryItemsArray[0].addEventListener('click', () => { // Item 1

            preventGalleryModalScroll();

            galleryModalOpened = true;
            galleryModalCloseTrigger = 0;

            galleryModalsArray[0].classList.remove('deactive');

        });


        galleryItemsArray[1].addEventListener('click', () => { // Item 2

            preventGalleryModalScroll();

            galleryModalOpened = true;
            galleryModalCloseTrigger = 1;

            galleryModalsArray[1].classList.remove('deactive');

        });



        function resizeGalleryModalFix() { // This is for when the user resizes the browser when a gallery modal is opened

            switch(galleryModalOpened) {

                case true: 

                    document.body.style.overflowY = 'hidden';
                    break;

                case false:

                    document.body.style.overflowY = 'auto';
                    break;

            }

        }





        function determineGalleryModalClose() { // Determines which modal will close based on the trigger

            switch(galleryModalCloseTrigger) {

                case 0:

                    ALL_GALLERY_MODALS[0].classList.toggle('deactive');
                    document.body.style.overflowY = 'auto';
                    galleryModalOpened = false;
                    break;

                case 1: 

                    ALL_GALLERY_MODALS[1].classList.toggle('deactive');
                    document.body.style.overflowY = 'auto';
                    galleryModalOpened = false;
                    break;

                default: // All else fails.... hide them all

                    hideAllGalleryModals();

            }

        }




        window.addEventListener('load', ()=> { // Shows the gallery and gallery modals after 4ms, this is for when the user reloads, it shows a modal.

            setTimeout(() => {

                GALLERY_GALLERY.classList.remove('deactive');
                GALLERY_MODALS.classList.remove('deactive');

            }, 400);

        });


        window.addEventListener('resize', resizeGalleryModalFix);
        ALL_GALLERY_MODAL_CLOSERS[0].addEventListener('click', determineGalleryModalClose);
        ALL_GALLERY_MODAL_CLOSERS[1].addEventListener('click', determineGalleryModalClose);