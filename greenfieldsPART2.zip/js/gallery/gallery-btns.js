/*

    This script is for the gallery page tab btns

*/




    const GALLERY = document.getElementById('galleryMain');
    const ALL_GALLERY_TABS = document.querySelectorAll('.gallery-tabs-box button');
    document.querySelector('#allTab').classList.toggle('active');

    //? Triggers

    let allClicked;
    let forestClicked;
    let hLClicked;
    let snowyClicked;


    var galleryI;





    //! Functions


    removeTabsHighLight(); // This will reset the highlights of the btns


    function removeTabsHighLight() {

        for (galleryI = 0; galleryI < ALL_GALLERY_TABS.length; galleryI++) {

            ALL_GALLERY_TABS[galleryI].addEventListener('click', () => {

                ALL_GALLERY_TABS[galleryI].classList.remove('active');

            });

        }

    }


    determineTabHighLight(); 

    function determineTabHighLight() { // This will determine which button will be highlighted based on the clicked trigger

        if (allClicked === 1 && forestClicked === 0 && hLClicked === 0 && snowyClicked === 0) {

            document.querySelector('#allTab').classList.toggle('active');
            document.querySelector('#forestTab').classList.remove('active');
            document.querySelector('#hLTab').classList.remove('active');
            document.querySelector('#snowyTab').classList.remove('active');

        } else if (allClicked === 0 && forestClicked === 1 && hLClicked === 0 && snowyClicked === 0) {

            document.querySelector('#allTab').classList.remove('active');
            document.querySelector('#forestTab').classList.toggle('active');
            document.querySelector('#hLTab').classList.remove('active');
            document.querySelector('#snowyTab').classList.remove('active');

        } else if (allClicked === 0 && forestClicked === 0 && hLClicked === 1 && snowyClicked === 0) {

            document.querySelector('#allTab').classList.remove('active');
            document.querySelector('#forestTab').classList.remove('active');
            document.querySelector('#hLTab').classList.toggle('active');
            document.querySelector('#snowyTab').classList.remove('active');

        } else if (allClicked === 0 && forestClicked === 0 && hLClicked === 0 && snowyClicked === 1) {

            document.querySelector('#allTab').classList.remove('active');
            document.querySelector('#forestTab').classList.remove('active')
            document.querySelector('#hLTab').classList.remove('active');
            document.querySelector('#snowyTab').classList.toggle('active');

        }

    }




    //! Btn Event Listeners

    document.querySelector('#allTab').addEventListener('click', () => { // All Tab

        allClicked = 1;
        forestClicked = 0;
        hLClicked = 0;
        snowyClicked = 0;

        removeTabsHighLight();
        determineTabHighLight();

    });


    document.querySelector('#forestTab').addEventListener('click', () => { // Forest Tab

        allClicked = 0;
        forestClicked = 1;
        hLClicked = 0;
        snowyClicked = 0;

        removeTabsHighLight();
        determineTabHighLight();

    });


    document.querySelector('#hLTab').addEventListener('click', () => { // Highlands Tab

        allClicked = 0;
        forestClicked = 0;
        hLClicked = 1;
        snowyClicked = 0;

        removeTabsHighLight();
        determineTabHighLight();

    });


    document.querySelector('#snowyTab').addEventListener('click', () => { // Snowy Tab

        allClicked = 0;
        forestClicked = 0;
        hLClicked = 0;
        snowyClicked = 1;

        removeTabsHighLight();
        determineTabHighLight();

    });