/*

    This script is for the gallery page gallery

*/


    const ALL_GALLERY_ITEMS = document.getElementsByClassName('gallery-item');
    const ALL_FOREST_ITEMS = document.getElementsByClassName('forest');
    const ALL_HL_ITEMS = document.getElementsByClassName('hL');
    const ALL_SNOWY_ITEMS = document.getElementsByClassName('snowy');
    const ALL_GALLERY_ROWS = document.getElementsByClassName('.gallery-items-row');


    var galleryImgsI;


        displayAllImgs(); // Shows all of the gallery items by default


            function displayAllImgs() {

                for (galleryImgsI = 0; galleryImgsI < ALL_GALLERY_ROWS.length; galleryImgsI++) {

                    ALL_GALLERY_ROWS[galleryImgsI].style.display = 'flex';
                    ALL_GALLERY_ROWS[galleryImgsI].classList.remove('deactive');

                }

                for (galleryImgsI = 0; galleryImgsI < ALL_GALLERY_ITEMS.length; galleryImgsI++) {

                    ALL_GALLERY_ITEMS[galleryImgsI].style.display = 'block';
                    ALL_GALLERY_ITEMS[galleryImgsI].classList.remove('deactive');

                }

            }
    





        function hideAllImgs() { // Used to hide all the other items when one tab is clicked
 
            for (galleryImgsI = 0; galleryImgsI < ALL_GALLERY_ITEMS.length; galleryImgsI++) {

                ALL_GALLERY_ITEMS[galleryImgsI].style.display = 'none';

            }

            for (galleryImgsI = 0; galleryImgsI < ALL_GALLERY_ROWS.length; galleryImgsI++) {

                ALL_GALLERY_ROWS[galleryImgsI].style.display = 'none';

            }

        }
        




        document.querySelector('#allTab').addEventListener('click', () => { // All Tab

            displayAllImgs();

        });



        document.querySelector('#forestTab').addEventListener('click', () => { // Forest Tab

            hideAllImgs();

            for (galleryImgsI = 0; galleryImgsI < ALL_FOREST_ITEMS.length; galleryImgsI++) {

                ALL_FOREST_ITEMS[galleryImgsI].style.display = 'block';
                ALL_FOREST_ITEMS[galleryImgsI].classList.remove('deactive');

            }

            document.querySelector('#forestRow').style.display = 'flex';

        });



        document.querySelector('#hLTab').addEventListener('click', () => { // Highlands Tab

            hideAllImgs();

            for (galleryImgsI = 0; galleryImgsI < ALL_HL_ITEMS.length; galleryImgsI++) {

                ALL_HL_ITEMS[galleryImgsI].style.display = 'block';
                ALL_HL_ITEMS[galleryImgsI].classList.remove('deactive');

            }

            document.querySelector('#hLRow').style.display = 'flex';

        });



        document.querySelector('#snowyTab').addEventListener('click', () => {

            hideAllImgs();

            for (galleryImgsI = 0; galleryImgsI < ALL_SNOWY_ITEMS.length; galleryImgsI++) {

                ALL_SNOWY_ITEMS[galleryImgsI].style.display = 'block';
                ALL_SNOWY_ITEMS[galleryImgsI].classList.remove('deactive');

            }

            document.querySelector('#snowyRow').style.display = 'flex';

        })