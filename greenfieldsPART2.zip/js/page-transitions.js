/*

    This script is for the page transitions

*/



    var pageI;


        togglePageTransitions();


        function togglePageTransitions() {

            const ALL_PAGE_TRANSITIONS = document.getElementsByClassName('page-transition');

            for (pageI = 0; pageI < ALL_PAGE_TRANSITIONS.length; pageI++) {

                ALL_PAGE_TRANSITIONS[pageI].classList.toggle('window-transition');

            }

        }




       