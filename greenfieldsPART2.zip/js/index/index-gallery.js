/*

    This script is for the index gallery

*/





    const INDEX_GALLERY = document.getElementById('indexGallery');
    const ALL_INDEX_GALLERY_ITEMS = document.querySelectorAll('.index-gallery-item');
    const ALL_INDEX_GALLERY_MODALS = document.getElementsByClassName('index-gallery-modal');
    const ALL_INDEX_GALLERY_CLOSERS = document.querySelectorAll('.index-gallery-modal-closer');






    const indexGalleryItemsArray = [ // Storing Variables

        indexGalleryItem1 = document.getElementById('iG1'),
        indexGalleryItem2 = document.getElementById('iG2'),
        indexGalleryItem3 = document.getElementById('iG3'),
        indexGalleryItem4 = document.getElementById('iG4')

    ];

    const indexGalleryModalsArray = [ // Storing Variables

        indexGalleryModal1 = document.getElementById('iGM1'),
        indexGalleryModal2 = document.getElementById('iGM2'),
        indexGalleryModal3 = document.getElementById('iGM3'),
        indexGalleryModal4 = document.getElementById('iGM4')

    ];


    var indexGalleryI;
    var indexGalleryModalCloseTrigger; // Used to determine which modal goes with what item
    var indexGalleryModalOpened;


    INDEX_GALLERY.classList.toggle('deactive'); // This will hide the modal that keeps popping up when the user reloads

   






    hideAllIndexGalleryModals(); // Hides the index gallery modals by default

    function hideAllIndexGalleryModals() { 

        for (indexGalleryI = 0; indexGalleryI < ALL_INDEX_GALLERY_MODALS.length; indexGalleryI++) {

            ALL_INDEX_GALLERY_MODALS[indexGalleryI].classList.toggle('deactive');

        }

    }









    function preventScrollModal() { // This will prevent the user to scroll when a index gallery modal is opened

        const PREVENT_MODALS = document.querySelectorAll('.index-gallery-item');

        PREVENT_MODALS.forEach((item) => {

            item = document.querySelector('.index-gallery-item');

            document.body.style.overflowY = 'hidden';

        })

    }






    indexGalleryItemsArray[0].addEventListener('click', () => { // Item 1

        preventScrollModal();

        indexGalleryModalOpened = true;
        indexGalleryModalCloseTrigger = 0;

        indexGalleryModalsArray[0].classList.remove('deactive');

    });





    indexGalleryItemsArray[1].addEventListener('click', () => { // Item 2

        preventScrollModal();

        indexGalleryModalOpened = true;
        indexGalleryModalCloseTrigger = 1;

        indexGalleryModalsArray[1].classList.remove('deactive');

    });





    indexGalleryItemsArray[2].addEventListener('click', () => { // Item 1

        preventScrollModal();

        indexGalleryModalOpened = true;
        indexGalleryModalCloseTrigger = 2;

        indexGalleryModalsArray[2].classList.remove('deactive');

    });



    

    indexGalleryItemsArray[3].addEventListener('click', () => { // Item 2

        preventScrollModal();

        indexGalleryModalOpened = true;
        indexGalleryModalCloseTrigger = 3;

        indexGalleryModalsArray[3].classList.remove('deactive');

    });




    function resizeIndexModalFix() { // This is for when the user resizes the browser when a gallery modal is opened

        switch(indexGalleryModalOpened) {

            case true:

                document.body.style.overflowY = 'hidden';
                break;

            case false:

                document.body.style.overflowY = 'auto';
                break;

        }

    }
    




    function determineIndexModalClose() { // Determines which modal will close based on the trigger

        switch(indexGalleryModalCloseTrigger) {

            case 0:

                ALL_INDEX_GALLERY_MODALS[0].classList.toggle('deactive');
                document.body.style.overflowY = 'auto';
                indexGalleryModalOpened = false;
                break;

            case 1:

                ALL_INDEX_GALLERY_MODALS[1].classList.toggle('deactive');
                document.body.style.overflowY = 'auto';
                indexGalleryModalOpened = false;
                break;

            case 2:

                ALL_INDEX_GALLERY_MODALS[2].classList.toggle('deactive');
                document.body.style.overflowY = 'auto';
                indexGalleryModalOpened = false;
                break;
    
            case 3:
    
                ALL_INDEX_GALLERY_MODALS[3].classList.toggle('deactive');
                document.body.style.overflowY = 'auto';
                indexGalleryModalOpened = false;
                break;

            default: // All else fails.... hide them all

                hideAllIndexGalleryModals();

        }

    }





    // Closer Event Listeners

    window.addEventListener('load', () => { // Shows the index gallery after 4ms, this is for when the user reloads, it shows a modal.

        setTimeout(() => {

            INDEX_GALLERY.classList.remove('deactive');

        }, 400); 

    });
    window.addEventListener('resize', resizeIndexModalFix);
    ALL_INDEX_GALLERY_CLOSERS[0].addEventListener('click', determineIndexModalClose);
    ALL_INDEX_GALLERY_CLOSERS[1].addEventListener('click', determineIndexModalClose); 
    ALL_INDEX_GALLERY_CLOSERS[2].addEventListener('click', determineIndexModalClose);
    ALL_INDEX_GALLERY_CLOSERS[3].addEventListener('click', determineIndexModalClose); 